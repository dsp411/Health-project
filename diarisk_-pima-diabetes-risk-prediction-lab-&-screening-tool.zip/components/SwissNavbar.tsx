'use client';

import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';

interface SwissNavbarProps {
  onContactClick: () => void;
  onLabClick: () => void;
}

export default function SwissNavbar({ onContactClick, onLabClick }: SwissNavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full h-[80px] bg-[#f2f2f2]/90 backdrop-blur-[12px] border-b border-[#1e1e1e]/10 px-4 sm:px-8">
      <div className="max-w-7xl mx-auto h-full flex items-center justify-between">
        {/* Brandmark */}
        <a href="#hero" className="flex items-center gap-3 group">
          <div className="w-5 h-5 bg-[#111111] transition-transform duration-300 group-hover:rotate-45" />
          <div className="flex flex-col">
            <span className="font-clash font-bold text-lg text-[#111111] tracking-tight leading-none uppercase">
              SWISS ARCHIVE
            </span>
            <span className="font-satoshi text-[9px] uppercase tracking-widest text-[#838282] mt-0.5">
              TYPOGRAPHIC SYSTEM
            </span>
          </div>
        </a>

        {/* Desktop Navigation Links (14px uppercase Satoshi with 120ms color transition to #b6b5b5) */}
        <nav className="hidden lg:flex items-center gap-8">
          <a
            href="#hero"
            className="text-[14px] uppercase font-satoshi font-medium tracking-wider text-[#111111] transition-colors duration-[120ms] hover:text-[#b6b5b5]"
          >
            01 // ECHO
          </a>
          <a
            href="#philosophy"
            className="text-[14px] uppercase font-satoshi font-medium tracking-wider text-[#111111] transition-colors duration-[120ms] hover:text-[#b6b5b5]"
          >
            02 // PHILOSOPHY
          </a>
          <a
            href="#showcase"
            className="text-[14px] uppercase font-satoshi font-medium tracking-wider text-[#111111] transition-colors duration-[120ms] hover:text-[#b6b5b5]"
          >
            03 // SHOWCASE
          </a>
          <a
            href="#services"
            className="text-[14px] uppercase font-satoshi font-medium tracking-wider text-[#111111] transition-colors duration-[120ms] hover:text-[#b6b5b5]"
          >
            04 // SERVICES
          </a>
          <button
            onClick={onLabClick}
            className="text-[14px] uppercase font-satoshi font-medium tracking-wider text-[#111111] transition-colors duration-[120ms] hover:text-[#b6b5b5] flex items-center gap-1.5"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#111111]" />
            LAB ENGINE
          </button>
        </nav>

        {/* Action Controls: Pill-shaped contact button with 1px solid #1e1e1e border that inverts on hover */}
        <div className="hidden sm:flex items-center gap-4">
          <button
            onClick={onContactClick}
            className="rounded-full border border-[#1e1e1e] px-6 py-2.5 text-[14px] uppercase font-satoshi font-bold tracking-wider text-[#111111] bg-transparent hover:bg-[#1e1e1e] hover:text-[#f2f2f2] transition-colors duration-200"
          >
            CONTACT STUDIO
          </button>
        </div>

        {/* Mobile Hamburger Toggle */}
        <div className="lg:hidden flex items-center gap-2">
          <button
            onClick={onContactClick}
            className="sm:hidden rounded-full border border-[#1e1e1e] px-3.5 py-1.5 text-[12px] uppercase font-satoshi font-bold tracking-wider text-[#111111] hover:bg-[#1e1e1e] hover:text-[#f2f2f2] transition-colors"
          >
            CONTACT
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-[#111111] hover:text-[#838282] transition-colors"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden absolute top-[80px] left-0 w-full bg-[#f2f2f2] border-b border-[#1e1e1e]/15 p-6 flex flex-col gap-4 shadow-xl">
          <a
            href="#hero"
            onClick={() => setMobileMenuOpen(false)}
            className="text-[14px] uppercase font-satoshi font-medium tracking-wider text-[#111111] hover:text-[#b6b5b5] py-2 border-b border-[#1e1e1e]/10"
          >
            01 // ECHO HERO
          </a>
          <a
            href="#philosophy"
            onClick={() => setMobileMenuOpen(false)}
            className="text-[14px] uppercase font-satoshi font-medium tracking-wider text-[#111111] hover:text-[#b6b5b5] py-2 border-b border-[#1e1e1e]/10"
          >
            02 // PHILOSOPHY &amp; NARRATIVE
          </a>
          <a
            href="#showcase"
            onClick={() => setMobileMenuOpen(false)}
            className="text-[14px] uppercase font-satoshi font-medium tracking-wider text-[#111111] hover:text-[#b6b5b5] py-2 border-b border-[#1e1e1e]/10"
          >
            03 // ASYMMETRICAL SHOWCASE
          </a>
          <a
            href="#services"
            onClick={() => setMobileMenuOpen(false)}
            className="text-[14px] uppercase font-satoshi font-medium tracking-wider text-[#111111] hover:text-[#b6b5b5] py-2 border-b border-[#1e1e1e]/10"
          >
            04 // BESPOKE SERVICES
          </a>
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onLabClick();
            }}
            className="text-left text-[14px] uppercase font-satoshi font-medium tracking-wider text-[#111111] hover:text-[#b6b5b5] py-2 border-b border-[#1e1e1e]/10"
          >
            05 // CLINICAL LAB ENGINE
          </button>
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onContactClick();
            }}
            className="mt-2 w-full rounded-full border border-[#1e1e1e] py-3 text-center text-[14px] uppercase font-satoshi font-bold tracking-wider text-[#111111] hover:bg-[#1e1e1e] hover:text-[#f2f2f2] transition-colors"
          >
            CONTACT STUDIO
          </button>
        </div>
      )}
    </header>
  );
}
