'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  FileText,
  Database,
  Sliders,
  BarChart2,
  BrainCircuit,
  Award,
  Globe,
  ChevronRight,
  ChevronLeft,
  Stethoscope,
  BookOpen,
  ArrowRight,
} from 'lucide-react';
import Exp1Objective from './experiments/Exp1Objective';
import Exp2Dataset from './experiments/Exp2Dataset';
import Exp3Preprocess from './experiments/Exp3Preprocess';
import Exp4EDA from './experiments/Exp4EDA';
import Exp5Training from './experiments/Exp5Training';
import Exp6Evaluation from './experiments/Exp6Evaluation';
import Exp7Deployment from './experiments/Exp7Deployment';
import Exp8Maintenance from './experiments/Exp8Maintenance';

interface LabStudioProps {
  onLaunchScreening: () => void;
  activeExp?: number;
  setActiveExp?: (exp: number) => void;
}

export default function LabStudio({ onLaunchScreening, activeExp: parentExp, setActiveExp: setParentExp }: LabStudioProps) {
  const [internalExp, setInternalExp] = useState<number>(1);
  const activeExp = parentExp ?? internalExp;
  const setActiveExp = setParentExp ?? setInternalExp;

  const experiments = [
    {
      id: 1,
      name: '01. Objective',
      fullTitle: 'Experiment 1: Project Goals & Clinical Need',
      phase: 'Phase 1: Problem & Data',
      icon: FileText,
      desc: 'High recall (≥ 80%) to minimize missed diabetes cases.',
    },
    {
      id: 2,
      name: '02. Dataset',
      fullTitle: 'Experiment 2: Pima Indians Cohort Data',
      phase: 'Phase 1: Problem & Data',
      icon: Database,
      desc: '768 patient records with 8 clinical physiological markers.',
    },
    {
      id: 3,
      name: '03. Cleaning',
      fullTitle: 'Experiment 3: Pre-processing & Imputation',
      phase: 'Phase 2: Pipeline',
      icon: Sliders,
      desc: 'Replacing biological zeros and standardizing feature scales.',
    },
    {
      id: 4,
      name: '04. Visuals',
      fullTitle: 'Experiment 4: Exploratory Data Analysis',
      phase: 'Phase 2: Pipeline',
      icon: BarChart2,
      desc: 'Feature correlation heatmaps and glucose distribution curves.',
    },
    {
      id: 5,
      name: '05. Training',
      fullTitle: 'Experiment 5: Model Training & Tuning',
      phase: 'Phase 3: Machine Learning',
      icon: BrainCircuit,
      desc: 'Comparing XGBoost, Random Forest, and Logistic Regression.',
    },
    {
      id: 6,
      name: '06. Evaluation',
      fullTitle: 'Experiment 6: Evaluation & Metrics',
      phase: 'Phase 3: Machine Learning',
      icon: Award,
      desc: 'Test set ROC curve (AUC 0.884) and decision threshold analysis.',
    },
    {
      id: 7,
      name: '07. API',
      fullTitle: 'Experiment 7: Live Prediction Endpoint',
      phase: 'Phase 4: Production',
      icon: Globe,
      desc: 'Test real-time predictions with JSON API requests.',
    },
    {
      id: 8,
      name: '08. Monitor',
      fullTitle: 'Experiment 8: Drift & Monitoring',
      phase: 'Phase 4: Production',
      icon: BrainCircuit,
      desc: 'Data drift surveillance and model retraining triggers.',
    },
  ];

  const currentExperiment = experiments.find((e) => e.id === activeExp) || experiments[0];
  const progressPct = ((activeExp) / 8) * 100;

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' && activeExp < 8) {
        setActiveExp(activeExp + 1);
      } else if (e.key === 'ArrowLeft' && activeExp > 1) {
        setActiveExp(activeExp - 1);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeExp, setActiveExp]);

  return (
    <div className="w-full bg-[#f2f2f2] text-[#111111] py-12 px-6 sm:px-10 lg:px-16">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header Card with Clean Swiss Brutalist Styling */}
        <div className="p-8 sm:p-10 rounded-sm bg-[#ffffff] border border-[#1e1e1e]/15 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 border-b border-[#1e1e1e]/10 pb-6">
            <div>
              <div className="flex items-center gap-2 mb-2 text-xs font-mono uppercase tracking-widest text-[#838282]">
                <span>WORKSPACE 02</span>
                <span>/</span>
                <span>RESEARCH &amp; AUDIT SUITE</span>
              </div>
              <h1 className="font-clash text-3xl sm:text-4xl font-bold text-[#111111] tracking-tight">
                Metabolic Machine Learning Lab
              </h1>
              <p className="font-satoshi text-xs sm:text-sm text-[#838282] mt-1 max-w-xl">
                Inspect 8 reproducible scientific experiments: data ingestion, zero-imputation, exploratory analysis,
                supervised training, ROC curve audits, REST API, and data drift monitoring.
              </p>
            </div>

            <button
              onClick={onLaunchScreening}
              className="self-start sm:self-center px-5 py-2.5 rounded-full bg-[#111111] text-[#f2f2f2] text-xs font-satoshi font-bold uppercase tracking-wider hover:bg-[#333333] transition-colors flex items-center gap-2 cursor-pointer shadow-xs"
            >
              <Stethoscope className="h-4 w-4" />
              <span>Open Patient Screener</span>
            </button>
          </div>

          {/* Clean Progress Line */}
          <div>
            <div className="flex items-center justify-between text-xs font-satoshi text-[#838282] mb-2 font-semibold">
              <span className="flex items-center gap-2 text-[#111111]">
                <BookOpen className="h-4 w-4 text-[#111111]" />
                <span className="font-clash font-bold uppercase">{currentExperiment.fullTitle}</span>
              </span>
              <span className="font-mono text-xs">{activeExp} of 8 Experiments</span>
            </div>
            <div className="w-full bg-[#e6e6e6] rounded-xs h-1.5 overflow-hidden">
              <div
                className="bg-[#111111] h-1.5 rounded-xs transition-all duration-300"
                style={{ width: `${progressPct}%` }}
              />
            </div>
          </div>

          {/* 8-Step Experiment Tabs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 pt-2">
            {experiments.map((exp) => {
              const isActive = activeExp === exp.id;
              const isCompleted = activeExp > exp.id;

              return (
                <button
                  key={exp.id}
                  onClick={() => setActiveExp(exp.id)}
                  className={`p-3 rounded-xs text-left transition-all cursor-pointer border ${
                    isActive
                      ? 'bg-[#111111] text-[#f2f2f2] border-[#111111] shadow-xs'
                      : 'bg-[#f2f2f2] hover:bg-[#ffffff] text-[#111111] border-[#1e1e1e]/10'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span
                      className={`text-[10px] font-mono font-bold uppercase ${
                        isActive ? 'text-[#f2f2f2]/70' : 'text-[#838282]'
                      }`}
                    >
                      EXP {exp.id}
                    </span>
                    {isCompleted && (
                      <span className="text-[10px] font-bold text-emerald-600">✓</span>
                    )}
                  </div>
                  <div className="font-clash text-xs font-bold truncate leading-tight">
                    {exp.name.replace(/^\d+\.\s*/, '')}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Experiment Content Stage */}
        <div className="bg-[#ffffff] border border-[#1e1e1e]/15 rounded-sm p-6 sm:p-10 shadow-xs">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeExp}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.25, ease: [0.77, 0, 0.175, 1] }}
            >
              {activeExp === 1 && <Exp1Objective />}
              {activeExp === 2 && <Exp2Dataset />}
              {activeExp === 3 && <Exp3Preprocess />}
              {activeExp === 4 && <Exp4EDA />}
              {activeExp === 5 && <Exp5Training />}
              {activeExp === 6 && <Exp6Evaluation />}
              {activeExp === 7 && <Exp7Deployment onLaunchScreening={onLaunchScreening} />}
              {activeExp === 8 && <Exp8Maintenance />}
            </motion.div>
          </AnimatePresence>

          {/* Stepper Navigation Controls */}
          <div className="flex items-center justify-between border-t border-[#1e1e1e]/10 pt-8 mt-10">
            <button
              onClick={() => setActiveExp(Math.max(1, activeExp - 1))}
              disabled={activeExp === 1}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-[#1e1e1e]/20 text-xs font-satoshi font-bold uppercase tracking-wider text-[#111111] hover:bg-[#f2f2f2] transition-colors disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
            >
              <ChevronLeft className="h-4 w-4" />
              <span>Previous Experiment</span>
            </button>

            <span className="text-xs font-mono text-[#838282] hidden sm:inline-block">
              {currentExperiment.phase}
            </span>

            {activeExp < 8 ? (
              <button
                onClick={() => setActiveExp(activeExp + 1)}
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#111111] text-[#f2f2f2] text-xs font-satoshi font-bold uppercase tracking-wider hover:bg-[#333333] transition-colors cursor-pointer"
              >
                <span>Next: Exp {activeExp + 1}</span>
                <ChevronRight className="h-4 w-4" />
              </button>
            ) : (
              <button
                onClick={onLaunchScreening}
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#111111] text-[#f2f2f2] text-xs font-satoshi font-bold uppercase tracking-wider hover:bg-[#333333] transition-colors cursor-pointer"
              >
                <span>Return to Screener</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
