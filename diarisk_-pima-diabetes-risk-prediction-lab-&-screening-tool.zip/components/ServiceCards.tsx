'use client';

import React from 'react';
import { ArrowRight } from 'lucide-react';

interface ServiceCardsProps {
  onServiceClick?: (serviceId: string) => void;
}

export default function ServiceCards({ onServiceClick }: ServiceCardsProps) {
  const services = [
    {
      id: 'typography',
      index: '01',
      kicker: 'MODULAR SPEC // 01',
      title: 'Typographic Systems',
      description:
        'Rigorous type hierarchies configured with mathematical ratio scales, -0.05em negative tracking, and multi-layered echo depth vectors.',
      cta: 'EXPLORE TYPOGRAPHY',
      shape: (
        <div className="w-6 h-6 border border-[#111111] relative">
          <div className="absolute top-1 left-1 right-1 bottom-1 bg-[#111111]" />
        </div>
      ),
    },
    {
      id: 'architecture',
      index: '02',
      kicker: 'STRUCTURAL SPEC // 02',
      title: 'Architectural Grids',
      description:
        'Asymmetrical 12-column frameworks, 500px pill viewports, and zero-pill discipline engineered for monumental editorial monographs.',
      cta: 'EXAMINE GRIDS',
      shape: (
        <div className="w-7 h-7 rounded-full border border-[#111111] flex items-center justify-center">
          <div className="w-3 h-3 bg-[#111111]" />
        </div>
      ),
    },
    {
      id: 'clinical',
      index: '03',
      kicker: 'ANALYTIC SPEC // 03',
      title: 'Clinical Model Lab',
      description:
        'High-recall triage matrices, diabetes risk prediction pipelines, and server-side model evaluation embedded in pure minimalist form.',
      cta: 'LAUNCH LAB ENGINE',
      shape: (
        <div className="w-6 h-6 border border-[#111111] rotate-45 flex items-center justify-center">
          <div className="w-2.5 h-2.5 bg-[#111111]" />
        </div>
      ),
    },
  ];

  return (
    <section id="services" className="w-full py-24 px-4 sm:px-8 bg-[#f2f2f2] text-[#111111]">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between border-b border-[#1e1e1e]/10 pb-6 mb-12">
          <div>
            <div className="text-xs font-satoshi font-bold uppercase tracking-widest text-[#838282] mb-2">
              04 // BESPOKE SERVICES
            </div>
            <h2 className="font-clash font-bold text-3xl sm:text-5xl text-[#111111] tracking-[-0.05em] uppercase">
              Disciplined Capabilities
            </h2>
          </div>
          <div className="mt-4 sm:mt-0 text-xs font-satoshi text-[#838282] uppercase tracking-wider text-right">
            <span>64×64PX ROTATING GEOMETRY</span>
            <br />
            <span>TRANSPARENT → SOLID #FFFFFF HOVER</span>
          </div>
        </div>

        {/* 3-Column Grid of Bespoke Service Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((item) => (
            <div
              key={item.id}
              onClick={() => onServiceClick?.(item.id)}
              className="group relative p-8 sm:p-10 border border-[#1e1e1e]/10 bg-transparent hover:bg-white transition-all duration-300 cursor-pointer flex flex-col justify-between"
            >
              <div>
                {/* Top Row: Index & 64x64px Geometric Icon Container */}
                <div className="flex items-center justify-between mb-8">
                  <span className="font-satoshi text-xs font-bold uppercase tracking-widest text-[#b6b5b5]">
                    {item.kicker}
                  </span>

                  {/* 64x64px geometric icon container that rotates 12 degrees on hover */}
                  <div className="w-16 h-16 border border-[#1e1e1e] flex items-center justify-center transition-transform duration-500 group-hover:rotate-12 bg-transparent">
                    {item.shape}
                  </div>
                </div>

                {/* Card Title in Clash Display */}
                <h3 className="font-clash font-bold text-2xl sm:text-3xl text-[#111111] tracking-[-0.03em] mb-4">
                  {item.title}
                </h3>

                {/* Card Description in Satoshi */}
                <p className="font-satoshi font-light text-sm text-[#838282] leading-relaxed">
                  {item.description}
                </p>
              </div>

              {/* Bottom CTA with ArrowRight and tracking-wide bold Satoshi */}
              <div className="pt-8 border-t border-[#1e1e1e]/10 mt-8 flex items-center justify-between">
                <span className="font-satoshi font-bold text-xs uppercase tracking-widest text-[#111111]">
                  {item.cta}
                </span>
                <div className="w-8 h-8 rounded-full border border-[#111111] flex items-center justify-center transition-transform duration-300 group-hover:translate-x-1 group-hover:bg-[#111111] group-hover:text-white">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
