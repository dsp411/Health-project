'use client';

import React from 'react';
import Image from 'next/image';

interface AsymmetricalShowcaseProps {
  onCardSelect?: (title: string) => void;
}

export default function AsymmetricalShowcase({ onCardSelect }: AsymmetricalShowcaseProps) {
  return (
    <section id="showcase" className="w-full py-24 px-4 sm:px-8 bg-[#f2f2f2] text-[#111111]">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between border-b border-[#1e1e1e]/10 pb-6 mb-12">
          <div>
            <div className="text-xs font-satoshi font-bold uppercase tracking-widest text-[#838282] mb-2">
              03 // ASYMMETRICAL SHOWCASE
            </div>
            <h2 className="font-clash font-bold text-3xl sm:text-5xl text-[#111111] tracking-[-0.05em] uppercase">
              Curated Form &amp; Space
            </h2>
          </div>
          <div className="mt-4 sm:mt-0 text-xs font-satoshi text-[#838282] uppercase tracking-wider text-right">
            <span>12-COLUMN ASYMMETRIC MATRIX</span>
            <br />
            <span>20% GRAYSCALE → 100% COLOR REVEAL</span>
          </div>
        </div>

        {/* 12-Column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          {/* Item 1: Large 8-column rectangular card with rounded-sm corners */}
          <div
            onClick={() => onCardSelect?.('01 / Brutalist Cantilever Monolith')}
            className="md:col-span-8 group relative rounded-sm overflow-hidden bg-[#e5e5e5] border border-[#1e1e1e]/10 cursor-pointer h-[420px] sm:h-[480px]"
          >
            <div className="relative w-full h-full overflow-hidden">
              <Image
                src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=1600&auto=format&fit=crop"
                alt="Brutalist architectural cantilever monolith"
                fill
                sizes="(max-width: 768px) 100vw, 66vw"
                referrerPolicy="no-referrer"
                className="object-cover filter grayscale-[0.2] transition-all duration-[700ms] ease-[cubic-bezier(0.77,0,0.175,1)] group-hover:grayscale-0 group-hover:scale-105"
              />
            </div>
            {/* Card Content Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex flex-col justify-end p-6 sm:p-8 text-white pointer-events-none">
              <span className="font-satoshi text-[11px] uppercase tracking-widest text-white/70 mb-1">
                EXHIBIT // 01 · 8-COLUMN RECTANGLE
              </span>
              <h3 className="font-clash font-bold text-xl sm:text-2xl tracking-[-0.03em] uppercase">
                Brutalist Cantilever Monolith
              </h3>
            </div>
          </div>

          {/* Item 2: Vertical 4-column pill-shaped card (full border-radius 9999px, height 500px) */}
          <div
            onClick={() => onCardSelect?.('02 / Vertical Monograph')}
            className="md:col-span-4 group relative h-[500px] rounded-full overflow-hidden bg-[#e5e5e5] border border-[#1e1e1e]/15 cursor-pointer shadow-sm mx-auto w-full max-w-[340px] md:max-w-none"
          >
            <div className="relative w-full h-full overflow-hidden rounded-full">
              <Image
                src="https://images.unsplash.com/photo-1513694203232-719a280e022f?q=80&w=900&auto=format&fit=crop"
                alt="Pill-shaped vertical architectural composition"
                fill
                sizes="(max-width: 768px) 100vw, 33vw"
                referrerPolicy="no-referrer"
                className="object-cover filter grayscale-[0.2] transition-all duration-[700ms] ease-[cubic-bezier(0.77,0,0.175,1)] group-hover:grayscale-0 group-hover:scale-105"
              />
            </div>

            {/* Special Component: Centered Circular Hover Overlay */}
            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-[700ms] ease-[cubic-bezier(0.77,0,0.175,1)] pointer-events-none p-4">
              <div className="w-32 h-32 rounded-full border border-white/80 bg-black/60 backdrop-blur-md flex flex-col items-center justify-center p-3 text-center text-white shadow-xl transition-transform duration-500 group-hover:scale-100 scale-90">
                <span className="font-satoshi text-[9px] uppercase tracking-widest text-[#d9d9d9] mb-0.5">
                  SERIES // 04
                </span>
                <span className="font-clash font-bold text-xs uppercase tracking-tight text-white">
                  PILL ARCHIVE
                </span>
                <span className="font-satoshi text-[8px] tracking-wide text-[#bfbfbf] mt-1 border-t border-white/20 pt-1">
                  1:2.4 RATIO
                </span>
              </div>
            </div>

            {/* Bottom Caption Pill */}
            <div className="absolute bottom-6 inset-x-0 text-center pointer-events-none">
              <span className="inline-block px-3 py-1 bg-black/50 backdrop-blur-sm text-white text-[10px] font-satoshi uppercase tracking-widest rounded-full border border-white/20">
                02 // PILL CONTAINER (500PX)
              </span>
            </div>
          </div>

          {/* Item 3: Circular 5-column aspect-square image */}
          <div
            onClick={() => onCardSelect?.('03 / Radial Concrete Spiral')}
            className="md:col-span-5 group relative aspect-square rounded-full overflow-hidden bg-[#e5e5e5] border border-[#1e1e1e]/15 cursor-pointer shadow-sm mx-auto w-full max-w-[380px] md:max-w-none"
          >
            <div className="relative w-full h-full overflow-hidden rounded-full">
              <Image
                src="https://images.unsplash.com/photo-1518780664697-55e3ad937233?q=80&w=1000&auto=format&fit=crop"
                alt="Radial concrete geometry spiral"
                fill
                sizes="(max-width: 768px) 100vw, 40vw"
                referrerPolicy="no-referrer"
                className="object-cover filter grayscale-[0.2] transition-all duration-[700ms] ease-[cubic-bezier(0.77,0,0.175,1)] group-hover:grayscale-0 group-hover:scale-105"
              />
            </div>
            {/* Subtle Center Emblem */}
            <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors duration-500 flex flex-col items-center justify-center p-6 text-center text-white pointer-events-none">
              <div className="px-4 py-2 bg-black/60 backdrop-blur-sm rounded-full border border-white/20 text-center">
                <span className="font-satoshi text-[10px] uppercase tracking-widest text-[#bfbfbf] block">
                  03 // 5-COL ASPECT SQUARE
                </span>
                <span className="font-clash font-bold text-sm tracking-tight uppercase">
                  RADIAL OCULUS
                </span>
              </div>
            </div>
          </div>

          {/* Item 4: Wide 7-column rectangle */}
          <div
            onClick={() => onCardSelect?.('04 / Horizon Longitudinal Pavilion')}
            className="md:col-span-7 group relative rounded-sm overflow-hidden bg-[#e5e5e5] border border-[#1e1e1e]/10 cursor-pointer h-[340px] sm:h-[400px]"
          >
            <div className="relative w-full h-full overflow-hidden">
              <Image
                src="https://images.unsplash.com/photo-1506157786151-b8491531f063?q=80&w=1600&auto=format&fit=crop"
                alt="Wide longitudinal pavilion architectural space"
                fill
                sizes="(max-width: 768px) 100vw, 58vw"
                referrerPolicy="no-referrer"
                className="object-cover filter grayscale-[0.2] transition-all duration-[700ms] ease-[cubic-bezier(0.77,0,0.175,1)] group-hover:grayscale-0 group-hover:scale-105"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex flex-col justify-end p-6 sm:p-8 text-white pointer-events-none">
              <span className="font-satoshi text-[11px] uppercase tracking-widest text-white/70 mb-1">
                EXHIBIT // 04 · 7-COLUMN HORIZON
              </span>
              <h3 className="font-clash font-bold text-xl sm:text-2xl tracking-[-0.03em] uppercase">
                Longitudinal Brutalist Pavilion
              </h3>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
