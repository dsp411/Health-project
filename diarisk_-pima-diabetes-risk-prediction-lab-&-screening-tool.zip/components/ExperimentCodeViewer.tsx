'use client';

import React, { useState } from 'react';
import {
  Code2,
  Terminal,
  Copy,
  Check,
  Download,
  BookOpen,
  Layers,
  FileCode,
  Sparkles,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { EXPERIMENT_CODES, ExperimentNotebookCode } from '@/lib/experimentCodes';

interface ExperimentCodeModalProps {
  experimentId: number;
}

export default function ExperimentCodeViewer({ experimentId }: ExperimentCodeModalProps) {
  const [activeTab, setActiveTab] = useState<'code' | 'output' | 'theory'>('code');
  const [copiedCode, setCopiedCode] = useState(false);
  const [isExpanded, setIsExpanded] = useState(true);

  const expData: ExperimentNotebookCode | undefined = EXPERIMENT_CODES[experimentId];

  if (!expData) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(expData.code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([expData.code], { type: 'text/x-python;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = expData.filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="rounded-[22px] border border-[#d6d6d6] dark:border-neutral-800 bg-white dark:bg-[#161618] shadow-xs overflow-hidden mt-6 transition-all">
      {/* Header Bar */}
      <div className="px-5 py-4 bg-[#fbfbfd] dark:bg-[#1a1a1c] border-b border-[#e5e5ea] dark:border-neutral-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-[12px] bg-[#0071e3]/10 text-[#0071e3] flex items-center justify-center">
            <FileCode className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-[#0071e3]/10 text-[#0071e3] font-semibold">
                {expData.filename}
              </span>
              <span className="text-[11px] text-[#86868b]">
                {expData.author} ({expData.studentId})
              </span>
            </div>
            <h3 className="text-[15px] font-semibold text-[#1d1d1f] dark:text-white mt-0.5">
              Experiment {expData.id} Complete Notebook Code & Execution Output
            </h3>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Tabs */}
          <div className="flex items-center bg-[#ededf0] dark:bg-[#2c2c2e] p-1 rounded-[10px]">
            <button
              onClick={() => {
                setActiveTab('code');
                setIsExpanded(true);
              }}
              className={`px-3 py-1 rounded-[8px] text-[12px] font-medium transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'code'
                  ? 'bg-white dark:bg-[#1c1c1e] text-[#1d1d1f] dark:text-white shadow-2xs font-semibold'
                  : 'text-[#707070] dark:text-[#86868b] hover:text-[#1d1d1f]'
              }`}
            >
              <Code2 className="h-3.5 w-3.5" />
              <span>Python Code</span>
            </button>
            <button
              onClick={() => {
                setActiveTab('output');
                setIsExpanded(true);
              }}
              className={`px-3 py-1 rounded-[8px] text-[12px] font-medium transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'output'
                  ? 'bg-white dark:bg-[#1c1c1e] text-[#1d1d1f] dark:text-white shadow-2xs font-semibold'
                  : 'text-[#707070] dark:text-[#86868b] hover:text-[#1d1d1f]'
              }`}
            >
              <Terminal className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>Terminal Output</span>
            </button>
            <button
              onClick={() => {
                setActiveTab('theory');
                setIsExpanded(true);
              }}
              className={`px-3 py-1 rounded-[8px] text-[12px] font-medium transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'theory'
                  ? 'bg-white dark:bg-[#1c1c1e] text-[#1d1d1f] dark:text-white shadow-2xs font-semibold'
                  : 'text-[#707070] dark:text-[#86868b] hover:text-[#1d1d1f]'
              }`}
            >
              <BookOpen className="h-3.5 w-3.5 text-[#0071e3]" />
              <span>Aim & Theory</span>
            </button>
          </div>

          <button
            onClick={handleCopy}
            className="p-2 rounded-[10px] text-[12px] text-[#707070] dark:text-[#86868b] hover:text-[#1d1d1f] dark:hover:text-white bg-[#ededf0] dark:bg-[#2c2c2e] hover:bg-[#e1e1e6] transition flex items-center gap-1.5 cursor-pointer font-medium"
            title="Copy Python Code"
          >
            {copiedCode ? <Check className="h-4 w-4 text-emerald-600" /> : <Copy className="h-4 w-4" />}
            <span className="hidden sm:inline">{copiedCode ? 'Copied' : 'Copy'}</span>
          </button>

          <button
            onClick={handleDownload}
            className="p-2 rounded-[10px] text-[12px] text-[#707070] dark:text-[#86868b] hover:text-[#1d1d1f] dark:hover:text-white bg-[#ededf0] dark:bg-[#2c2c2e] hover:bg-[#e1e1e6] transition flex items-center gap-1.5 cursor-pointer font-medium"
            title="Download .py file"
          >
            <Download className="h-4 w-4" />
            <span className="hidden sm:inline">Download</span>
          </button>

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-2 rounded-[10px] text-[#707070] dark:text-[#86868b] hover:text-[#1d1d1f] dark:hover:text-white bg-[#ededf0] dark:bg-[#2c2c2e] transition cursor-pointer"
            title={isExpanded ? 'Collapse' : 'Expand'}
          >
            {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {/* Expandable Content Area */}
      {isExpanded && (
        <div>
          {/* Tab 1: Python Code */}
          {activeTab === 'code' && (
            <div className="relative bg-[#1e1e22] text-[#e6e6e8]">
              <div className="flex items-center justify-between px-4 py-2 border-b border-[#2d2d32] text-[11px] font-mono text-[#86868b]">
                <span>Python 3 Jupyter Notebook Cell (paste and run)</span>
                <span>Imports: {expData.libraries.join(', ')}</span>
              </div>
              <pre className="p-4 sm:p-5 text-[12px] font-mono leading-relaxed overflow-x-auto max-h-[460px] overflow-y-auto selection:bg-[#0071e3]/30">
                <code>{expData.code}</code>
              </pre>
            </div>
          )}

          {/* Tab 2: Terminal Output */}
          {activeTab === 'output' && (
            <div className="bg-[#0f1115] text-emerald-400 p-4 sm:p-5 font-mono text-[12px] leading-relaxed overflow-x-auto max-h-[460px] overflow-y-auto">
              <div className="flex items-center gap-2 pb-3 mb-3 border-b border-emerald-900/40 text-[11px] text-emerald-500 font-semibold uppercase tracking-wider">
                <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>Execution Logs from Single-Run Cell</span>
              </div>
              <pre className="whitespace-pre font-mono">{expData.terminalOutput}</pre>
            </div>
          )}

          {/* Tab 3: Aim & Theory */}
          {activeTab === 'theory' && (
            <div className="p-6 space-y-5 bg-white dark:bg-[#161618] text-[#1d1d1f] dark:text-neutral-200">
              <div className="space-y-2">
                <h4 className="text-[12px] font-bold text-[#707070] dark:text-[#86868b] uppercase tracking-wider">
                  Aim of the Experiment
                </h4>
                <p className="text-[14px] leading-relaxed">{expData.aim}</p>
              </div>

              <div className="space-y-2">
                <h4 className="text-[12px] font-bold text-[#707070] dark:text-[#86868b] uppercase tracking-wider">
                  Theoretical Foundations
                </h4>
                <p className="text-[14px] leading-relaxed text-[#505054] dark:text-neutral-300">{expData.theory}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                <div className="p-4 rounded-[16px] bg-[#f5f5f7] dark:bg-[#202024] border border-[#e5e5ea] dark:border-neutral-800">
                  <span className="text-[11px] font-bold text-[#707070] dark:text-[#86868b] uppercase tracking-wider block mb-1">
                    Input Artifacts
                  </span>
                  <p className="text-[13px] text-[#1d1d1f] dark:text-neutral-200">{expData.inputs}</p>
                </div>
                <div className="p-4 rounded-[16px] bg-[#f5f5f7] dark:bg-[#202024] border border-[#e5e5ea] dark:border-neutral-800">
                  <span className="text-[11px] font-bold text-[#707070] dark:text-[#86868b] uppercase tracking-wider block mb-1">
                    Output Deliverables
                  </span>
                  <p className="text-[13px] text-[#1d1d1f] dark:text-neutral-200">{expData.outputsSummary}</p>
                </div>
              </div>

              {/* Key Insights Pills */}
              <div className="space-y-2 pt-2">
                <h4 className="text-[12px] font-bold text-[#707070] dark:text-[#86868b] uppercase tracking-wider">
                  Key Findings & Decisions
                </h4>
                <div className="space-y-1.5">
                  {expData.keyInsights.map((insight, idx) => (
                    <div
                      key={idx}
                      className="flex items-start gap-2.5 text-[13px] text-[#1d1d1f] dark:text-neutral-200"
                    >
                      <span className="h-5 w-5 rounded-full bg-[#0071e3]/10 text-[#0071e3] flex items-center justify-center shrink-0 text-[11px] font-bold mt-0.5">
                        {idx + 1}
                      </span>
                      <span>{insight}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
