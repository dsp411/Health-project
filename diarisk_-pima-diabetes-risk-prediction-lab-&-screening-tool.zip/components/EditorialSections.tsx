'use client';

import React from 'react';
import { ArrowRight, ArrowDown } from 'lucide-react';
import TypographicEcho from './TypographicEcho';

interface EditorialSectionsProps {
  onSelectPersona?: (personaId: 'low' | 'moderate' | 'high' | 'gestational') => void;
  onNavigateToLab?: (expId: number) => void;
  onScrollToScreener?: () => void;
  currentRiskScore?: number;
  currentRiskTier?: string;
}

export default function EditorialSections({
  onSelectPersona,
  onScrollToScreener,
  currentRiskScore = 32,
  currentRiskTier = 'LOW',
}: EditorialSectionsProps) {
  return (
    <div className="w-full">
      {/* =========================================================================
          HERO SECTION (Pure typographic weight, Echo Stack, minimal whitespace)
          ========================================================================= */}
      <section className="relative min-h-[70vh] lg:min-h-[80vh] w-full flex flex-col justify-center items-center px-6 sm:px-10 lg:px-16 py-20 border-b border-[#1e1e1e]/10 bg-[#f2f2f2] text-center">
        <div className="max-w-4xl mx-auto flex flex-col items-center">
          <span className="text-[11px] font-mono uppercase tracking-[0.3em] text-[#838282] mb-6">
            Clinical Decision Support System
          </span>

          <TypographicEcho
            text="PREDICTION"
            sizeClass="text-[13vw] sm:text-[11vw] lg:text-[160px] leading-[0.88] tracking-[-0.05em]"
          />

          <p className="mt-8 max-w-xl text-center text-sm sm:text-base font-satoshi text-[#838282] leading-relaxed">
            A Swiss-calibrated machine learning architecture trained on 768 multi-center biometric records. 
            Engineered to detect early metabolic transitions in primary care triage.
          </p>

          <div className="mt-10">
            <button
              onClick={onScrollToScreener}
              className="group inline-flex items-center gap-3 rounded-full border border-[#111111] bg-[#111111] px-8 py-3.5 text-xs uppercase font-satoshi font-bold tracking-widest text-[#f2f2f2] transition-all duration-300 hover:bg-transparent hover:text-[#111111] cursor-pointer"
            >
              <span>Begin Assessment</span>
              <ArrowDown className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-y-0.5" />
            </button>
          </div>
        </div>
      </section>

      {/* =========================================================================
          PHILOSOPHY / NARRATIVE SECTION
          ========================================================================= */}
      <section className="relative w-full py-28 px-6 sm:px-10 lg:px-16 border-b border-[#1e1e1e]/10 bg-[#f2f2f2]">
        <div className="max-w-4xl mx-auto text-center">
          {/* Vertical hairline divider */}
          <div className="w-px h-16 bg-[#1e1e1e]/15 mx-auto mb-12" />

          {/* Large-scale quote with contrasting serif italic keyword */}
          <blockquote className="font-clash text-3xl sm:text-5xl lg:text-6xl font-bold text-[#111111] leading-[1.08] tracking-tight">
            “Metabolic risk is not an unforeseen fate—it is a{' '}
            <span className="font-serif-italic font-normal text-[#111111] underline decoration-1 underline-offset-8">
              measurable
            </span>{' '}
            trajectory calibrated through precision clinical intelligence.”
          </blockquote>

          {/* 3-column minimal informational grid */}
          <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-10 text-left border-t border-[#1e1e1e]/10 pt-12">
            <div>
              <span className="font-mono text-[11px] text-[#838282] block mb-2">01 / SENSITIVITY</span>
              <h3 className="font-clash text-lg font-bold text-[#111111] mb-2 tracking-tight">
                Recall Prioritization
              </h3>
              <p className="font-satoshi text-xs sm:text-sm text-[#838282] leading-relaxed">
                Optimized loss function to prevent false negatives in early prediabetes.
              </p>
            </div>

            <div className="border-t md:border-t-0 md:border-l border-[#1e1e1e]/10 pt-6 md:pt-0 md:pl-8">
              <span className="font-mono text-[11px] text-[#838282] block mb-2">02 / PHYSIOLOGY</span>
              <h3 className="font-clash text-lg font-bold text-[#111111] mb-2 tracking-tight">
                Zero-Imputation
              </h3>
              <p className="font-satoshi text-xs sm:text-sm text-[#838282] leading-relaxed">
                Distribution-aware medians for biological zero serum insulin values.
              </p>
            </div>

            <div className="border-t md:border-t-0 md:border-l border-[#1e1e1e]/10 pt-6 md:pt-0 md:pl-8">
              <span className="font-mono text-[11px] text-[#838282] block mb-2">03 / THRESHOLD</span>
              <h3 className="font-clash text-lg font-bold text-[#111111] mb-2 tracking-tight">
                0.45 ROC Cutoff
              </h3>
              <p className="font-satoshi text-xs sm:text-sm text-[#838282] leading-relaxed">
                Calibrated operating point for rapid primary care lifestyle intervention.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================================
          ASYMMETRICAL SHOWCASE GRID
          ========================================================================= */}
      <section className="w-full py-24 px-6 sm:px-10 lg:px-16 border-b border-[#1e1e1e]/10 bg-[#f2f2f2]">
        <div className="max-w-7xl mx-auto">
          <div className="mb-14">
            <span className="text-[11px] uppercase font-mono tracking-widest text-[#838282] block mb-2">
              System Architecture
            </span>
            <h2 className="font-clash text-3xl sm:text-4xl font-bold text-[#111111] tracking-tight">
              Calibrated Biometric Matrix
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* 1. Large 8-column rectangular card */}
            <div className="lg:col-span-8 group rounded-xs border border-[#1e1e1e]/15 bg-[#ffffff] p-8 sm:p-10 transition-all duration-700 ease-[cubic-bezier(0.77,0,0.175,1)]">
              <div className="flex items-center justify-between border-b border-[#1e1e1e]/10 pb-4 mb-6">
                <span className="font-mono text-xs uppercase tracking-wider text-[#838282]">
                  Model Benchmark · XGBoost
                </span>
                <span className="font-mono text-xs text-[#838282]">Stratified 5-Fold</span>
              </div>

              <div className="grid grid-cols-3 gap-6 mb-8 text-center sm:text-left">
                <div>
                  <span className="block text-[11px] uppercase tracking-wider text-[#838282]">Accuracy</span>
                  <span className="font-clash text-3xl font-bold text-[#111111] mt-1 block">82.6%</span>
                </div>
                <div>
                  <span className="block text-[11px] uppercase tracking-wider text-[#838282]">Recall</span>
                  <span className="font-clash text-3xl font-bold text-[#111111] mt-1 block">91.8%</span>
                </div>
                <div>
                  <span className="block text-[11px] uppercase tracking-wider text-[#838282]">ROC-AUC</span>
                  <span className="font-clash text-3xl font-bold text-[#111111] mt-1 block">0.887</span>
                </div>
              </div>

              <div className="space-y-3 pt-6 border-t border-[#1e1e1e]/10">
                <span className="text-xs font-mono uppercase text-[#838282] block">
                  Top Relative Feature Contributions
                </span>
                <div className="space-y-2">
                  <div>
                    <div className="flex justify-between text-xs font-mono mb-1">
                      <span>Fasting Plasma Glucose</span>
                      <span className="font-bold">34.2%</span>
                    </div>
                    <div className="w-full h-1.5 bg-[#e6e6e6] rounded-xs overflow-hidden">
                      <div className="h-full bg-[#111111]" style={{ width: '34.2%' }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-xs font-mono mb-1">
                      <span>Body Mass Index (BMI)</span>
                      <span className="font-bold">23.8%</span>
                    </div>
                    <div className="w-full h-1.5 bg-[#e6e6e6] rounded-xs overflow-hidden">
                      <div className="h-full bg-[#111111]" style={{ width: '23.8%' }} />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 2. Vertical 4-column pill-shaped card (500px, rounded-full) */}
            <div className="lg:col-span-4 group relative h-[500px] rounded-full border border-[#1e1e1e]/20 bg-[#ffffff] overflow-hidden flex flex-col items-center justify-center p-6 text-center">
              <div className="absolute inset-0 w-full h-full bg-gradient-to-b from-[#e6e6e6] to-[#d6d6d6] showcase-image flex items-center justify-center">
                <div className="flex flex-col items-center justify-center p-6 text-[#111111]">
                  <div className="w-36 h-36 rounded-full border border-[#111111]/30 flex items-center justify-center">
                    <span className="font-clash text-2xl font-bold">768</span>
                  </div>
                  <div className="mt-6 font-clash text-sm font-bold tracking-tight uppercase">
                    Pima Cohort
                  </div>
                  <div className="font-mono text-[11px] text-[#838282]">Biometric Records</div>
                </div>
              </div>

              {/* Center circular overlay on hover */}
              <div className="relative z-10 w-44 h-44 rounded-full border border-[#111111] bg-[#ffffff]/95 backdrop-blur-md p-4 flex flex-col items-center justify-center text-center opacity-0 group-hover:opacity-100 transition-opacity duration-700 ease-[cubic-bezier(0.77,0,0.175,1)]">
                <span className="font-mono text-[9px] uppercase tracking-widest text-[#838282] mb-1">
                  Biometrics
                </span>
                <span className="font-clash text-sm font-bold text-[#111111] uppercase leading-tight mb-2">
                  Clinical Intake
                </span>
                <button
                  onClick={onScrollToScreener}
                  className="text-[10px] font-bold uppercase tracking-wider text-[#111111] underline cursor-pointer"
                >
                  Enter Vitals ↓
                </button>
              </div>
            </div>

            {/* 3. Circular 5-column aspect-square image */}
            <div className="lg:col-span-5 group relative aspect-square rounded-full border border-[#1e1e1e]/20 bg-[#ffffff] overflow-hidden flex flex-col items-center justify-center p-8 text-center">
              <div className="absolute inset-0 w-full h-full bg-[#e8e8e8] showcase-image flex items-center justify-center">
                <div className="relative w-3/4 h-3/4 rounded-full border border-[#111111]/20 flex items-center justify-center">
                  <div className="w-24 h-24 rounded-full bg-[#111111] text-[#f2f2f2] flex flex-col items-center justify-center">
                    <span className="font-clash text-lg font-bold">DSS</span>
                    <span className="text-[9px] font-mono tracking-wider">HEALTH-01</span>
                  </div>
                </div>
              </div>
            </div>

            {/* 4. Wide 7-column rectangle (Instant Persona Triage) */}
            <div className="lg:col-span-7 group rounded-xs border border-[#1e1e1e]/15 bg-[#ffffff] p-8 sm:p-10 transition-all duration-700 ease-[cubic-bezier(0.77,0,0.175,1)]">
              <div className="flex items-center justify-between border-b border-[#1e1e1e]/10 pb-4 mb-6">
                <div>
                  <span className="font-mono text-xs uppercase tracking-wider text-[#838282] block">
                    Patient Archetypes
                  </span>
                  <h3 className="font-clash text-xl font-bold text-[#111111] tracking-tight mt-1">
                    Instant Clinical Injection
                  </h3>
                </div>
                <span className="text-xs font-mono text-[#838282]">
                  Current: {currentRiskTier} ({currentRiskScore}%)
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <button
                  onClick={() => onSelectPersona?.('low')}
                  className="p-3.5 rounded-xs border border-[#1e1e1e]/10 bg-[#f2f2f2] text-left hover:border-[#111111] hover:bg-[#ffffff] transition-colors cursor-pointer"
                >
                  <span className="font-clash text-xs font-bold text-[#111111] block mb-1">Normal Adult</span>
                  <span className="text-[11px] font-mono text-[#838282] block">FPG 88 · BMI 22.4</span>
                </button>

                <button
                  onClick={() => onSelectPersona?.('moderate')}
                  className="p-3.5 rounded-xs border border-[#1e1e1e]/10 bg-[#f2f2f2] text-left hover:border-[#111111] hover:bg-[#ffffff] transition-colors cursor-pointer"
                >
                  <span className="font-clash text-xs font-bold text-[#111111] block mb-1">Pre-Diabetes</span>
                  <span className="text-[11px] font-mono text-[#838282] block">FPG 116 · BMI 29.8</span>
                </button>

                <button
                  onClick={() => onSelectPersona?.('high')}
                  className="p-3.5 rounded-xs border border-[#1e1e1e]/10 bg-[#f2f2f2] text-left hover:border-[#111111] hover:bg-[#ffffff] transition-colors cursor-pointer"
                >
                  <span className="font-clash text-xs font-bold text-[#111111] block mb-1">High Risk</span>
                  <span className="text-[11px] font-mono text-[#838282] block">FPG 168 · BMI 34.5</span>
                </button>
              </div>

              <div className="mt-6 pt-4 border-t border-[#1e1e1e]/10 flex justify-end">
                <button
                  onClick={onScrollToScreener}
                  className="text-xs font-satoshi font-bold text-[#111111] hover:underline flex items-center gap-1.5 cursor-pointer"
                >
                  <span>Open Screening Workspace</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
