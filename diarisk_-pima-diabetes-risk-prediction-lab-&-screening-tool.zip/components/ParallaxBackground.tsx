'use client';

import React from 'react';

export default function ParallaxBackground() {
  return (
    <div
      aria-hidden="true"
      className="fixed inset-0 -z-10 pointer-events-none select-none bg-slate-50 dark:bg-[#0b1120] transition-colors duration-300 print:hidden"
    >
      {/* Subtle clinical micro-grid pattern for hospital portal texture */}
      <div
        className="absolute inset-0 opacity-[0.4] dark:opacity-[0.15]"
        style={{
          backgroundImage:
            'radial-gradient(rgba(15, 23, 42, 0.12) 1px, transparent 1px)',
          backgroundSize: '24px 24px',
        }}
      />
      {/* Soft top gradient wash */}
      <div className="absolute top-0 inset-x-0 h-96 bg-gradient-to-b from-teal-50/50 via-slate-50/20 to-transparent dark:from-teal-950/20 dark:via-transparent dark:to-transparent" />
    </div>
  );
}
