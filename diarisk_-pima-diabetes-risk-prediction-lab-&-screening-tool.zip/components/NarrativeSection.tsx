'use client';

import React from 'react';

export default function NarrativeSection() {
  return (
    <section id="philosophy" className="relative w-full py-28 px-4 sm:px-8 bg-[#f2f2f2] text-[#111111]">
      <div className="max-w-6xl mx-auto flex flex-col items-center">
        {/* Vertical Hairline Divider leading into the section */}
        <div className="w-[1px] h-24 bg-[#1e1e1e]/10 mx-auto mb-12" aria-hidden="true" />

        {/* Section Tag */}
        <div className="mb-6 flex items-center gap-2 text-xs font-satoshi font-semibold uppercase tracking-widest text-[#838282]">
          <span>02 // PHILOSOPHY &amp; NARRATIVE</span>
        </div>

        {/* Large-scale Quote (4xl to 6xl) with contrasting serif italic keyword */}
        <blockquote className="font-clash font-bold text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-center leading-[0.95] tracking-[-0.05em] max-w-4xl text-[#111111] mb-20">
          Form does not merely follow function; form{' '}
          <span className="font-editorial font-normal tracking-tight text-4xl sm:text-5xl md:text-6xl lg:text-7xl lowercase text-[#111111] inline-block mx-1">
            crystallizes
          </span>{' '}
          the uncompromising truth of structure.
        </blockquote>

        {/* 3-Column Informational Grid with 32px gaps */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full border-t border-[#1e1e1e]/10 pt-16">
          {/* Column 1 */}
          <div className="flex flex-col">
            <div className="text-xs font-satoshi font-bold uppercase tracking-wider text-[#b6b5b5] mb-2">
              PILLAR / 01
            </div>
            <h3 className="font-clash font-bold text-2xl text-[#111111] mb-4 tracking-[-0.03em]">
              Monochrome Discipline
            </h3>
            <p className="font-satoshi font-light text-sm sm:text-base text-[#838282] leading-relaxed">
              By rejecting chromatic distraction, every decision is anchored in high-contrast value,
              scale differentials, and calibrated offsets that honor classic Swiss grid principles.
            </p>
          </div>

          {/* Column 2 */}
          <div className="flex flex-col">
            <div className="text-xs font-satoshi font-bold uppercase tracking-wider text-[#b6b5b5] mb-2">
              PILLAR / 02
            </div>
            <h3 className="font-clash font-bold text-2xl text-[#111111] mb-4 tracking-[-0.03em]">
              Typographic Infrastructure
            </h3>
            <p className="font-satoshi font-light text-sm sm:text-base text-[#838282] leading-relaxed">
              Clash Display commands absolute presence through heavy weight and tight negative tracking (-0.05em),
              while Satoshi provides effortless, utilitarian readability for complex datasets.
            </p>
          </div>

          {/* Column 3 */}
          <div className="flex flex-col">
            <div className="text-xs font-satoshi font-bold uppercase tracking-wider text-[#b6b5b5] mb-2">
              PILLAR / 03
            </div>
            <h3 className="font-clash font-bold text-2xl text-[#111111] mb-4 tracking-[-0.03em]">
              Asymmetrical Equilibrium
            </h3>
            <p className="font-satoshi font-light text-sm sm:text-base text-[#838282] leading-relaxed">
              Tension arises when strict modularity meets unexpected aspect ratios. Pill-shaped geometry
              and brutalist cutouts elevate the digital surface into a collectible physical monograph.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
