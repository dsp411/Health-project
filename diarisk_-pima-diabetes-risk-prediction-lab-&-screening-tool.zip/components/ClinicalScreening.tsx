'use client';

import React, { useState, useMemo } from 'react';
import {
  RotateCw,
  Sparkles,
  Printer,
  Copy,
  Check,
  RotateCcw,
  Sliders,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { predictPatientRisk } from '@/lib/mlEngine';
import { ALL_PATIENTS } from '@/lib/pimaRecords';
import RiskGauge from './RiskGauge';

interface ClinicalScreeningProps {
  onOpenLab?: () => void;
  presetPersona?: 'low' | 'moderate' | 'high' | 'gestational';
}

export default function ClinicalScreening({ presetPersona }: ClinicalScreeningProps) {
  // Form State with standard primary care defaults
  const [formData, setFormData] = useState({
    pregnancies: 2,
    glucose: 105,
    bloodPressure: 74,
    skinThickness: 26,
    insulin: 110,
    bmi: 27.2,
    diabetesPedigreeFunction: 0.45,
    age: 42,
  });

  const [activePatientName, setActivePatientName] = useState<string>('Standard Intake');
  const [familyHistoryLevel, setFamilyHistoryLevel] = useState<'none' | 'one' | 'multiple'>('one');
  const [selectedModel, setSelectedModel] = useState<'xgboost' | 'random_forest' | 'logistic_regression'>('xgboost');
  const [decisionThreshold] = useState<number>(0.45);
  const [showAdvanced, setShowAdvanced] = useState<boolean>(false);
  const [showBmiCalculator, setShowBmiCalculator] = useState<boolean>(false);

  // Height/Weight helper state
  const [heightFeet, setHeightFeet] = useState<number>(5);
  const [heightInches, setHeightInches] = useState<number>(9);
  const [weightLbs, setWeightLbs] = useState<number>(185);

  // Gemini AI Consultation state
  const [aiAdvice, setAiAdvice] = useState<any>(null);
  const [aiLoading, setAiLoading] = useState<boolean>(false);

  // Interactive ordered labs checklist
  const [checkedLabs, setCheckedLabs] = useState<Record<string, boolean>>({});
  const [copiedNote, setCopiedNote] = useState<boolean>(false);

  // Run calibrated clinical assessment whenever inputs change
  const assessment = useMemo(() => {
    return predictPatientRisk(formData, selectedModel, decisionThreshold);
  }, [formData, selectedModel, decisionThreshold]);

  // Clinical Personas
  const personas = [
    {
      id: 'low',
      name: 'Normal Adult',
      familyHistory: 'none' as const,
      data: { pregnancies: 1, glucose: 88, bloodPressure: 68, skinThickness: 22, insulin: 75, bmi: 22.4, diabetesPedigreeFunction: 0.18, age: 28 },
    },
    {
      id: 'moderate',
      name: 'Pre-Diabetes',
      familyHistory: 'one' as const,
      data: { pregnancies: 2, glucose: 116, bloodPressure: 76, skinThickness: 28, insulin: 130, bmi: 29.8, diabetesPedigreeFunction: 0.45, age: 46 },
    },
    {
      id: 'high',
      name: 'High Risk',
      familyHistory: 'multiple' as const,
      data: { pregnancies: 4, glucose: 168, bloodPressure: 86, skinThickness: 36, insulin: 210, bmi: 34.5, diabetesPedigreeFunction: 0.85, age: 52 },
    },
    {
      id: 'gestational',
      name: 'Gestational Profile',
      familyHistory: 'one' as const,
      data: { pregnancies: 6, glucose: 138, bloodPressure: 80, skinThickness: 31, insulin: 165, bmi: 31.2, diabetesPedigreeFunction: 0.58, age: 39 },
    },
  ];

  const handleSelectPersona = (p: (typeof personas)[0]) => {
    setFormData(p.data);
    setActivePatientName(p.name);
    setFamilyHistoryLevel(p.familyHistory);
    setAiAdvice(null);
  };

  const handleResetDefaults = () => {
    setFormData({
      pregnancies: 2,
      glucose: 105,
      bloodPressure: 74,
      skinThickness: 26,
      insulin: 110,
      bmi: 27.2,
      diabetesPedigreeFunction: 0.45,
      age: 42,
    });
    setActivePatientName('Standard Intake');
    setFamilyHistoryLevel('one');
    setAiAdvice(null);
  };

  const handleFamilyHistoryChange = (level: 'none' | 'one' | 'multiple') => {
    setFamilyHistoryLevel(level);
    const pedVal = level === 'none' ? 0.18 : level === 'one' ? 0.45 : 0.85;
    setFormData((prev) => ({ ...prev, diabetesPedigreeFunction: pedVal }));
  };

  const handleApplyBmiCalc = () => {
    const totalInches = heightFeet * 12 + heightInches;
    if (totalInches > 0 && weightLbs > 0) {
      const calculatedBmi = (weightLbs / (totalInches * totalInches)) * 703;
      setFormData((prev) => ({ ...prev, bmi: Math.round(calculatedBmi * 10) / 10 }));
      setShowBmiCalculator(false);
    }
  };

  const handleGenerateAiAdvice = async () => {
    if (!assessment) return;
    setAiLoading(true);

    try {
      const res = await fetch('/api/clinical-advice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          vitals: formData,
          assessment: {
            riskTier: assessment.riskLevel,
            probability: assessment.probability,
            diabetesRiskScore: assessment.riskScorePercent,
            confirmatoryUrgency: assessment.confirmatoryUrgency,
            model: selectedModel,
          },
          riskDrivers: assessment.riskDrivers.map((d) => ({
            label: d.label,
            observedValue: d.value,
            clinicalNormal: d.reference,
            pathologicalMechanism: d.note,
          })),
        }),
      });

      if (!res.ok) {
        throw new Error('Clinical consultation service unavailable.');
      }

      const data = await res.json();
      setAiAdvice(data);
      const adviceEl = document.getElementById('consultation-notes');
      if (adviceEl) adviceEl.scrollIntoView({ behavior: 'smooth' });
    } catch {
      // Fallback
      setAiAdvice({
        summary: `Patient presents with ${assessment.riskLevel} risk (${assessment.riskScorePercent}% probability). Fasting plasma glucose observed at ${formData.glucose} mg/dL and BMI at ${formData.bmi} kg/m². Immediate clinical confirmation and structured lifestyle intervention recommended.`,
        confirmatoryPlan: [
          'Confirmatory Fasting Plasma Glucose (FPG) Venous Draw',
          'Standardized Laboratory HbA1c Glycated Hemoglobin Assay',
          'Complete Fasting Lipid Panel (Triglycerides, HDL, LDL)',
        ],
        lifestyleInterventions: [
          '7% body weight reduction through calorie-restricted Mediterranean dietary pattern',
          'Minimum 150 minutes weekly of moderate-intensity aerobic exercise',
          'Continuous biometric surveillance and self-monitoring of blood glucose',
        ],
        clinicalFollowup: `Schedule patient review within ${assessment.confirmatoryUrgency}.`,
        source: 'clinical_protocol',
      });
    } finally {
      setAiLoading(false);
    }
  };

  const handlePrint = () => {
    if (typeof window !== 'undefined') {
      window.print();
    }
  };

  const handleCopyNote = () => {
    if (!assessment) return;
    const note = `METABOLIC INTELLIGENCE · DIABETES CLINICAL TRIAGE REPORT
Date: ${new Date().toLocaleDateString()}
Patient Case: ${activePatientName}
--------------------------------------------------
CALCULATED RISK: ${assessment.riskScorePercent}% (${assessment.riskLevel})
Inference Model: ${assessment.modelUsed}
Triage Action: ${assessment.clinicalAction}
Confirmatory Window: ${assessment.confirmatoryUrgency}

OBSERVED BIOMARKERS:
- Fasting Glucose: ${formData.glucose} mg/dL
- BMI: ${formData.bmi} kg/m²
- Blood Pressure: ${formData.bloodPressure} mm Hg
- Patient Age: ${formData.age} years
- Family History: ${familyHistoryLevel.toUpperCase()}
`;
    navigator.clipboard.writeText(note);
    setCopiedNote(true);
    setTimeout(() => setCopiedNote(false), 2000);
  };

  const toggleLabCheck = (labKey: string) => {
    setCheckedLabs((prev) => ({ ...prev, [labKey]: !prev[labKey] }));
  };

  return (
    <div id="clinical-workspace" className="w-full bg-[#f2f2f2] text-[#111111] py-20 px-6 sm:px-10 lg:px-16">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Workspace Title & Controls */}
        <div className="border-b border-[#1e1e1e]/10 pb-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="text-[11px] font-mono uppercase tracking-widest text-[#838282] block mb-1">
              Assessment Workspace
            </span>
            <h2 className="font-clash text-3xl sm:text-4xl font-bold tracking-tight text-[#111111]">
              Biometric Screener
            </h2>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleResetDefaults}
              className="inline-flex items-center gap-2 text-xs font-mono text-[#838282] hover:text-[#111111] transition-colors cursor-pointer"
            >
              <RotateCcw className="h-3 w-3" />
              <span>Reset</span>
            </button>
          </div>
        </div>

        {/* Archetype Selector (Clean minimal buttons) */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {personas.map((p) => {
            const isActive = activePatientName === p.name;
            return (
              <button
                key={p.id}
                onClick={() => handleSelectPersona(p)}
                className={`text-left p-3.5 rounded-xs border transition-all cursor-pointer ${
                  isActive
                    ? 'border-[#111111] bg-[#111111] text-[#f2f2f2]'
                    : 'border-[#1e1e1e]/10 bg-[#ffffff] hover:border-[#111111] text-[#111111]'
                }`}
              >
                <span className="font-clash text-xs font-bold block">{p.name}</span>
                <span
                  className={`text-[10px] font-mono block mt-1 ${
                    isActive ? 'text-[#f2f2f2]/70' : 'text-[#838282]'
                  }`}
                >
                  FPG {p.data.glucose} · BMI {p.data.bmi}
                </span>
              </button>
            );
          })}
        </div>

        {/* 2-Column Clinical Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Left Column: Biometric Inputs (7 Cols) */}
          <div className="lg:col-span-7 bg-[#ffffff] border border-[#1e1e1e]/15 p-8 sm:p-10 rounded-xs space-y-8">
            {/* Fasting Blood Glucose */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-satoshi font-bold uppercase tracking-wider text-[#111111]">
                  Fasting Glucose (mg/dL)
                </label>
                <span className="text-[11px] font-mono text-[#838282]">
                  Target: &lt;100 mg/dL
                </span>
              </div>

              <div className="flex items-center gap-3">
                <div className="relative flex-1">
                  <input
                    type="number"
                    min={40}
                    max={350}
                    value={formData.glucose}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, glucose: Number(e.target.value) || 0 }))
                    }
                    className="w-full rounded-xs border border-[#1e1e1e]/20 bg-[#f2f2f2] px-4 py-2.5 text-base font-mono font-bold text-[#111111] focus:border-[#111111] focus:bg-[#ffffff] focus:outline-none transition-colors"
                  />
                  <span className="absolute right-3.5 top-2.5 text-xs font-mono text-[#838282]">
                    mg/dL
                  </span>
                </div>

                {/* Fasting Glucose Presets */}
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => setFormData((prev) => ({ ...prev, glucose: 90 }))}
                    className={`px-3 py-2 text-xs font-mono font-semibold rounded-xs border transition-colors cursor-pointer ${
                      formData.glucose === 90
                        ? 'border-[#111111] bg-[#111111] text-[#f2f2f2]'
                        : 'border-[#1e1e1e]/15 bg-[#f2f2f2] hover:bg-[#ffffff] text-[#111111]'
                    }`}
                  >
                    90
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData((prev) => ({ ...prev, glucose: 115 }))}
                    className={`px-3 py-2 text-xs font-mono font-semibold rounded-xs border transition-colors cursor-pointer ${
                      formData.glucose === 115
                        ? 'border-[#111111] bg-[#111111] text-[#f2f2f2]'
                        : 'border-[#1e1e1e]/15 bg-[#f2f2f2] hover:bg-[#ffffff] text-[#111111]'
                    }`}
                  >
                    115
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData((prev) => ({ ...prev, glucose: 150 }))}
                    className={`px-3 py-2 text-xs font-mono font-semibold rounded-xs border transition-colors cursor-pointer ${
                      formData.glucose === 150
                        ? 'border-[#111111] bg-[#111111] text-[#f2f2f2]'
                        : 'border-[#1e1e1e]/15 bg-[#f2f2f2] hover:bg-[#ffffff] text-[#111111]'
                    }`}
                  >
                    150
                  </button>
                </div>
              </div>
            </div>

            {/* Body Mass Index */}
            <div className="space-y-3 pt-6 border-t border-[#1e1e1e]/10">
              <div className="flex items-center justify-between">
                <label className="text-xs font-satoshi font-bold uppercase tracking-wider text-[#111111]">
                  Body Mass Index (BMI)
                </label>
                <button
                  type="button"
                  onClick={() => setShowBmiCalculator(!showBmiCalculator)}
                  className="text-xs font-satoshi text-[#838282] hover:text-[#111111] underline cursor-pointer"
                >
                  {showBmiCalculator ? 'Close Calculator' : 'Height/Weight Helper'}
                </button>
              </div>

              {showBmiCalculator && (
                <div className="p-4 bg-[#f2f2f2] border border-[#1e1e1e]/15 rounded-xs space-y-3">
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="text-[10px] font-mono text-[#838282] block mb-1">Feet</label>
                      <input
                        type="number"
                        value={heightFeet}
                        min={3}
                        max={7}
                        onChange={(e) => setHeightFeet(Number(e.target.value) || 0)}
                        className="w-full bg-[#ffffff] border border-[#1e1e1e]/20 px-3 py-1.5 text-xs font-mono rounded-xs"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-mono text-[#838282] block mb-1">Inches</label>
                      <input
                        type="number"
                        value={heightInches}
                        min={0}
                        max={11}
                        onChange={(e) => setHeightInches(Number(e.target.value) || 0)}
                        className="w-full bg-[#ffffff] border border-[#1e1e1e]/20 px-3 py-1.5 text-xs font-mono rounded-xs"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-mono text-[#838282] block mb-1">Weight (lbs)</label>
                      <input
                        type="number"
                        value={weightLbs}
                        min={60}
                        max={500}
                        onChange={(e) => setWeightLbs(Number(e.target.value) || 0)}
                        className="w-full bg-[#ffffff] border border-[#1e1e1e]/20 px-3 py-1.5 text-xs font-mono rounded-xs"
                      />
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleApplyBmiCalc}
                    className="w-full py-2 bg-[#111111] text-[#f2f2f2] text-xs font-satoshi font-bold uppercase rounded-xs hover:bg-[#333333] transition-colors cursor-pointer"
                  >
                    Apply Calculated BMI
                  </button>
                </div>
              )}

              <div className="relative">
                <input
                  type="number"
                  step="0.1"
                  min={12}
                  max={70}
                  value={formData.bmi}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, bmi: Number(e.target.value) || 0 }))
                  }
                  className="w-full rounded-xs border border-[#1e1e1e]/20 bg-[#f2f2f2] px-4 py-2.5 text-base font-mono font-bold text-[#111111] focus:border-[#111111] focus:bg-[#ffffff] focus:outline-none transition-colors"
                />
                <span className="absolute right-3.5 top-2.5 text-xs font-mono text-[#838282]">
                  kg/m²
                </span>
              </div>
            </div>

            {/* Age & Blood Pressure */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-6 border-t border-[#1e1e1e]/10">
              <div className="space-y-2">
                <label className="text-xs font-satoshi font-bold uppercase tracking-wider text-[#111111] block">
                  Patient Age
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min={18}
                    max={95}
                    value={formData.age}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, age: Number(e.target.value) || 0 }))
                    }
                    className="w-full rounded-xs border border-[#1e1e1e]/20 bg-[#f2f2f2] px-4 py-2 text-base font-mono font-bold text-[#111111] focus:border-[#111111] focus:bg-[#ffffff] focus:outline-none transition-colors"
                  />
                  <span className="absolute right-3.5 top-2 text-xs font-mono text-[#838282]">
                    yrs
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-satoshi font-bold uppercase tracking-wider text-[#111111] block">
                  Blood Pressure
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min={40}
                    max={140}
                    value={formData.bloodPressure}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        bloodPressure: Number(e.target.value) || 0,
                      }))
                    }
                    className="w-full rounded-xs border border-[#1e1e1e]/20 bg-[#f2f2f2] px-4 py-2 text-base font-mono font-bold text-[#111111] focus:border-[#111111] focus:bg-[#ffffff] focus:outline-none transition-colors"
                  />
                  <span className="absolute right-3.5 top-2 text-xs font-mono text-[#838282]">
                    mm Hg
                  </span>
                </div>
              </div>
            </div>

            {/* Family History */}
            <div className="space-y-3 pt-6 border-t border-[#1e1e1e]/10">
              <label className="text-xs font-satoshi font-bold uppercase tracking-wider text-[#111111] block">
                Family History
              </label>
              <div className="grid grid-cols-3 gap-3">
                <button
                  type="button"
                  onClick={() => handleFamilyHistoryChange('none')}
                  className={`p-3 text-left rounded-xs border transition-all cursor-pointer ${
                    familyHistoryLevel === 'none'
                      ? 'border-[#111111] bg-[#111111] text-[#f2f2f2]'
                      : 'border-[#1e1e1e]/15 bg-[#f2f2f2] hover:bg-[#ffffff] text-[#111111]'
                  }`}
                >
                  <span className="font-clash text-xs font-bold block">None</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleFamilyHistoryChange('one')}
                  className={`p-3 text-left rounded-xs border transition-all cursor-pointer ${
                    familyHistoryLevel === 'one'
                      ? 'border-[#111111] bg-[#111111] text-[#f2f2f2]'
                      : 'border-[#1e1e1e]/15 bg-[#f2f2f2] hover:bg-[#ffffff] text-[#111111]'
                  }`}
                >
                  <span className="font-clash text-xs font-bold block">1 Relative</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleFamilyHistoryChange('multiple')}
                  className={`p-3 text-left rounded-xs border transition-all cursor-pointer ${
                    familyHistoryLevel === 'multiple'
                      ? 'border-[#111111] bg-[#111111] text-[#f2f2f2]'
                      : 'border-[#1e1e1e]/15 bg-[#f2f2f2] hover:bg-[#ffffff] text-[#111111]'
                  }`}
                >
                  <span className="font-clash text-xs font-bold block">Multiple</span>
                </button>
              </div>
            </div>

            {/* Collapsible Secondary Labs Drawer */}
            <div className="pt-4 border-t border-[#1e1e1e]/10">
              <button
                type="button"
                onClick={() => setShowAdvanced(!showAdvanced)}
                className="w-full flex items-center justify-between text-xs font-satoshi font-bold uppercase tracking-wider text-[#111111] hover:text-[#838282] transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <Sliders className="h-3.5 w-3.5" />
                  <span>Secondary Labs &amp; Model</span>
                </div>
                {showAdvanced ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
              </button>

              {showAdvanced && (
                <div className="mt-6 space-y-6 p-5 bg-[#f2f2f2] border border-[#1e1e1e]/15 rounded-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="text-[10px] font-mono text-[#838282] block mb-1">
                        Serum Insulin (μU/mL)
                      </label>
                      <input
                        type="number"
                        value={formData.insulin}
                        onChange={(e) =>
                          setFormData((prev) => ({ ...prev, insulin: Number(e.target.value) || 0 }))
                        }
                        className="w-full bg-[#ffffff] border border-[#1e1e1e]/20 px-3 py-1.5 text-xs font-mono rounded-xs"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-mono text-[#838282] block mb-1">
                        Triceps Skinfold (mm)
                      </label>
                      <input
                        type="number"
                        value={formData.skinThickness}
                        onChange={(e) =>
                          setFormData((prev) => ({
                            ...prev,
                            skinThickness: Number(e.target.value) || 0,
                          }))
                        }
                        className="w-full bg-[#ffffff] border border-[#1e1e1e]/20 px-3 py-1.5 text-xs font-mono rounded-xs"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-mono text-[#838282] block mb-1">
                        Pregnancies
                      </label>
                      <input
                        type="number"
                        min={0}
                        max={17}
                        value={formData.pregnancies}
                        onChange={(e) =>
                          setFormData((prev) => ({
                            ...prev,
                            pregnancies: Number(e.target.value) || 0,
                          }))
                        }
                        className="w-full bg-[#ffffff] border border-[#1e1e1e]/20 px-3 py-1.5 text-xs font-mono rounded-xs"
                      />
                    </div>
                  </div>

                  {/* Model Switcher */}
                  <div className="pt-4 border-t border-[#1e1e1e]/10">
                    <label className="text-xs font-satoshi font-bold uppercase tracking-wider text-[#111111] block mb-2">
                      Inference Engine
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {(['xgboost', 'random_forest', 'logistic_regression'] as const).map((m) => (
                        <button
                          key={m}
                          type="button"
                          onClick={() => setSelectedModel(m)}
                          className={`p-2 text-center text-xs font-mono uppercase rounded-xs border transition-all cursor-pointer ${
                            selectedModel === m
                              ? 'border-[#111111] bg-[#111111] text-[#f2f2f2] font-bold'
                              : 'border-[#1e1e1e]/15 bg-[#ffffff] text-[#838282] hover:text-[#111111]'
                          }`}
                        >
                          {m === 'xgboost'
                            ? 'XGBoost'
                            : m === 'random_forest'
                            ? 'Random Forest'
                            : 'Logistic Reg'}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Sticky Real-time Diagnostic Summary (5 Cols) */}
          <div className="lg:col-span-5 bg-[#ffffff] border border-[#1e1e1e]/15 p-8 rounded-xs space-y-6 lg:sticky lg:top-24">
            <div className="flex items-center justify-between border-b border-[#1e1e1e]/10 pb-4">
              <span className="font-clash text-base font-bold uppercase tracking-tight text-[#111111]">
                Assessment
              </span>
              <span className="font-mono text-xs text-[#838282] uppercase">
                {assessment.riskLevel} TIER
              </span>
            </div>

            {/* Calibrated Risk Gauge */}
            <div className="py-2">
              <RiskGauge
                score={assessment.riskScorePercent}
                probability={assessment.probability}
                threshold={decisionThreshold}
                riskLevel={assessment.riskLevel}
                urgency={assessment.confirmatoryUrgency}
              />
            </div>

            <div className="p-4 bg-[#f2f2f2] rounded-xs space-y-2 text-xs font-mono">
              <div className="flex justify-between">
                <span className="text-[#838282]">Timeline:</span>
                <span className="font-bold text-[#111111]">{assessment.confirmatoryUrgency}</span>
              </div>
              <div className="text-xs font-satoshi text-[#838282] pt-2 border-t border-[#1e1e1e]/10 leading-relaxed">
                {assessment.clinicalAction}
              </div>
            </div>

            {/* Top Physiological Risk Drivers */}
            <div className="space-y-2">
              <span className="text-xs font-satoshi font-bold uppercase tracking-wider text-[#111111] block">
                Primary Drivers
              </span>
              <div className="space-y-1.5">
                {assessment.riskDrivers.slice(0, 3).map((driver, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-[#f2f2f2] rounded-xs flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-clash font-bold text-[#111111]">{driver.label}</span>
                    </div>
                    <span className="font-mono text-xs font-bold text-[#111111]">{driver.value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2.5 pt-2">
              <button
                type="button"
                onClick={handleGenerateAiAdvice}
                disabled={aiLoading}
                className="w-full py-3 bg-[#111111] text-[#f2f2f2] text-xs uppercase font-satoshi font-bold tracking-wider rounded-xs hover:bg-[#333333] transition-colors flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {aiLoading ? (
                  <>
                    <RotateCw className="h-3.5 w-3.5 animate-spin" />
                    <span>Synthesizing...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="h-3.5 w-3.5" />
                    <span>Generate Clinical Memo</span>
                  </>
                )}
              </button>

              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={handlePrint}
                  className="py-2.5 bg-[#ffffff] border border-[#111111] text-[#111111] text-xs uppercase font-satoshi font-bold tracking-wider rounded-xs hover:bg-[#111111] hover:text-[#f2f2f2] transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Printer className="h-3.5 w-3.5" />
                  <span>Print Report</span>
                </button>

                <button
                  type="button"
                  onClick={handleCopyNote}
                  className="py-2.5 bg-[#f2f2f2] border border-[#1e1e1e]/20 text-[#111111] text-xs uppercase font-satoshi font-bold tracking-wider rounded-xs hover:bg-[#ffffff] transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  {copiedNote ? (
                    <>
                      <Check className="h-3.5 w-3.5 text-emerald-600" />
                      <span>Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="h-3.5 w-3.5" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Consultation Memo (when generated) */}
        {aiAdvice && (
          <div
            id="consultation-notes"
            className="bg-[#ffffff] border border-[#111111] p-8 sm:p-10 rounded-xs space-y-6"
          >
            <div className="border-b border-[#1e1e1e]/10 pb-4 flex items-center justify-between">
              <h3 className="font-clash text-xl font-bold uppercase tracking-tight text-[#111111]">
                Clinical Consultation Memo
              </h3>
              <span className="text-[11px] font-mono text-[#838282]">
                ADA Protocol
              </span>
            </div>

            <p className="font-satoshi text-xs sm:text-sm text-[#111111] leading-relaxed">
              {aiAdvice.summary}
            </p>

            <div className="space-y-3">
              <span className="text-xs font-satoshi font-bold uppercase tracking-wider text-[#111111] block">
                Recommended Lab Orders
              </span>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {aiAdvice.confirmatoryPlan?.map((planItem: string, idx: number) => {
                  const isChecked = !!checkedLabs[`lab_${idx}`];
                  return (
                    <div
                      key={idx}
                      onClick={() => toggleLabCheck(`lab_${idx}`)}
                      className={`p-3.5 rounded-xs border transition-colors cursor-pointer text-xs font-satoshi ${
                        isChecked
                          ? 'border-[#111111] bg-[#111111] text-[#f2f2f2]'
                          : 'border-[#1e1e1e]/15 bg-[#f2f2f2] hover:bg-[#ffffff] text-[#111111]'
                      }`}
                    >
                      {planItem}
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="pt-4 border-t border-[#1e1e1e]/10 text-xs font-satoshi text-[#838282]">
              {aiAdvice.clinicalFollowup}
            </div>
          </div>
        )}

        {/* Print-Only Letterhead */}
        <div className="hidden print:block print-area bg-white text-black p-8 font-mono text-xs">
          <div className="border-b-2 border-black pb-4 mb-6 flex justify-between items-end">
            <div>
              <h1 className="text-xl font-bold font-clash uppercase">
                Metabolic Intelligence Diagnostic Center
              </h1>
              <p className="text-xs text-gray-600">
                Department of Endocrinology &amp; Primary Care Metabolic Triage
              </p>
            </div>
            <div className="text-right text-[10px]">
              <div>Date: {new Date().toLocaleDateString()}</div>
              <div>Case: {activePatientName}</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6 mb-6 pb-6 border-b border-gray-300">
            <div>
              <h3 className="font-bold text-sm uppercase mb-2">Vitals</h3>
              <div>Fasting Glucose: {formData.glucose} mg/dL</div>
              <div>BMI: {formData.bmi} kg/m²</div>
              <div>Blood Pressure: {formData.bloodPressure} mm Hg</div>
              <div>Age: {formData.age} years</div>
            </div>

            <div>
              <h3 className="font-bold text-sm uppercase mb-2">Assessment</h3>
              <div className="text-base font-bold">
                DIABETES RISK: {assessment.riskScorePercent}% ({assessment.riskLevel})
              </div>
              <div>Model: {assessment.modelUsed}</div>
              <div>Follow-up: {assessment.confirmatoryUrgency}</div>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="font-bold text-sm uppercase mb-2">Action Plan</h3>
            <p className="mb-4">{assessment.clinicalAction}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
