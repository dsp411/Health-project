'use client';

import React from 'react';

interface EditorialFooterProps {
  onSwitchTab?: (tab: 'screening' | 'lab') => void;
  onNavigateToLab?: (expId: number) => void;
}

export default function EditorialFooter({ onSwitchTab }: EditorialFooterProps) {
  return (
    <footer className="w-full bg-[#1e1e1e] text-[#f6f6f6]/60 border-t border-white/5 py-16 px-6 sm:px-10 lg:px-16 print-hide">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-8 text-xs font-satoshi">
        {/* Brand Summary */}
        <div className="space-y-2 max-w-md">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-xs bg-[#ffffff] text-[#111111] font-clash font-bold text-[11px] flex items-center justify-center">
              H1
            </div>
            <span className="font-clash font-bold text-sm tracking-tight text-[#f6f6f6] uppercase">
              Metabolic Intelligence
            </span>
          </div>
          <p className="text-[12px] leading-relaxed text-[#f6f6f6]/50">
            A Swiss minimalist clinical decision support system. Grounded in the NIDDK/UCI Pima Indians cohort.
          </p>
        </div>

        {/* Minimal Navigation & Actions */}
        <div className="flex flex-wrap items-center gap-6 text-[12px] uppercase font-satoshi font-semibold tracking-wider text-[#f6f6f6]/70">
          <button
            onClick={() => {
              if (onSwitchTab) onSwitchTab('screening');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="hover:text-[#ffffff] transition-colors cursor-pointer"
          >
            Screener
          </button>
          <button
            onClick={() => {
              window.print();
            }}
            className="hover:text-[#ffffff] transition-colors cursor-pointer"
          >
            Print PDF
          </button>
          <span className="text-[#f6f6f6]/30">·</span>
          <span className="font-mono text-[11px] text-[#f6f6f6]/40">
            ADA 2024 STANDARDS
          </span>
        </div>
      </div>

      {/* Hairline Bottom */}
      <div className="max-w-7xl mx-auto mt-12 pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] font-mono text-[#f6f6f6]/30">
        <div>© 2026 METABOLIC INTELLIGENCE · HEALTH-PROJECT 1</div>
        <div>CALIBRATED 0.45 ROC THRESHOLD</div>
      </div>
    </footer>
  );
}
