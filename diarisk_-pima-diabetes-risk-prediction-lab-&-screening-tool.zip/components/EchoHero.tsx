'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowDown, Layers, Sparkles } from 'lucide-react';

interface EchoHeroProps {
  onExploreClick?: () => void;
}

const WORDS = ['SYNTHESIS', 'PRECISION', 'STRUCTURE', 'EQUILIBRIUM'];

export default function EchoHero({ onExploreClick }: EchoHeroProps) {
  const [activeWordIdx, setActiveWordIdx] = useState(0);
  const [intensity, setIntensity] = useState(1);

  const currentWord = WORDS[activeWordIdx];

  const handleNextWord = () => {
    setActiveWordIdx((prev) => (prev + 1) % WORDS.length);
  };

  return (
    <section className="relative w-full min-h-[90vh] flex flex-col justify-between items-center px-4 sm:px-8 pt-24 pb-12 overflow-hidden bg-[#f2f2f2] select-none">
      {/* Top Editorial Subtext */}
      <div className="w-full max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-6 border-t border-[#1e1e1e]/10 text-xs font-satoshi uppercase tracking-widest text-[#838282]">
        <div className="flex items-center gap-3">
          <span className="w-2 h-2 bg-[#111111]" />
          <span>SWISS DESIGN SYSTEM // NO. 01</span>
        </div>
        <div className="hidden md:flex items-center gap-8">
          <span>WEIGHT: CLASH 700</span>
          <span>TRACKING: -0.05EM</span>
          <span>LEADING: 0.9</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleNextWord}
            className="flex items-center gap-1.5 px-3 py-1 border border-[#1e1e1e]/20 hover:border-[#111111] text-[#111111] transition-colors rounded-none text-[11px] font-medium tracking-wider"
          >
            <Layers className="w-3 h-3" />
            <span>CYCLE ECHO ({activeWordIdx + 1}/{WORDS.length})</span>
          </button>
        </div>
      </div>

      {/* Main Center Stage: Typographic Echo Stack */}
      <div className="w-full flex-1 flex flex-col items-center justify-center my-8 relative">
        <div className="relative inline-block cursor-pointer group" onClick={handleNextWord}>
          {/* Layer 5: Offset -0.16em, Color #d9d9d9 */}
          <div
            className="absolute inset-0 font-clash font-bold uppercase tracking-[-0.05em] leading-[0.9] text-center pointer-events-none select-none transition-all duration-500"
            style={{
              color: '#d9d9d9',
              transform: `translate(${-0.16 * intensity}em, ${-0.16 * intensity}em)`,
              fontSize: 'clamp(3.5rem, 11vw, 180px)',
              zIndex: 1,
            }}
            aria-hidden="true"
          >
            {currentWord}
          </div>

          {/* Layer 4: Offset -0.12em, Color #d1d1d1 */}
          <div
            className="absolute inset-0 font-clash font-bold uppercase tracking-[-0.05em] leading-[0.9] text-center pointer-events-none select-none transition-all duration-500"
            style={{
              color: '#d1d1d1',
              transform: `translate(${-0.12 * intensity}em, ${-0.12 * intensity}em)`,
              fontSize: 'clamp(3.5rem, 11vw, 180px)',
              zIndex: 2,
            }}
            aria-hidden="true"
          >
            {currentWord}
          </div>

          {/* Layer 3: Offset -0.08em, Color #c9c9c9 */}
          <div
            className="absolute inset-0 font-clash font-bold uppercase tracking-[-0.05em] leading-[0.9] text-center pointer-events-none select-none transition-all duration-500"
            style={{
              color: '#c9c9c9',
              transform: `translate(${-0.08 * intensity}em, ${-0.08 * intensity}em)`,
              fontSize: 'clamp(3.5rem, 11vw, 180px)',
              zIndex: 3,
            }}
            aria-hidden="true"
          >
            {currentWord}
          </div>

          {/* Layer 2: Offset -0.04em, Color #bfbfbf */}
          <div
            className="absolute inset-0 font-clash font-bold uppercase tracking-[-0.05em] leading-[0.9] text-center pointer-events-none select-none transition-all duration-500"
            style={{
              color: '#bfbfbf',
              transform: `translate(${-0.04 * intensity}em, ${-0.04 * intensity}em)`,
              fontSize: 'clamp(3.5rem, 11vw, 180px)',
              zIndex: 4,
            }}
            aria-hidden="true"
          >
            {currentWord}
          </div>

          {/* Layer 1 (Top / Foreground): Color #111111 */}
          <h1
            className="relative font-clash font-bold uppercase tracking-[-0.05em] leading-[0.9] text-center text-[#111111] z-10 transition-transform duration-300"
            style={{
              fontSize: 'clamp(3.5rem, 11vw, 180px)',
            }}
          >
            {currentWord}
          </h1>
        </div>

        {/* Caption below headline */}
        <p className="mt-8 text-center text-sm sm:text-base font-satoshi font-medium text-[#838282] max-w-xl mx-auto tracking-normal px-4">
          Offset text layering through pure geometric weight. Devoid of ornamental fluff, engineered for high-contrast clarity.
        </p>
      </div>

      {/* Bottom Kicker & Scroll Indicator */}
      <div className="w-full max-w-7xl mx-auto flex items-end justify-between border-b border-[#1e1e1e]/10 pb-6 pt-4 text-xs font-satoshi">
        <div className="flex items-center gap-6">
          <span className="font-bold text-[#111111] uppercase tracking-wider">01 // INTRODUCTION</span>
          <span className="hidden sm:inline text-[#b6b5b5]">BRUTALIST MONOCHROME</span>
        </div>

        <button
          onClick={onExploreClick}
          className="flex items-center gap-2 uppercase tracking-widest text-[#111111] hover:text-[#838282] transition-colors"
        >
          <span>EXPLORE MANIFESTO</span>
          <ArrowDown className="w-3.5 h-3.5 animate-bounce" />
        </button>
      </div>
    </section>
  );
}
