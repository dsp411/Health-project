'use client';

import React from 'react';

interface TypographicEchoProps {
  text: string;
  className?: string;
  sizeClass?: string;
}

export default function TypographicEcho({
  text,
  className = '',
  sizeClass = 'text-[11vw] lg:text-[160px]',
}: TypographicEchoProps) {
  return (
    <div className={`echo-container relative inline-block select-none font-clash ${className}`}>
      {/* Background Echo Layer 4 (-0.16em) */}
      <span
        aria-hidden="true"
        className={`echo-layer echo-layer-4 ${sizeClass} font-bold`}
        style={{
          transform: 'translate(-0.16em, -0.16em)',
          color: '#d9d9d9',
        }}
      >
        {text}
      </span>

      {/* Background Echo Layer 3 (-0.12em) */}
      <span
        aria-hidden="true"
        className={`echo-layer echo-layer-3 ${sizeClass} font-bold`}
        style={{
          transform: 'translate(-0.12em, -0.12em)',
          color: '#d1d1d1',
        }}
      >
        {text}
      </span>

      {/* Background Echo Layer 2 (-0.08em) */}
      <span
        aria-hidden="true"
        className={`echo-layer echo-layer-2 ${sizeClass} font-bold`}
        style={{
          transform: 'translate(-0.08em, -0.08em)',
          color: '#c9c9c9',
        }}
      >
        {text}
      </span>

      {/* Background Echo Layer 1 (-0.04em) */}
      <span
        aria-hidden="true"
        className={`echo-layer echo-layer-1 ${sizeClass} font-bold`}
        style={{
          transform: 'translate(-0.04em, -0.04em)',
          color: '#bfbfbf',
        }}
      >
        {text}
      </span>

      {/* Foreground Top Layer */}
      <h1
        className={`echo-foreground relative z-10 ${sizeClass} font-bold text-[#111111]`}
      >
        {text}
      </h1>
    </div>
  );
}
