'use client';

import React, { useState, useMemo } from 'react';
import {
  Database,
  Search,
  Filter,
  AlertCircle,
  Info,
  Download,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  FileSpreadsheet,
} from 'lucide-react';
import { ALL_PATIENTS } from '@/lib/pimaRecords';
import { DATASET_STATS } from '@/lib/mlEngine';
import { FEATURE_METADATA } from '@/lib/dataset';
import ExperimentCodeViewer from '@/components/ExperimentCodeViewer';

type SortKey =
  | 'id'
  | 'pregnancies'
  | 'glucose'
  | 'bloodPressure'
  | 'skinThickness'
  | 'insulin'
  | 'bmi'
  | 'diabetesPedigreeFunction'
  | 'age'
  | 'outcome';

export default function Exp2Dataset() {
  const [searchTerm, setSearchTerm] = useState('');
  const [outcomeFilter, setOutcomeFilter] = useState<'all' | '0' | '1'>('all');
  const [sortKey, setSortKey] = useState<SortKey>('id');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 12;

  const totalPatients = ALL_PATIENTS.length;
  const positiveCount = ALL_PATIENTS.filter((p) => p.outcome === 1).length;
  const negativeCount = totalPatients - positiveCount;
  const positivePct = ((positiveCount / totalPatients) * 100).toFixed(1);
  const negativePct = ((negativeCount / totalPatients) * 100).toFixed(1);

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortKey(key);
      setSortDirection('asc');
    }
    setCurrentPage(1);
  };

  const filteredPatients = useMemo(() => {
    let result = ALL_PATIENTS.filter((p) => {
      if (outcomeFilter !== 'all' && p.outcome.toString() !== outcomeFilter) return false;
      if (!searchTerm) return true;
      const term = searchTerm.toLowerCase();
      return (
        p.id.toString().includes(term) ||
        p.glucose.toString().includes(term) ||
        p.bmi.toString().includes(term) ||
        p.age.toString().includes(term)
      );
    });

    result.sort((a, b) => {
      const valA = a[sortKey];
      const valB = b[sortKey];
      if (valA < valB) return sortDirection === 'asc' ? -1 : 1;
      if (valA > valB) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });

    return result;
  }, [searchTerm, outcomeFilter, sortKey, sortDirection]);

  const totalPages = Math.ceil(filteredPatients.length / pageSize);
  const displayedPatients = filteredPatients.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const handleDownloadCSV = () => {
    const header = 'id,pregnancies,glucose,bloodPressure,skinThickness,insulin,bmi,diabetesPedigreeFunction,age,outcome';
    const rows = ALL_PATIENTS.map(
      (p) =>
        `${p.id},${p.pregnancies},${p.glucose},${p.bloodPressure},${p.skinThickness},${p.insulin},${p.bmi},${p.diabetesPedigreeFunction},${p.age},${p.outcome}`
    );
    const csvContent = 'data:text/csv;charset=utf-8,' + [header, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'pima_indians_diabetes_768_records.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const renderSortIndicator = (key: SortKey) => {
    if (sortKey !== key) return <ArrowUpDown className="h-3 w-3 text-slate-400 inline ml-1 opacity-60" />;
    return sortDirection === 'asc' ? (
      <ArrowUp className="h-3 w-3 text-indigo-600 inline ml-1" />
    ) : (
      <ArrowDown className="h-3 w-3 text-indigo-600 inline ml-1" />
    );
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 mb-2">
              <span>Experiment 2</span>
              <span>•</span>
              <span>1.5 Hours Scheduled</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Dataset Analysis & Feature Dictionary</h2>
            <p className="text-slate-600 text-sm mt-1 max-w-3xl">
              Dataset Description Report: Source provenance, schema metadata, feature dictionary, target class distribution, and ethnic/clinical limitations.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              id="download-csv-btn"
              onClick={handleDownloadCSV}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold shadow-xs transition"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export CSV (768 Records)</span>
            </button>
            <span className="text-xs px-3 py-1.5 rounded-lg bg-slate-100 text-slate-700 font-mono font-medium">
              N = 768 Records
            </span>
          </div>
        </div>
      </div>

      {/* Overview Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Cohort Population</span>
          <div className="text-2xl font-bold text-slate-900 mt-1">768 Patients</div>
          <p className="text-xs text-slate-600 mt-1">Female Pima Indian heritage, age ≥ 21 yrs</p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Non-Diabetic (Outcome = 0)</span>
          <div className="text-2xl font-bold text-slate-700 mt-1">
            500 <span className="text-sm font-normal text-slate-500">({negativePct}%)</span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2 overflow-hidden">
            <div className="bg-slate-400 h-1.5 rounded-full" style={{ width: `${negativePct}%` }} />
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Diabetic (Outcome = 1)</span>
          <div className="text-2xl font-bold text-rose-600 mt-1">
            268 <span className="text-sm font-normal text-slate-500">({positivePct}%)</span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2 overflow-hidden">
            <div className="bg-rose-500 h-1.5 rounded-full" style={{ width: `${positivePct}%` }} />
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Provenance & License</span>
          <div className="text-sm font-semibold text-slate-900 mt-1">NIDDK / UCI Repository</div>
          <p className="text-xs text-slate-500 mt-1">CC0 Public Domain (Kaggle)</p>
        </div>
      </div>

      {/* Feature / Label Dictionary Table */}
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-xs">
        <div className="border-b border-slate-200 bg-slate-50/75 px-5 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Database className="h-4 w-4 text-teal-600" />
            <h3 className="font-semibold text-slate-900 text-sm">Feature & Label Clinical Dictionary</h3>
          </div>
          <span className="text-xs text-slate-500">8 Diagnostic Predictors</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 text-slate-600 uppercase font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-4">Feature Key</th>
                <th className="py-2.5 px-4">Clinical Label</th>
                <th className="py-2.5 px-4">Unit</th>
                <th className="py-2.5 px-4">Cohort Mean ± Std</th>
                <th className="py-2.5 px-4">Clinical Reference</th>
                <th className="py-2.5 px-4">Pathological Significance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {Object.entries(FEATURE_METADATA).map(([key, meta]) => {
                const stats = DATASET_STATS[key];
                return (
                  <tr key={key} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4 font-mono font-medium text-slate-900">{key}</td>
                    <td className="py-3 px-4 font-semibold text-slate-800">{meta.label}</td>
                    <td className="py-3 px-4 text-slate-500">{meta.unit}</td>
                    <td className="py-3 px-4 font-mono text-slate-700">
                      {stats ? `${stats.mean.toFixed(1)} ± ${stats.std.toFixed(1)}` : '—'}
                    </td>
                    <td className="py-3 px-4 text-slate-600 font-mono text-[11px]">{meta.normalRange}</td>
                    <td className="py-3 px-4 text-slate-600">{meta.clinicalNote}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Cohort Record Explorer with Sorting & Search */}
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-200 bg-slate-50/60 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                id="search-patients-input"
                type="text"
                placeholder="Search ID, Glucose, BMI..."
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setCurrentPage(1);
                }}
                className="pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white focus:outline-hidden focus:ring-2 focus:ring-teal-500 w-52 sm:w-64"
              />
            </div>

            <div className="flex items-center gap-1 text-xs">
              <Filter className="h-3.5 w-3.5 text-slate-500" />
              <select
                id="filter-outcome-select"
                value={outcomeFilter}
                onChange={(e) => {
                  setOutcomeFilter(e.target.value as 'all' | '0' | '1');
                  setCurrentPage(1);
                }}
                className="border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs bg-white focus:outline-hidden focus:ring-2 focus:ring-teal-500"
              >
                <option value="all">All Outcomes ({totalPatients})</option>
                <option value="0">Non-Diabetic (500)</option>
                <option value="1">Diabetic (268)</option>
              </select>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-xs text-slate-500">
              Showing {(currentPage - 1) * pageSize + 1} – {Math.min(currentPage * pageSize, filteredPatients.length)} of{' '}
              {filteredPatients.length} records
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 uppercase font-semibold border-b border-slate-200 select-none">
              <tr>
                <th onClick={() => handleSort('id')} className="py-2.5 px-3 cursor-pointer hover:text-slate-900">
                  # ID {renderSortIndicator('id')}
                </th>
                <th onClick={() => handleSort('pregnancies')} className="py-2.5 px-3 cursor-pointer hover:text-slate-900">
                  Pregnancies {renderSortIndicator('pregnancies')}
                </th>
                <th onClick={() => handleSort('glucose')} className="py-2.5 px-3 cursor-pointer hover:text-slate-900">
                  Glucose {renderSortIndicator('glucose')}
                </th>
                <th onClick={() => handleSort('bloodPressure')} className="py-2.5 px-3 cursor-pointer hover:text-slate-900">
                  BP {renderSortIndicator('bloodPressure')}
                </th>
                <th onClick={() => handleSort('skinThickness')} className="py-2.5 px-3 cursor-pointer hover:text-slate-900">
                  Skin {renderSortIndicator('skinThickness')}
                </th>
                <th onClick={() => handleSort('insulin')} className="py-2.5 px-3 cursor-pointer hover:text-slate-900">
                  Insulin {renderSortIndicator('insulin')}
                </th>
                <th onClick={() => handleSort('bmi')} className="py-2.5 px-3 cursor-pointer hover:text-slate-900">
                  BMI {renderSortIndicator('bmi')}
                </th>
                <th onClick={() => handleSort('diabetesPedigreeFunction')} className="py-2.5 px-3 cursor-pointer hover:text-slate-900">
                  Pedigree {renderSortIndicator('diabetesPedigreeFunction')}
                </th>
                <th onClick={() => handleSort('age')} className="py-2.5 px-3 cursor-pointer hover:text-slate-900">
                  Age {renderSortIndicator('age')}
                </th>
                <th onClick={() => handleSort('outcome')} className="py-2.5 px-3 cursor-pointer hover:text-slate-900">
                  Outcome {renderSortIndicator('outcome')}
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {displayedPatients.map((patient) => (
                <tr key={patient.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-2 px-3 font-mono font-medium text-slate-500">#{patient.id}</td>
                  <td className="py-2 px-3 text-slate-700">{patient.pregnancies}</td>
                  <td className="py-2 px-3 font-mono font-semibold text-slate-900">
                    <span className={patient.glucose >= 140 ? 'text-rose-600 font-bold' : ''}>
                      {patient.glucose}
                    </span>
                  </td>
                  <td className="py-2 px-3 text-slate-700">{patient.bloodPressure}</td>
                  <td className="py-2 px-3 text-slate-700">{patient.skinThickness}</td>
                  <td className="py-2 px-3 text-slate-700">{patient.insulin}</td>
                  <td className="py-2 px-3 font-mono text-slate-700">
                    <span className={patient.bmi >= 30 ? 'text-amber-700 font-medium' : ''}>
                      {patient.bmi.toFixed(1)}
                    </span>
                  </td>
                  <td className="py-2 px-3 text-slate-700">{patient.diabetesPedigreeFunction.toFixed(3)}</td>
                  <td className="py-2 px-3 text-slate-700">{patient.age}</td>
                  <td className="py-2 px-3">
                    {patient.outcome === 1 ? (
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-rose-50 text-rose-700 border border-rose-200">
                        Diabetic (1)
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium bg-slate-100 text-slate-700">
                        Normal (0)
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination controls */}
        <div className="p-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs">
          <span className="text-slate-600">
            Page <strong>{currentPage}</strong> of <strong>{totalPages || 1}</strong>
          </span>
          <div className="flex items-center gap-1">
            <button
              id="prev-page-btn"
              disabled={currentPage <= 1}
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              className="px-2.5 py-1 rounded-md border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1 transition"
            >
              <ChevronLeft className="h-3.5 w-3.5" /> Prev
            </button>
            <button
              id="next-page-btn"
              disabled={currentPage >= totalPages}
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              className="px-2.5 py-1 rounded-md border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1 transition"
            >
              Next <ChevronRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Code & Notebook Execution Terminal */}
      <ExperimentCodeViewer experimentId={2} />
    </div>
  );
}
