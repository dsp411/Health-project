'use client';

import React, { useState } from 'react';
import { BrainCircuit, Sliders, Play, CheckCircle2, RotateCw, Sparkles, Activity } from 'lucide-react';
import { MODEL_BENCHMARKS } from '@/lib/mlEngine';
import ExperimentCodeViewer from '@/components/ExperimentCodeViewer';

export default function Exp5Training() {
  const [selectedAlgo, setSelectedAlgo] = useState<'xgboost' | 'random_forest' | 'logistic_regression'>('xgboost');
  const [learningRate, setLearningRate] = useState<number>(0.08);
  const [maxDepth, setMaxDepth] = useState<number>(5);
  const [nEstimators, setNEstimators] = useState<number>(100);
  const [cParam, setCParam] = useState<number>(1.0);
  const [isTraining, setIsTraining] = useState<boolean>(false);
  const [trainingLogs, setTrainingLogs] = useState<string[]>([
    '[Epoch 01] Initializing stratified 5-fold cross validation on 614 training instances...',
    '[Epoch 05] Fold 1 validation accuracy: 0.813, log-loss: 0.452',
    '[Epoch 10] Fold 2 validation accuracy: 0.829, log-loss: 0.438',
    '[Epoch 15] Fold 3 validation accuracy: 0.805, log-loss: 0.461',
    '[Epoch 20] Fold 4 validation accuracy: 0.821, log-loss: 0.440',
    '[Epoch 25] Fold 5 validation accuracy: 0.797, log-loss: 0.472',
    '[Convergence] 5-Fold Cross-Validation complete. Mean Score: 0.812 (±0.028). Best weights saved to checkpoint.',
  ]);

  const handleRetrain = () => {
    setIsTraining(true);
    setTrainingLogs((prev) => [
      ...prev,
      `[Retrain Triggered] Tuning ${selectedAlgo.toUpperCase()} with depth=${maxDepth}, lr=${learningRate}, n_estimators=${nEstimators}...`,
    ]);

    setTimeout(() => {
      setIsTraining(false);
      setTrainingLogs((prev) => [
        ...prev,
        `[Optimized] Hyperparameter grid evaluation finished. Validation Recall achieved: 81.8%. Saved to checkpoint: /models/${selectedAlgo}_v2.bin`,
      ]);
    }, 1200);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 mb-2">
              <span>Experiment 5</span>
              <span>•</span>
              <span>2.0 Hours Scheduled</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Model Training & Hyperparameter Tuning</h2>
            <p className="text-slate-600 text-sm mt-1 max-w-3xl">
              Training candidate algorithms (Logistic Regression, Random Forest, Gradient Boosting / XGBoost), conducting 5-fold cross-validation, and tuning hyperparameters to optimize clinical sensitivity.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs px-3 py-1.5 rounded-lg bg-teal-50 text-teal-700 border border-teal-200 font-medium">
              5-Fold Stratified CV
            </span>
          </div>
        </div>
      </div>

      {/* Model Cards Benchmark Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {MODEL_BENCHMARKS.map((m) => {
          const isSelected = selectedAlgo === m.algorithm;
          return (
            <div
              key={m.algorithm}
              onClick={() => setSelectedAlgo(m.algorithm)}
              className={`cursor-pointer rounded-xl p-5 border transition-all ${
                isSelected
                  ? 'border-indigo-600 bg-indigo-50/30 ring-2 ring-indigo-500/20 shadow-sm'
                  : 'border-slate-200 bg-white hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500 font-mono">
                  {m.algorithm.replace('_', ' ')}
                </span>
                {isSelected && (
                  <span className="inline-flex items-center gap-1 text-[11px] font-bold text-indigo-700 bg-indigo-100 px-2 py-0.5 rounded-full">
                    <CheckCircle2 className="h-3 w-3" /> Selected
                  </span>
                )}
              </div>

              <h3 className="text-base font-bold text-slate-900 leading-tight">{m.name}</h3>

              <div className="grid grid-cols-2 gap-3 mt-4 text-xs">
                <div className="bg-white p-2.5 rounded-lg border border-slate-100">
                  <span className="text-slate-500 block text-[11px]">Accuracy</span>
                  <span className="text-base font-bold font-mono text-slate-900">{(m.accuracy * 100).toFixed(1)}%</span>
                </div>
                <div className="bg-white p-2.5 rounded-lg border border-slate-100">
                  <span className="text-slate-500 block text-[11px]">Recall (Sensitivity)</span>
                  <span className="text-base font-bold font-mono text-rose-600">{(m.recall * 100).toFixed(1)}%</span>
                </div>
                <div className="bg-white p-2.5 rounded-lg border border-slate-100">
                  <span className="text-slate-500 block text-[11px]">5-Fold CV Score</span>
                  <span className="text-xs font-bold font-mono text-slate-800">
                    {(m.cvMeanScore * 100).toFixed(1)}% (±{(m.cvStdScore * 100).toFixed(1)}%)
                  </span>
                </div>
                <div className="bg-white p-2.5 rounded-lg border border-slate-100">
                  <span className="text-slate-500 block text-[11px]">ROC-AUC</span>
                  <span className="text-xs font-bold font-mono text-teal-700">{m.rocAuc.toFixed(3)}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Interactive Hyperparameter Tuning & Retraining Workbench */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Controls Column */}
        <div className="lg:col-span-5 rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
            <Sliders className="h-4 w-4 text-indigo-600" />
            <h3 className="font-bold text-slate-900 text-sm">Hyperparameter Controls ({selectedAlgo.toUpperCase()})</h3>
          </div>

          {selectedAlgo === 'xgboost' && (
            <>
              <div>
                <div className="flex justify-between text-xs font-medium text-slate-700 mb-1">
                  <span>Learning Rate (η): {learningRate}</span>
                  <span className="text-slate-500">Shrinkage step</span>
                </div>
                <input
                  type="range"
                  min="0.01"
                  max="0.30"
                  step="0.01"
                  value={learningRate}
                  onChange={(e) => setLearningRate(parseFloat(e.target.value))}
                  className="w-full accent-indigo-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-medium text-slate-700 mb-1">
                  <span>Max Tree Depth: {maxDepth}</span>
                  <span className="text-slate-500">Interaction depth</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="10"
                  step="1"
                  value={maxDepth}
                  onChange={(e) => setMaxDepth(parseInt(e.target.value))}
                  className="w-full accent-indigo-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-medium text-slate-700 mb-1">
                  <span>Estimators (Boosting Rounds): {nEstimators}</span>
                  <span className="text-slate-500">Tree count</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="300"
                  step="10"
                  value={nEstimators}
                  onChange={(e) => setNEstimators(parseInt(e.target.value))}
                  className="w-full accent-indigo-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
                />
              </div>
            </>
          )}

          {selectedAlgo === 'random_forest' && (
            <>
              <div>
                <div className="flex justify-between text-xs font-medium text-slate-700 mb-1">
                  <span>Number of Trees: {nEstimators}</span>
                  <span className="text-slate-500">Bootstrap forest</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="300"
                  step="10"
                  value={nEstimators}
                  onChange={(e) => setNEstimators(parseInt(e.target.value))}
                  className="w-full accent-indigo-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
                />
              </div>
              <div>
                <div className="flex justify-between text-xs font-medium text-slate-700 mb-1">
                  <span>Max Depth: {maxDepth}</span>
                  <span className="text-slate-500">Leaf depth</span>
                </div>
                <input
                  type="range"
                  min="3"
                  max="12"
                  step="1"
                  value={maxDepth}
                  onChange={(e) => setMaxDepth(parseInt(e.target.value))}
                  className="w-full accent-indigo-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
                />
              </div>
            </>
          )}

          {selectedAlgo === 'logistic_regression' && (
            <div>
              <div className="flex justify-between text-xs font-medium text-slate-700 mb-1">
                <span>Inverse Regularization Strength (C): {cParam}</span>
                <span className="text-slate-500">L2 Penalty</span>
              </div>
              <input
                type="range"
                min="0.01"
                max="10.0"
                step="0.1"
                value={cParam}
                onChange={(e) => setCParam(parseFloat(e.target.value))}
                className="w-full accent-indigo-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
              />
            </div>
          )}

          <button
            id="run-train-btn"
            onClick={handleRetrain}
            disabled={isTraining}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition disabled:opacity-50"
          >
            {isTraining ? (
              <>
                <RotateCw className="h-4 w-4 animate-spin" />
                <span>Running Cross-Validation Epochs...</span>
              </>
            ) : (
              <>
                <Play className="h-4 w-4" />
                <span>Train Model Checkpoint</span>
              </>
            )}
          </button>
        </div>

        {/* Training Console Logs Column */}
        <div className="lg:col-span-7 rounded-xl border border-slate-800 bg-slate-900 text-slate-200 overflow-hidden shadow-sm flex flex-col justify-between">
          <div className="px-4 py-2.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between text-xs font-mono text-slate-400">
            <span>training_stdout.log • 5-Fold Stratified Cross-Validation</span>
            <span className="text-emerald-400 text-[11px] flex items-center gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" /> Live Logs
            </span>
          </div>

          <div className="p-4 font-mono text-xs text-slate-300 space-y-1.5 overflow-y-auto max-h-64">
            {trainingLogs.map((log, idx) => (
              <div key={idx} className={log.includes('Convergence') || log.includes('Optimized') ? 'text-teal-400 font-bold' : ''}>
                {log}
              </div>
            ))}
          </div>

          <div className="p-3 bg-slate-950/80 border-t border-slate-800 text-slate-400 text-[11px] flex items-center justify-between">
            <span>Hardware: Accelerated Container Environment</span>
            <span>Batch Size: 32 • Early Stopping: Patience 10</span>
          </div>
        </div>
      </div>

      {/* Code & Notebook Execution Terminal */}
      <ExperimentCodeViewer experimentId={5} />
    </div>
  );
}
