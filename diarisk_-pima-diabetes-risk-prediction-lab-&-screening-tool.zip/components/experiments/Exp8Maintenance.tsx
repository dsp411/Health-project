'use client';

import React, { useState } from 'react';
import { Activity, AlertTriangle, ShieldCheck, RefreshCw, Layers, Bell, CheckCircle2, RotateCcw } from 'lucide-react';
import ExperimentCodeViewer from '@/components/ExperimentCodeViewer';

export default function Exp8Maintenance() {
  const [driftScenario, setDriftScenario] = useState<'normal' | 'aging' | 'metabolic'>('normal');

  const scenarios = {
    normal: {
      name: 'Scenario A: Normal Clinic Patient Inflow',
      psi: 0.042,
      status: 'STABLE',
      statusColor: 'text-emerald-700 bg-emerald-50 border-emerald-200',
      observedRecall: '81.2%',
      driftNote: 'Baseline distribution aligned with training demographic. No distribution shift detected.',
      actionRequired: 'Continue passive logging. Next scheduled model recalibration in 90 days.',
      featuresDrift: [
        { feature: 'Glucose', driftPValue: 0.84, shifted: false },
        { feature: 'BMI', driftPValue: 0.76, shifted: false },
        { feature: 'Age', driftPValue: 0.91, shifted: false },
      ],
    },
    aging: {
      name: 'Scenario B: Geriatric Clinic Outreach (+12y Age Shift)',
      psi: 0.284,
      status: 'MODERATE DRIFT WARNING',
      statusColor: 'text-amber-800 bg-amber-50 border-amber-300',
      observedRecall: '76.4%',
      driftNote: 'Significant shift in Age and BloodPressure distributions. Baseline cutoff causes higher false positive rate.',
      actionRequired: 'Automated retraining trigger tripped: Initiate age-stratified recalibration and threshold tuning.',
      featuresDrift: [
        { feature: 'Age', driftPValue: 0.002, shifted: true },
        { feature: 'BloodPressure', driftPValue: 0.041, shifted: true },
        { feature: 'Glucose', driftPValue: 0.32, shifted: false },
      ],
    },
    metabolic: {
      name: 'Scenario C: Urban High-Adiposity Surge (BMI & Glucose Shift)',
      psi: 0.392,
      status: 'CRITICAL POPULATION DRIFT',
      statusColor: 'text-rose-800 bg-rose-50 border-rose-300',
      observedRecall: '71.8%',
      driftNote: 'Severe covariate shift in BMI and Glucose distributions. Model performance degrading below clinical SLA.',
      actionRequired: 'CRITICAL ALERT: Activate shadow validation model, notify Clinical Director, trigger urgent pipeline retrain with current cohort.',
      featuresDrift: [
        { feature: 'Glucose', driftPValue: 0.0001, shifted: true },
        { feature: 'BMI', driftPValue: 0.001, shifted: true },
        { feature: 'Insulin', driftPValue: 0.008, shifted: true },
      ],
    },
  };

  const active = scenarios[driftScenario];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 mb-2">
              <span>Experiment 8</span>
              <span>•</span>
              <span>1.5 Hours Scheduled</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Continuous Update, Drift & Maintenance</h2>
            <p className="text-slate-600 text-sm mt-1 max-w-3xl">
              Monitoring & Maintenance Plan: Real-time population drift detection (PSI), automated retraining triggers, clinical SLA compliance, and fallback rollback protocols.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs px-3 py-1.5 rounded-lg bg-teal-50 text-teal-700 border border-teal-200 font-medium">
              MLOps Clinical Governance
            </span>
          </div>
        </div>
      </div>

      {/* Interactive Population Drift Simulator */}
      <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-slate-200 pb-3">
          <div className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-indigo-600" />
            <h3 className="font-bold text-slate-900 text-sm">Incoming Patient Cohort Drift Simulator</h3>
          </div>

          {/* Scenario Selector */}
          <div className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-100 p-1 text-xs">
            <button
              id="drift-scenario-normal"
              onClick={() => setDriftScenario('normal')}
              className={`px-3 py-1 rounded-md font-medium transition ${
                driftScenario === 'normal' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-600'
              }`}
            >
              Normal Intake
            </button>
            <button
              id="drift-scenario-aging"
              onClick={() => setDriftScenario('aging')}
              className={`px-3 py-1 rounded-md font-medium transition ${
                driftScenario === 'aging' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-600'
              }`}
            >
              Age Demographic Shift
            </button>
            <button
              id="drift-scenario-metabolic"
              onClick={() => setDriftScenario('metabolic')}
              className={`px-3 py-1 rounded-md font-medium transition ${
                driftScenario === 'metabolic' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-600'
              }`}
            >
              Metabolic Adiposity Surge
            </button>
          </div>
        </div>

        {/* Drift Status Banner */}
        <div className={`rounded-xl border p-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4 ${active.statusColor}`}>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider font-mono">Status:</span>
              <span className="font-bold text-sm">{active.status}</span>
            </div>
            <p className="text-xs leading-relaxed">{active.driftNote}</p>
          </div>

          <div className="flex items-center gap-4 text-center shrink-0">
            <div className="bg-white/80 backdrop-blur-xs px-3 py-1.5 rounded-lg border border-slate-200">
              <span className="text-[10px] text-slate-500 block uppercase font-mono">PSI Score</span>
              <span className="text-base font-extrabold font-mono text-slate-900">{active.psi}</span>
            </div>
            <div className="bg-white/80 backdrop-blur-xs px-3 py-1.5 rounded-lg border border-slate-200">
              <span className="text-[10px] text-slate-500 block uppercase font-mono">Monitored Recall</span>
              <span className="text-base font-extrabold font-mono text-slate-900">{active.observedRecall}</span>
            </div>
          </div>
        </div>

        {/* Feature-Level KS Drift Table */}
        <div className="pt-2">
          <span className="text-xs font-semibold text-slate-700 block mb-2">Biomarker Feature Drift Tests (Kolmogorov-Smirnov p-value)</span>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            {active.featuresDrift.map((f) => (
              <div
                key={f.feature}
                className={`p-3 rounded-lg border ${
                  f.shifted ? 'bg-rose-50/60 border-rose-200' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex justify-between items-center mb-1">
                  <span className="font-bold text-slate-900">{f.feature}</span>
                  <span
                    className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                      f.shifted ? 'bg-rose-200 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {f.shifted ? 'Shift Detected' : 'Stable'}
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 font-mono">KS p-value: {f.driftPValue}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Action Callout */}
        <div className="rounded-lg bg-slate-100 p-3 text-xs text-slate-700 flex items-start gap-2">
          <Bell className="h-4 w-4 text-indigo-600 shrink-0 mt-0.5" />
          <div>
            <strong>Automated Action Protocol:</strong> {active.actionRequired}
          </div>
        </div>
      </div>

      {/* Retraining Cadence & Maintenance Plan Specifications */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-2">
          <div className="flex items-center gap-2 text-indigo-700">
            <RefreshCw className="h-4 w-4" />
            <h4 className="font-bold text-slate-900 text-sm">Retraining Triggers</h4>
          </div>
          <ul className="text-xs text-slate-600 space-y-1.5 list-disc pl-4">
            <li><strong>Calendar Cadence:</strong> Quarterly retraining with incoming verified laboratory cohorts.</li>
            <li><strong>Drift Threshold:</strong> Event-driven when Population Stability Index (PSI) exceeds <strong>0.20</strong>.</li>
            <li><strong>Performance Drop:</strong> Monitored screening recall falls below <strong>78.0%</strong> over 100 consecutive cases.</li>
          </ul>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-2">
          <div className="flex items-center gap-2 text-teal-700">
            <RotateCcw className="h-4 w-4" />
            <h4 className="font-bold text-slate-900 text-sm">Rollback & Shadow Pipeline</h4>
          </div>
          <ul className="text-xs text-slate-600 space-y-1.5 list-disc pl-4">
            <li><strong>Canary Shadow Run:</strong> Newly trained candidate models run silently in parallel for 14 days before activation.</li>
            <li><strong>Zero-Downtime Rollback:</strong> Instant fallback to previous golden checkpoint (/models/xgboost_v1.bin) if validation metric dips.</li>
            <li><strong>Deterministic Seed:</strong> Strict random seed tracking for reproducibility.</li>
          </ul>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-2">
          <div className="flex items-center gap-2 text-blue-700">
            <ShieldCheck className="h-4 w-4" />
            <h4 className="font-bold text-slate-900 text-sm">Clinical SLA & Governance</h4>
          </div>
          <ul className="text-xs text-slate-600 space-y-1.5 list-disc pl-4">
            <li><strong>Clinical Ownership:</strong> Chief Medical Officer (CMO) and Lead Endocrinologist review quarterly audit logs.</li>
            <li><strong>Inference SLA:</strong> 99.9% uptime with p95 response latency &lt; 150ms.</li>
            <li><strong>Audit Logging:</strong> All inputs, model scores, and subsequent confirmatory lab outcomes logged in compliance with HIPAA.</li>
          </ul>
        </div>
      </div>

      {/* Code & Notebook Execution Terminal */}
      <ExperimentCodeViewer experimentId={8} />
    </div>
  );
}
