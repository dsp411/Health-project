'use client';

import React, { useState } from 'react';
import { Terminal, Copy, Check, Send, Globe, Play, Stethoscope, ArrowRight, ShieldCheck } from 'lucide-react';
import ExperimentCodeViewer from '@/components/ExperimentCodeViewer';

export default function Exp7Deployment({ onLaunchScreening }: { onLaunchScreening: () => void }) {
  const [copiedCurl, setCopiedCurl] = useState(false);
  const [copiedPython, setCopiedPython] = useState(false);
  const [apiLoading, setApiLoading] = useState(false);
  const [apiResponse, setApiResponse] = useState<string | null>(null);
  const [latencyMs, setLatencyMs] = useState<number | null>(null);

  const [requestPayload, setRequestPayload] = useState({
    pregnancies: 6,
    glucose: 148,
    bloodPressure: 72,
    skinThickness: 35,
    insulin: 169.5,
    bmi: 33.6,
    diabetesPedigreeFunction: 0.627,
    age: 50,
    model: 'xgboost',
    decisionThreshold: 0.45,
  });

  const curlCommand = `curl -X POST https://your-clinic-host.app/api/predict \\
  -H "Content-Type: application/json" \\
  -d '{
    "pregnancies": 6,
    "glucose": 148,
    "bloodPressure": 72,
    "skinThickness": 35,
    "insulin": 169.5,
    "bmi": 33.6,
    "diabetesPedigreeFunction": 0.627,
    "age": 50,
    "model": "xgboost",
    "decisionThreshold": 0.45
  }'`;

  const pythonCode = `import requests

url = "https://your-clinic-host.app/api/predict"
payload = {
    "pregnancies": 6,
    "glucose": 148,
    "bloodPressure": 72,
    "skinThickness": 35,
    "insulin": 169.5,
    "bmi": 33.6,
    "diabetesPedigreeFunction": 0.627,
    "age": 50,
    "model": "xgboost",
    "decisionThreshold": 0.45
}

response = requests.post(url, json=payload)
data = response.json()
print("Diabetes Risk Score:", data['assessment']['diabetesRiskScore'], "%")
print("Triage Action:", data['assessment']['triageAction'])
`;

  const handleTestApi = async () => {
    setApiLoading(true);
    const startTime = performance.now();
    try {
      const res = await fetch('/api/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestPayload),
      });
      const data = await res.json();
      const elapsed = Math.round(performance.now() - startTime);
      setLatencyMs(elapsed);
      setApiResponse(JSON.stringify(data, null, 2));
    } catch (err) {
      setApiResponse(JSON.stringify({ error: 'Failed to contact API' }, null, 2));
    } finally {
      setApiLoading(false);
    }
  };

  const copyCurl = () => {
    navigator.clipboard.writeText(curlCommand);
    setCopiedCurl(true);
    setTimeout(() => setCopiedCurl(false), 2000);
  };

  const copyPython = () => {
    navigator.clipboard.writeText(pythonCode);
    setCopiedPython(true);
    setTimeout(() => setCopiedPython(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 mb-2">
              <span>Experiment 7</span>
              <span>•</span>
              <span>2.5 Hours Scheduled</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Deployment & Clinical REST API</h2>
            <p className="text-slate-600 text-sm mt-1 max-w-3xl">
              Production inference microservice returning diabetes risk scores, clinical priority tiers, and risk drivers from patient vitals.
            </p>
          </div>
          <button
            id="launch-screening-from-exp7-btn"
            onClick={onLaunchScreening}
            className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs shadow-xs transition"
          >
            <Stethoscope className="h-4 w-4" />
            <span>Open Clinical Screening Portal</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Live Interactive API Testing Console */}
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-xs">
        <div className="border-b border-slate-200 bg-slate-50 px-5 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Globe className="h-4 w-4 text-teal-600" />
            <h3 className="font-bold text-slate-900 text-sm">Interactive API Playground (POST /api/predict)</h3>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold">
              HTTP 200 READY
            </span>
          </div>
        </div>

        <div className="p-5 grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Request Payload Editor */}
          <div className="lg:col-span-6 space-y-3">
            <div className="flex justify-between items-center text-xs">
              <span className="font-semibold text-slate-700">JSON Request Body</span>
              <span className="text-slate-400 font-mono">application/json</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <label className="block text-[11px] text-slate-500 font-medium">Glucose (mg/dL)</label>
                <input
                  type="number"
                  value={requestPayload.glucose}
                  onChange={(e) => setRequestPayload({ ...requestPayload, glucose: Number(e.target.value) })}
                  className="w-full border border-slate-300 rounded px-2.5 py-1 text-xs font-mono"
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-500 font-medium">BMI (kg/m²)</label>
                <input
                  type="number"
                  step="0.1"
                  value={requestPayload.bmi}
                  onChange={(e) => setRequestPayload({ ...requestPayload, bmi: Number(e.target.value) })}
                  className="w-full border border-slate-300 rounded px-2.5 py-1 text-xs font-mono"
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-500 font-medium">Age (yrs)</label>
                <input
                  type="number"
                  value={requestPayload.age}
                  onChange={(e) => setRequestPayload({ ...requestPayload, age: Number(e.target.value) })}
                  className="w-full border border-slate-300 rounded px-2.5 py-1 text-xs font-mono"
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-500 font-medium">Pregnancies</label>
                <input
                  type="number"
                  value={requestPayload.pregnancies}
                  onChange={(e) => setRequestPayload({ ...requestPayload, pregnancies: Number(e.target.value) })}
                  className="w-full border border-slate-300 rounded px-2.5 py-1 text-xs font-mono"
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-500 font-medium">Insulin (μU/mL)</label>
                <input
                  type="number"
                  value={requestPayload.insulin}
                  onChange={(e) => setRequestPayload({ ...requestPayload, insulin: Number(e.target.value) })}
                  className="w-full border border-slate-300 rounded px-2.5 py-1 text-xs font-mono"
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-500 font-medium">Pedigree Function</label>
                <input
                  type="number"
                  step="0.01"
                  value={requestPayload.diabetesPedigreeFunction}
                  onChange={(e) =>
                    setRequestPayload({ ...requestPayload, diabetesPedigreeFunction: Number(e.target.value) })
                  }
                  className="w-full border border-slate-300 rounded px-2.5 py-1 text-xs font-mono"
                />
              </div>
            </div>

            <button
              id="send-api-req-btn"
              onClick={handleTestApi}
              disabled={apiLoading}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs transition disabled:opacity-50"
            >
              <Send className="h-3.5 w-3.5" />
              <span>{apiLoading ? 'Invoking Inference Microservice...' : 'Execute Live API Request'}</span>
            </button>
          </div>

          {/* Response Inspector */}
          <div className="lg:col-span-6 rounded-lg border border-slate-800 bg-slate-900 text-slate-100 overflow-hidden flex flex-col justify-between">
            <div className="px-3.5 py-2 bg-slate-950 border-b border-slate-800 flex items-center justify-between text-xs font-mono text-slate-400">
              <span>Response Payload</span>
              {latencyMs !== null && <span className="text-teal-400 font-bold">{latencyMs} ms latency</span>}
            </div>

            <pre className="p-3 text-[11px] font-mono overflow-y-auto max-h-72 text-emerald-400 leading-relaxed">
              {apiResponse ||
                JSON.stringify(
                  {
                    status: 'awaiting_request',
                    hint: 'Click "Execute Live API Request" to test endpoint',
                  },
                  null,
                  2
                )}
            </pre>

            <div className="p-2 bg-slate-950/80 border-t border-slate-800 text-[10px] text-slate-400 flex justify-between">
              <span>Status: {apiResponse ? '200 OK' : 'Ready'}</span>
              <span>Content-Type: application/json</span>
            </div>
          </div>
        </div>
      </div>

      {/* Code Snippets for Integration */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* cURL */}
        <div className="rounded-xl border border-slate-800 bg-slate-900 text-slate-100 overflow-hidden shadow-xs">
          <div className="px-4 py-2.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
            <span className="text-xs font-mono text-slate-300">cURL Terminal Command</span>
            <button
              id="copy-curl-btn"
              onClick={copyCurl}
              className="text-xs text-teal-400 hover:text-teal-300 flex items-center gap-1 font-mono"
            >
              {copiedCurl ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copiedCurl ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
          <pre className="p-3 text-[11px] font-mono text-slate-300 overflow-x-auto">{curlCommand}</pre>
        </div>

        {/* Python Requests */}
        <div className="rounded-xl border border-slate-800 bg-slate-900 text-slate-100 overflow-hidden shadow-xs">
          <div className="px-4 py-2.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
            <span className="text-xs font-mono text-slate-300">Python Client (requests)</span>
            <button
              id="copy-python-btn"
              onClick={copyPython}
              className="text-xs text-teal-400 hover:text-teal-300 flex items-center gap-1 font-mono"
            >
              {copiedPython ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copiedPython ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
          <pre className="p-3 text-[11px] font-mono text-slate-300 overflow-x-auto">{pythonCode}</pre>
        </div>
      </div>

      {/* Code & Notebook Execution Terminal */}
      <ExperimentCodeViewer experimentId={7} />
    </div>
  );
}
