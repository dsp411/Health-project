'use client';

import React from 'react';
import { Target, Users, ShieldAlert, Award, FileText, CheckCircle, ArrowRight, AlertTriangle } from 'lucide-react';
import ExperimentCodeViewer from '@/components/ExperimentCodeViewer';

export default function Exp1Objective() {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 mb-2">
              <span>Experiment 1</span>
              <span>•</span>
              <span>1.5 Hours Scheduled</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Objective & Problem Formulation</h2>
            <p className="text-slate-600 text-sm mt-1 max-w-3xl">
              1-page Problem Definition Document: Translating the clinical triage brief into a formal Machine Learning formulation with clinical success metrics and constraint boundaries.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-xs px-3 py-1 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 font-medium">
              Target: Outcome (0 or 1)
            </span>
            <span className="text-xs px-3 py-1 rounded-md bg-amber-50 text-amber-800 border border-amber-200 font-medium">
              Primary KPI: Recall (Sensitivity)
            </span>
          </div>
        </div>
      </div>

      {/* Case Brief Box */}
      <div className="rounded-xl border border-indigo-100 bg-indigo-50/50 p-5">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-lg bg-indigo-600 text-white mt-0.5">
            <FileText className="h-5 w-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-indigo-950 uppercase tracking-wider">Clinical Case Brief</h3>
            <p className="text-sm text-indigo-900 mt-1 italic leading-relaxed">
              &ldquo;A busy primary-care clinic wants a rapid point-of-care screening tool to flag female patients at elevated risk of type-2 diabetes based on routine diagnostic measurements, so clinic staff can proactively prioritise high-risk individuals for formal confirmatory laboratory testing (fasting glucose, HbA1c) and preventative lifestyle intervention before microvascular complications develop.&rdquo;
            </p>
          </div>
        </div>
      </div>

      {/* Core Specification Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Card 1: Machine Learning Formulation */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center gap-2 mb-3">
            <Target className="h-5 w-5 text-teal-600" />
            <h3 className="font-semibold text-slate-900">Machine Learning Formulation</h3>
          </div>
          <dl className="space-y-3 text-sm">
            <div>
              <dt className="text-xs font-semibold text-slate-500 uppercase">Learning Paradigm</dt>
              <dd className="text-slate-900 font-medium mt-0.5">Supervised Binary Classification</dd>
            </div>
            <div>
              <dt className="text-xs font-semibold text-slate-500 uppercase">Input Vector (X ∈ ℝ⁸)</dt>
              <dd className="text-slate-700 mt-0.5">
                8 routine diagnostic features: <code className="text-xs bg-slate-100 px-1 py-0.5 rounded">Pregnancies</code>, <code className="text-xs bg-slate-100 px-1 py-0.5 rounded">Glucose</code>, <code className="text-xs bg-slate-100 px-1 py-0.5 rounded">BloodPressure</code>, <code className="text-xs bg-slate-100 px-1 py-0.5 rounded">SkinThickness</code>, <code className="text-xs bg-slate-100 px-1 py-0.5 rounded">Insulin</code>, <code className="text-xs bg-slate-100 px-1 py-0.5 rounded">BMI</code>, <code className="text-xs bg-slate-100 px-1 py-0.5 rounded">DiabetesPedigreeFunction</code>, <code className="text-xs bg-slate-100 px-1 py-0.5 rounded">Age</code>.
              </dd>
            </div>
            <div>
              <dt className="text-xs font-semibold text-slate-500 uppercase">Target Variable (Y ∈ &#123;0, 1&#125;)</dt>
              <dd className="text-slate-900 font-medium mt-0.5 flex items-center gap-3">
                <span className="inline-flex items-center gap-1 text-slate-700">
                  <span className="h-2 w-2 rounded-full bg-slate-400" />
                  <strong>0</strong> = Non-Diabetic (Healthy / Normal)
                </span>
                <span className="inline-flex items-center gap-1 text-rose-700">
                  <span className="h-2 w-2 rounded-full bg-rose-500" />
                  <strong>1</strong> = Diabetic (Positive Case)
                </span>
              </dd>
            </div>
            <div>
              <dt className="text-xs font-semibold text-slate-500 uppercase">Model Output</dt>
              <dd className="text-slate-700 mt-0.5">
                Calibrated probability <code className="text-xs bg-slate-100 px-1 py-0.5 rounded">P(Outcome = 1 | X)</code> mapped to Clinical Triage Risk Tiers (Low &lt;38%, Moderate 38-65%, High &gt;65%).
              </dd>
            </div>
          </dl>
        </div>

        {/* Card 2: Success Metrics & Cost Asymmetry */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center gap-2 mb-3">
            <Award className="h-5 w-5 text-amber-600" />
            <h3 className="font-semibold text-slate-900">Success Metric & Clinical Cost Matrix</h3>
          </div>
          <div className="space-y-3 text-sm">
            <div className="rounded-lg bg-amber-50 p-3 border border-amber-200 text-amber-900 text-xs leading-relaxed">
              <strong>Clinical Imperative:</strong> In primary care screening, <em>False Negatives</em> (missing a diabetic patient) are far costlier than <em>False Positives</em> (a false alarm prompting an inexpensive blood test). Hence, <strong>Recall (Sensitivity ≥ 80%)</strong> is our primary optimization criterion.
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="rounded-md border border-rose-200 bg-rose-50/50 p-2.5">
                <span className="font-bold text-rose-800">False Negative (FN)</span>
                <p className="text-rose-900 mt-1 text-[11px]">
                  <strong>Consequence: Severe.</strong> Missed early diagnosis; disease progresses silently to retinopathy, nephropathy, or cardiovascular events.
                </p>
              </div>
              <div className="rounded-md border border-slate-200 bg-slate-50 p-2.5">
                <span className="font-bold text-slate-800">False Positive (FP)</span>
                <p className="text-slate-700 mt-1 text-[11px]">
                  <strong>Consequence: Low-Moderate.</strong> Patient receives confirmatory Fasting Plasma Glucose / HbA1c ($25 test). Cleared on lab review.
                </p>
              </div>
            </div>

            <div className="pt-1">
              <span className="text-xs font-semibold text-slate-500 uppercase">Target Evaluation Benchmarks</span>
              <ul className="mt-1 space-y-1 text-xs text-slate-700">
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3.5 w-3.5 text-emerald-600" />
                  <span>Recall (Sensitivity): <strong>≥ 80.0%</strong></span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3.5 w-3.5 text-emerald-600" />
                  <span>ROC-AUC Discriminative Power: <strong>≥ 0.85</strong></span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-3.5 w-3.5 text-emerald-600" />
                  <span>Specificity: <strong>≥ 75.0%</strong> to prevent laboratory overload</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Card 3: Stakeholders */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center gap-2 mb-3">
            <Users className="h-5 w-5 text-blue-600" />
            <h3 className="font-semibold text-slate-900">Clinical Stakeholder Mapping</h3>
          </div>
          <div className="space-y-2.5 text-xs text-slate-700">
            <div className="p-2 rounded bg-slate-50 border border-slate-100">
              <strong className="text-slate-900">Primary Care Physicians (PCPs):</strong>
              <p className="text-slate-600 mt-0.5">Need instant (&lt;100ms) risk scoring during standard 15-minute consultations with plain-English physiological risk factor explanations.</p>
            </div>
            <div className="p-2 rounded bg-slate-50 border border-slate-100">
              <strong className="text-slate-900">Patients:</strong>
              <p className="text-slate-600 mt-0.5">Benefit from early non-invasive screening, transparent risk education, and timely lifestyle counseling to halt prediabetes progression.</p>
            </div>
            <div className="p-2 rounded bg-slate-50 border border-slate-100">
              <strong className="text-slate-900">Clinical Pathology Lab:</strong>
              <p className="text-slate-600 mt-0.5">Prioritized testing queue ensures high pre-test probability, optimizing reagent usage and clinician throughput.</p>
            </div>
          </div>
        </div>

        {/* Card 4: Constraints & Governance */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center gap-2 mb-3">
            <ShieldAlert className="h-5 w-5 text-rose-600" />
            <h3 className="font-semibold text-slate-900">Operating Constraints & Clinical Governance</h3>
          </div>
          <div className="space-y-2.5 text-xs text-slate-700">
            <div className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-teal-600 shrink-0 mt-0.5" />
              <span><strong>Latency SLA:</strong> Inference runtime must be &lt;200ms for seamless integration into Electronic Health Record (EHR) workflows.</span>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-teal-600 shrink-0 mt-0.5" />
              <span><strong>Model Explainability:</strong> Black-box predictions forbidden; model must expose feature-level attribution (e.g. elevated glucose, BMI).</span>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-teal-600 shrink-0 mt-0.5" />
              <span><strong>Decision Support Only:</strong> Tool explicitly functions as Clinical Decision Support (CDS), requiring physician confirmation prior to therapy.</span>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-teal-600 shrink-0 mt-0.5" />
              <span><strong>Zero-Value Data Quality Rule:</strong> Missing biological zero entries (e.g. Glucose = 0) must be imputed during pipeline preprocessing.</span>
            </div>
          </div>
        </div>
      </div>

      {/* Code & Notebook Execution Terminal */}
      <ExperimentCodeViewer experimentId={1} />
    </div>
  );
}
