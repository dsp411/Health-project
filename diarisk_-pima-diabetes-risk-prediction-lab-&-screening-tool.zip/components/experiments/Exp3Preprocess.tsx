'use client';

import React, { useState } from 'react';
import { Sliders, Copy, Check, ArrowRight, ShieldCheck, Cpu, RefreshCw, BarChart2 } from 'lucide-react';
import { DATASET_STATS, SCALER_PARAMS } from '@/lib/mlEngine';
import ExperimentCodeViewer from '@/components/ExperimentCodeViewer';

export default function Exp3Preprocess() {
  const [copied, setCopied] = useState(false);
  const [activeStrategy, setActiveStrategy] = useState<'median' | 'knn' | 'mean'>('median');
  const [showNormalized, setShowNormalized] = useState(false);

  const pythonPipelineCode = `import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
import joblib

# 1. Load Raw Pima Indians Diabetes CSV
df = pd.read_csv('pima_diabetes_raw.csv')

# 2. Biological Zero Handling: Replace implausible zeros with NaN
zero_fields = ['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI']
for col in zero_fields:
    df[col] = df[col].replace(0, np.nan)

# 3. Separate Predictors and Target
X = df.drop(columns=['Outcome'])
y = df['Outcome']

# 4. Stratified Train / Test Split (80% Train, 20% Held-Out Test)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

# 5. Scikit-Learn Preprocessing Pipeline
num_features = X.columns.tolist()
preprocessor = Pipeline([
    ('imputer', SimpleImputer(strategy='${activeStrategy}')), # ${activeStrategy} imputation
    ('scaler', StandardScaler())                 # Z-score standardization
])

# 6. Fit pipeline on Training Set ONLY (prevent data leakage)
X_train_processed = preprocessor.fit_transform(X_train)
X_test_processed = preprocessor.transform(X_test)

# 7. Persist Pipeline Artifact
joblib.dump(preprocessor, 'pima_preprocessing_pipeline.pkl')
print(f"Preprocessed Train shape: {X_train_processed.shape}, Test shape: {X_test_processed.shape}")
`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(pythonPipelineCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const zeroStats = [
    { feature: 'Insulin', rawZeros: 374, pct: 48.7, clinicalReason: '2h fasting insulin challenge omitted or below test detection limit', medianVal: 102.5 },
    { feature: 'SkinThickness', rawZeros: 227, pct: 29.6, clinicalReason: 'Triceps skinfold caliper measurement skipped', medianVal: 27.0 },
    { feature: 'BloodPressure', rawZeros: 35, pct: 4.6, clinicalReason: 'Sphygmomanometer reading missing / unrecorded', medianVal: 72.0 },
    { feature: 'BMI', rawZeros: 11, pct: 1.4, clinicalReason: 'Height or weight scale uncalibrated', medianVal: 32.0 },
    { feature: 'Glucose', rawZeros: 5, pct: 0.7, clinicalReason: 'Laboratory glucometer test unlogged', medianVal: 117.0 },
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 mb-2">
              <span>Experiment 3</span>
              <span>•</span>
              <span>2.0 Hours Scheduled</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Data Pre-Processing Pipeline</h2>
            <p className="text-slate-600 text-sm mt-1 max-w-3xl">
              Transforming raw clinical records into train-ready vectors: Zero-value imputation, feature scaling, leakage prevention, and scikit-learn pipeline serialization.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 font-medium">
              Zero Leakage Architecture
            </span>
          </div>
        </div>
      </div>

      {/* 4-Step Pipeline Stepper */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <div className="flex items-center gap-2 text-indigo-600 mb-1.5">
            <span className="h-6 w-6 rounded-full bg-indigo-100 flex items-center justify-center font-bold text-xs">1</span>
            <span className="font-semibold text-xs text-slate-900">Zero-Audit</span>
          </div>
          <p className="text-xs text-slate-600">Detect physiologically impossible zero readings across 5 vital signs.</p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <div className="flex items-center gap-2 text-indigo-600 mb-1.5">
            <span className="h-6 w-6 rounded-full bg-indigo-100 flex items-center justify-center font-bold text-xs">2</span>
            <span className="font-semibold text-xs text-slate-900">Median Imputation</span>
          </div>
          <p className="text-xs text-slate-600">Replace missing biological zeroes with training median (skew-resistant).</p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <div className="flex items-center gap-2 text-indigo-600 mb-1.5">
            <span className="h-6 w-6 rounded-full bg-indigo-100 flex items-center justify-center font-bold text-xs">3</span>
            <span className="font-semibold text-xs text-slate-900">Z-Score Scaling</span>
          </div>
          <p className="text-xs text-slate-600">Standardize features (μ=0, σ=1) for gradient descent & distance stability.</p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <div className="flex items-center gap-2 text-indigo-600 mb-1.5">
            <span className="h-6 w-6 rounded-full bg-indigo-100 flex items-center justify-center font-bold text-xs">4</span>
            <span className="font-semibold text-xs text-slate-900">Stratified Split</span>
          </div>
          <p className="text-xs text-slate-600">80/20 train/test split maintaining 34.9% positive class ratio.</p>
        </div>
      </div>

      {/* Zero Anomaly Inspection Table */}
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-xs">
        <div className="border-b border-slate-200 bg-slate-50/75 px-5 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sliders className="h-4 w-4 text-teal-600" />
            <h3 className="font-semibold text-slate-900 text-sm">Biological Zero-Value Anomaly Audit & Imputation Strategy</h3>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-medium">Selected Imputer:</span>
            <span className="text-xs px-2.5 py-0.5 rounded-md bg-teal-100 text-teal-800 font-bold">
              Median (Robust to Outliers)
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 uppercase font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-4">Biomarker</th>
                <th className="py-2.5 px-4">Raw Zero Count</th>
                <th className="py-2.5 px-4">Missingness %</th>
                <th className="py-2.5 px-4">Clinical Context</th>
                <th className="py-2.5 px-4">Imputed Value</th>
                <th className="py-2.5 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {zeroStats.map((item) => (
                <tr key={item.feature} className="hover:bg-slate-50/80">
                  <td className="py-3 px-4 font-semibold text-slate-900">{item.feature}</td>
                  <td className="py-3 px-4 font-mono font-medium text-rose-600">{item.rawZeros} rows</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-slate-100 rounded-full h-1.5 overflow-hidden">
                        <div className="bg-rose-500 h-1.5 rounded-full" style={{ width: `${item.pct}%` }} />
                      </div>
                      <span className="font-mono text-slate-700">{item.pct}%</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-slate-600 max-w-sm">{item.clinicalReason}</td>
                  <td className="py-3 px-4 font-mono font-bold text-teal-700">{item.medianVal}</td>
                  <td className="py-3 px-4">
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                      <Check className="h-3 w-3" /> Resolved
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Split & Normalization Parameters Card */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <h3 className="font-semibold text-slate-900 text-sm mb-3 flex items-center gap-2">
            <Cpu className="h-4 w-4 text-indigo-600" />
            <span>Dataset Stratified Split Breakdown</span>
          </h3>
          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between font-medium text-slate-700 mb-1">
                <span>Training Cohort (80%)</span>
                <span>614 Patients (214 Diabetic, 400 Non-Diabetic)</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden flex">
                <div className="bg-indigo-600 h-3" style={{ width: '65.1%' }} title="Non-diabetic" />
                <div className="bg-rose-500 h-3" style={{ width: '34.9%' }} title="Diabetic" />
              </div>
            </div>

            <div>
              <div className="flex justify-between font-medium text-slate-700 mb-1">
                <span>Held-Out Test Cohort (20%)</span>
                <span>154 Patients (54 Diabetic, 100 Non-Diabetic)</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden flex">
                <div className="bg-indigo-600 h-3" style={{ width: '65.1%' }} />
                <div className="bg-rose-500 h-3" style={{ width: '34.9%' }} />
              </div>
            </div>

            <div className="rounded-lg bg-slate-50 p-3 border border-slate-200 text-slate-600 space-y-1">
              <p><strong>Stratification Guarantee:</strong> Both splits preserve the exact 34.9% positive class balance.</p>
              <p><strong>Leakage Prevention:</strong> StandardScaler and SimpleImputer are fitted strictly on the 614 training records, and applied as frozen transforms to test queries.</p>
            </div>
          </div>
        </div>

        {/* Feature Scaler Parameters */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <h3 className="font-semibold text-slate-900 text-sm mb-3 flex items-center gap-2">
            <BarChart2 className="h-4 w-4 text-teal-600" />
            <span>Fitted Scaler Parameters (Z-Score μ, σ)</span>
          </h3>
          <div className="grid grid-cols-2 gap-2 text-xs">
            {Object.entries(SCALER_PARAMS).map(([k, v]) => (
              <div key={k} className="p-2 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-mono font-bold text-slate-800">{k}</span>
                <div className="flex justify-between text-[11px] text-slate-500 mt-1">
                  <span>μ: {v.mean}</span>
                  <span>σ: {v.std}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scikit-Learn Python Pipeline Export */}
      <div className="rounded-xl border border-slate-800 bg-slate-900 text-slate-100 overflow-hidden shadow-sm">
        <div className="px-5 py-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <span className="font-mono text-xs text-slate-400">pipeline_export.py • scikit-learn Pipeline</span>
          <button
            id="copy-pipeline-code-btn"
            onClick={copyToClipboard}
            className="flex items-center gap-1.5 text-xs text-teal-400 hover:text-teal-300 font-medium px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 transition"
          >
            {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
            <span>{copied ? 'Copied to Clipboard' : 'Copy Code'}</span>
          </button>
        </div>
        <pre className="p-4 text-xs font-mono overflow-x-auto text-emerald-400 leading-relaxed max-h-72">
          {pythonPipelineCode}
        </pre>
      </div>

      {/* Code & Notebook Execution Terminal */}
      <ExperimentCodeViewer experimentId={3} />
    </div>
  );
}
