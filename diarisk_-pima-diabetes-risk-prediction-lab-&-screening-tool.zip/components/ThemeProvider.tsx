'use client';

import React, { createContext, useContext, useSyncExternalStore } from 'react';

type Theme = 'light' | 'dark';

interface ThemeContextType {
  theme: Theme;
  toggleTheme: () => void;
  setTheme: (theme: Theme) => void;
}

function applyTheme(t: Theme) {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;
  if (t === 'dark') {
    root.classList.add('dark');
    root.style.colorScheme = 'dark';
  } else {
    root.classList.remove('dark');
    root.style.colorScheme = 'light';
  }
}

function readStoredTheme(): Theme {
  if (typeof window === 'undefined') return 'light';
  try {
    const savedTheme = localStorage.getItem('diarisk-theme') as Theme | null;
    if (savedTheme === 'dark' || savedTheme === 'light') {
      return savedTheme;
    }
  } catch {
    // Storage access blocked
  }
  // Default to light mode (Apple White Gallery design system)
  return 'light';
}

let themeStoreValue: Theme = 'light';
if (typeof window !== 'undefined') {
  themeStoreValue = readStoredTheme();
  applyTheme(themeStoreValue);
}

const themeListeners = new Set<() => void>();

function subscribeTheme(callback: () => void) {
  themeListeners.add(callback);
  return () => {
    themeListeners.delete(callback);
  };
}

function getThemeSnapshot(): Theme {
  return themeStoreValue;
}

function getThemeServerSnapshot(): Theme {
  return 'light';
}

function updateTheme(newTheme: Theme) {
  themeStoreValue = newTheme;
  applyTheme(newTheme);
  try {
    localStorage.setItem('diarisk-theme', newTheme);
  } catch {
    // Storage access blocked
  }
  themeListeners.forEach((listener) => listener());
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const theme = useSyncExternalStore(subscribeTheme, getThemeSnapshot, getThemeServerSnapshot);

  const setTheme = (newTheme: Theme) => {
    updateTheme(newTheme);
  };

  const toggleTheme = () => {
    const next = theme === 'light' ? 'dark' : 'light';
    updateTheme(next);
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) {
    return {
      theme: 'light' as Theme,
      toggleTheme: () => {},
      setTheme: () => {},
    };
  }
  return context;
}
