'use client';

import React from 'react';
import { AlertCircle, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface RiskGaugeProps {
  score: number; // 0 to 100
  probability: number; // 0.0 to 1.0
  threshold?: number; // default 0.45
  riskLevel: 'LOW' | 'MODERATE' | 'HIGH';
  urgency: string;
}

export default function RiskGauge({
  score,
  threshold = 0.45,
  riskLevel,
  urgency,
}: RiskGaugeProps) {
  const clampedScore = Math.max(0, Math.min(100, Math.round(score)));
  // Needle angle: -90 deg is 0% (left horizontal), 0 deg is 50% (vertical up), +90 deg is 100% (right horizontal)
  const needleAngle = -90 + (clampedScore / 100) * 180;
  const thresholdAngle = -90 + threshold * 180;

  // Geometry: SVG view box 240 x 135
  const cx = 120;
  const cy = 115;
  const r = 82;

  const colorMap = {
    LOW: {
      text: 'text-emerald-700 dark:text-emerald-300',
      scoreText: 'text-emerald-700 dark:text-emerald-400',
      badge: 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
      needle: '#059669',
      icon: CheckCircle2,
      label: 'Low Risk',
      iconColor: 'text-emerald-600 dark:text-emerald-400',
    },
    MODERATE: {
      text: 'text-amber-800 dark:text-amber-300',
      scoreText: 'text-amber-700 dark:text-amber-400',
      badge: 'bg-amber-50 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300 border-amber-200 dark:border-amber-800',
      needle: '#d97706',
      icon: AlertTriangle,
      label: 'Moderate Risk',
      iconColor: 'text-amber-600 dark:text-amber-400',
    },
    HIGH: {
      text: 'text-rose-800 dark:text-rose-300',
      scoreText: 'text-rose-700 dark:text-rose-400',
      badge: 'bg-rose-50 text-rose-800 dark:bg-rose-950/70 dark:text-rose-300 border-rose-200 dark:border-rose-800',
      needle: '#dc2626',
      icon: AlertCircle,
      label: 'High Clinical Risk',
      iconColor: 'text-rose-600 dark:text-rose-400',
    },
  };

  const currentConfig = colorMap[riskLevel] || colorMap.LOW;
  const StatusIcon = currentConfig.icon;

  return (
    <div
      id="annual-risk-gauge-container"
      className="annual-risk-gauge-container flex flex-col items-center justify-center select-none w-full max-w-[280px] mx-auto py-2"
    >
      {/* 1. Dedicated Stage Container Wrapper for Meter Arc & Pin Assembly (CSS Flexbox) */}
      <div
        id="meter-pin-stage-container"
        className="meter-pin-stage-container relative w-[240px] h-[135px] flex items-center justify-center shrink-0"
      >
        <svg
          viewBox="0 0 240 135"
          className="w-full h-full overflow-visible"
          aria-label={`Annual diabetes risk gauge displaying ${score}% probability`}
        >
          <defs>
            <linearGradient id="clinicalGaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#059669" />
              <stop offset="35%" stopColor="#10b981" />
              <stop offset="65%" stopColor="#d97706" />
              <stop offset="100%" stopColor="#dc2626" />
            </linearGradient>
          </defs>

          {/* Background Outer Arc Track */}
          <path
            d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
            fill="none"
            stroke="currentColor"
            className="text-slate-200 dark:text-slate-800"
            strokeWidth="14"
            strokeLinecap="round"
          />

          {/* Active Color Gradient Track */}
          <path
            d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
            fill="none"
            stroke="url(#clinicalGaugeGradient)"
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray="258"
            strokeDashoffset={258 - (clampedScore / 100) * 258}
            className="transition-all duration-500 ease-out"
          />

          {/* Cutoff / Threshold Notch */}
          {(() => {
            const rad = ((thresholdAngle - 90) * Math.PI) / 180;
            const x1 = cx + (r - 7) * Math.cos(rad);
            const y1 = cy + (r - 7) * Math.sin(rad);
            const x2 = cx + (r + 7) * Math.cos(rad);
            const y2 = cy + (r + 7) * Math.sin(rad);
            return (
              <g id="threshold-marker">
                <line
                  x1={x1}
                  y1={y1}
                  x2={x2}
                  y2={y2}
                  stroke="currentColor"
                  className="text-slate-800 dark:text-slate-200"
                  strokeWidth="2.5"
                />
                <circle cx={x2} cy={y2} r="2.5" fill="currentColor" className="text-slate-800 dark:text-slate-200" />
              </g>
            );
          })()}

          {/* Calibrated Tick Marks: 0%, 50%, 100% */}
          <text
            x={cx - r}
            y={cy + 16}
            fontSize="10"
            fontWeight="600"
            fill="currentColor"
            textAnchor="middle"
            className="font-mono text-slate-500 dark:text-slate-400"
          >
            0%
          </text>
          <text
            x={cx}
            y={cy - r - 8}
            fontSize="10"
            fontWeight="600"
            fill="currentColor"
            textAnchor="middle"
            className="font-mono text-slate-500 dark:text-slate-400"
          >
            50%
          </text>
          <text
            x={cx + r}
            y={cy + 16}
            fontSize="10"
            fontWeight="600"
            fill="currentColor"
            textAnchor="middle"
            className="font-mono text-slate-500 dark:text-slate-400"
          >
            100%
          </text>

          {/* Central Needle & Pin Assembly Container Group */}
          <g id="needle-pin-assembly">
            {/* Rotating Precision Indicator Needle */}
            <g
              id="gauge-needle"
              style={{
                transformOrigin: `${cx}px ${cy}px`,
                transform: `rotate(${needleAngle}deg)`,
                transition: 'transform 0.45s cubic-bezier(0.34, 1.3, 0.64, 1)',
              }}
            >
              {/* Needle shaft */}
              <line
                x1={cx}
                y1={cy}
                x2={cx}
                y2={cy - r + 8}
                stroke="currentColor"
                className="text-slate-800 dark:text-slate-100"
                strokeWidth="3"
                strokeLinecap="round"
              />
              {/* Arrowhead / Tip indicator */}
              <polygon
                points={`${cx - 4},${cy - r + 15} ${cx + 4},${cy - r + 15} ${cx},${cy - r + 4}`}
                fill={currentConfig.needle}
              />
            </g>

            {/* Central Pivot Pin */}
            <circle
              id="gauge-pivot-pin-outer"
              cx={cx}
              cy={cy}
              r="8"
              fill="currentColor"
              className="text-slate-800 dark:text-slate-200 shadow-xs"
            />
            <circle
              id="gauge-pivot-pin-inner"
              cx={cx}
              cy={cy}
              r="4"
              fill="currentColor"
              className="text-white dark:text-slate-900"
            />
          </g>
        </svg>
      </div>

      {/* 2. Dedicated Annual Risk Readout Container (CSS Grid for structured row alignment) */}
      <div
        id="annual-risk-readout-container"
        className="annual-risk-readout-container grid grid-flow-row auto-rows-max gap-1.5 place-items-center text-center w-full mt-2"
      >
        {/* Large Bold Score Display */}
        <div id="annual-risk-score-display" className="flex items-baseline justify-center gap-1 leading-none">
          <span className={`text-5xl font-black font-mono tracking-tight ${currentConfig.scoreText}`}>
            {clampedScore}
          </span>
          <span className="text-2xl font-bold font-mono text-slate-500 dark:text-slate-400">%</span>
        </div>

        {/* Readout Caption */}
        <span id="annual-risk-score-label" className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
          Calculated Annual Risk
        </span>

        {/* Status Badge Container with clinical badge */}
        <div id="annual-risk-status-badge-wrapper" className="flex items-center justify-center mt-1">
          <span
            className={`inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold px-3 py-1 rounded-md border ${currentConfig.badge}`}
          >
            <StatusIcon className={`h-4 w-4 ${currentConfig.iconColor}`} />
            <span>{currentConfig.label}</span>
          </span>
        </div>

        {/* Urgency Container */}
        <div
          id="annual-risk-urgency-container"
          className="annual-risk-urgency-container flex items-center justify-center gap-1.5 px-3 py-1 rounded-md text-xs font-medium bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs mt-1"
        >
          <span className="text-slate-500 dark:text-slate-400">Clinical Follow-up:</span>
          <strong className="text-slate-800 dark:text-slate-200 font-semibold">{urgency}</strong>
        </div>
      </div>
    </div>
  );
}
