'use client';

import React, { useState } from 'react';
import { X, Send, Check } from 'lucide-react';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ContactModal({ isOpen, onClose }: ContactModalProps) {
  const [submitted, setSubmitted] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#f2f2f2] border border-[#1e1e1e] p-8 sm:p-10 shadow-2xl text-[#111111]">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 p-2 text-[#111111] hover:rotate-90 transition-transform duration-200"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-xs font-satoshi font-bold uppercase tracking-widest text-[#838282] mb-2">
          INQUIRY PROTOCOL // 01
        </div>
        <h2 className="font-clash font-bold text-3xl sm:text-4xl uppercase tracking-[-0.04em] mb-2">
          Contact Studio
        </h2>
        <p className="font-satoshi text-sm text-[#838282] font-light mb-8">
          Engage our typography and architectural systems practice for bespoke monographs and digital infrastructure.
        </p>

        {submitted ? (
          <div className="p-8 border border-[#111111] bg-white flex flex-col items-center justify-center text-center">
            <div className="w-12 h-12 rounded-full border border-[#111111] flex items-center justify-center mb-4">
              <Check className="w-6 h-6 text-[#111111]" />
            </div>
            <h3 className="font-clash font-bold text-xl uppercase mb-2">Transmission Received</h3>
            <p className="font-satoshi text-xs text-[#838282]">
              Our Zürich studio will review your parameters within 24 hours.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block font-satoshi text-xs font-bold uppercase tracking-wider mb-2">
                Name // Entity
              </label>
              <input
                required
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Dieter Rams"
                className="w-full bg-white border border-[#1e1e1e]/20 px-4 py-3 text-sm font-satoshi outline-none focus:border-[#111111] transition-colors"
              />
            </div>

            <div>
              <label className="block font-satoshi text-xs font-bold uppercase tracking-wider mb-2">
                Coordinates // Email
              </label>
              <input
                required
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="studio@architecture.ch"
                className="w-full bg-white border border-[#1e1e1e]/20 px-4 py-3 text-sm font-satoshi outline-none focus:border-[#111111] transition-colors"
              />
            </div>

            <div>
              <label className="block font-satoshi text-xs font-bold uppercase tracking-wider mb-2">
                Brief // Scope Requirements
              </label>
              <textarea
                required
                rows={3}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Outline your typographic or structural project parameters..."
                className="w-full bg-white border border-[#1e1e1e]/20 px-4 py-3 text-sm font-satoshi outline-none focus:border-[#111111] transition-colors resize-none"
              />
            </div>

            <button
              type="submit"
              className="w-full rounded-full border border-[#1e1e1e] bg-[#111111] text-[#f2f2f2] hover:bg-transparent hover:text-[#111111] py-3.5 text-xs font-satoshi font-bold uppercase tracking-widest transition-all duration-200 flex items-center justify-center gap-2 mt-4"
            >
              <span>Transmit Dispatch</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
