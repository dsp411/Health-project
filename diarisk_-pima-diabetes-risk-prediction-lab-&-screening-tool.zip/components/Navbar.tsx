'use client';

import React from 'react';
import { ArrowUpRight } from 'lucide-react';

interface NavbarProps {
  currentView?: 'clinical' | 'lab';
  setCurrentView?: (view: 'clinical' | 'lab') => void;
  activeTab?: 'screening' | 'lab';
  setActiveTab?: (tab: 'screening' | 'lab') => void;
  activeLabExp?: number;
  setActiveLabExp?: (exp: number) => void;
  onSelectExperiment?: (exp: number) => void;
}

export default function Navbar({
  activeTab = 'screening',
  setActiveTab,
}: NavbarProps) {
  const scrollToWorkspace = () => {
    if (setActiveTab) setActiveTab('screening');
    setTimeout(() => {
      const el = document.getElementById('clinical-workspace');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  return (
    <header className="sticky top-0 z-50 h-[80px] w-full bg-[#f2f2f2]/90 backdrop-blur-[12px] border-b border-[#1e1e1e]/10 transition-colors duration-200 print-hide">
      <div className="mx-auto flex h-full max-w-7xl items-center justify-between px-6 sm:px-10">
        {/* Brand / Logo */}
        <button
          onClick={() => {
            if (setActiveTab) setActiveTab('screening');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="flex items-center gap-3 text-left group cursor-pointer"
        >
          <div className="w-8 h-8 rounded-xs bg-[#111111] text-[#f2f2f2] flex items-center justify-center font-clash text-xs font-bold transition-transform group-hover:scale-105 duration-300">
            H1
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="font-clash font-bold text-sm tracking-tight text-[#111111] uppercase">
                Metabolic Intelligence
              </span>
              <span className="text-[10px] font-mono tracking-widest text-[#838282] uppercase">
                [PIMA·768]
              </span>
            </div>
            <span className="text-[11px] font-satoshi text-[#838282] uppercase tracking-wider">
              Health-Project 1 · Clinical DSS
            </span>
          </div>
        </button>

        {/* Action Button: Clean pill-shaped button with 1px border that inverts on hover */}
        <div>
          <button
            onClick={scrollToWorkspace}
            className="group relative inline-flex items-center gap-2 rounded-full border border-[#1e1e1e] bg-transparent px-5 py-2.5 text-[12px] uppercase font-satoshi font-semibold tracking-wider text-[#111111] transition-all duration-300 hover:bg-[#111111] hover:text-[#f2f2f2] cursor-pointer"
          >
            <span>Run Triage</span>
            <ArrowUpRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </button>
        </div>
      </div>
    </header>
  );
}
