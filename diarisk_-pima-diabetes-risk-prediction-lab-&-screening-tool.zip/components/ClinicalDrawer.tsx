'use client';

import React, { useState } from 'react';
import { X, FlaskConical, Stethoscope } from 'lucide-react';
import ClinicalScreening from './ClinicalScreening';
import LabStudio from './LabStudio';

interface ClinicalDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  defaultTab?: 'screening' | 'lab';
}

export default function ClinicalDrawer({ isOpen, onClose, defaultTab = 'screening' }: ClinicalDrawerProps) {
  const [activeTab, setActiveTab] = useState<'screening' | 'lab'>(defaultTab);
  const [activeExp, setActiveExp] = useState<number>(1);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#f2f2f2] overflow-y-auto animate-in slide-in-from-bottom duration-300">
      {/* Top Protocol Header */}
      <div className="sticky top-0 z-40 bg-[#f2f2f2]/95 backdrop-blur-md border-b border-[#1e1e1e]/15 px-4 sm:px-8 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-4 h-4 bg-[#111111]" />
          <div>
            <span className="font-clash font-bold text-base sm:text-lg text-[#111111] uppercase tracking-tight">
              CLINICAL INFORMATICS &amp; ML LAB
            </span>
            <span className="hidden sm:inline-block text-xs font-satoshi text-[#838282] ml-3 uppercase tracking-wider">
              PIMA INDIANS DIABETES TRIAGE MATRIX
            </span>
          </div>
        </div>

        {/* Tab Controls + Close */}
        <div className="flex items-center gap-3">
          <div className="flex items-center border border-[#1e1e1e]/20 p-0.5 rounded-full bg-white text-xs font-satoshi font-semibold">
            <button
              onClick={() => setActiveTab('screening')}
              className={`px-4 py-1.5 rounded-full transition-all flex items-center gap-1.5 ${
                activeTab === 'screening'
                  ? 'bg-[#111111] text-white shadow-sm'
                  : 'text-[#838282] hover:text-[#111111]'
              }`}
            >
              <Stethoscope className="w-3.5 h-3.5" />
              <span>SCREENING</span>
            </button>
            <button
              onClick={() => setActiveTab('lab')}
              className={`px-4 py-1.5 rounded-full transition-all flex items-center gap-1.5 ${
                activeTab === 'lab'
                  ? 'bg-[#111111] text-white shadow-sm'
                  : 'text-[#838282] hover:text-[#111111]'
              }`}
            >
              <FlaskConical className="w-3.5 h-3.5" />
              <span>LAB STUDIO</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="p-2 border border-[#1e1e1e]/20 rounded-full hover:bg-[#111111] hover:text-white transition-colors"
            aria-label="Close Clinical Protocol Drawer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Content Body */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-8">
        {activeTab === 'screening' ? (
          <ClinicalScreening onOpenLab={() => setActiveTab('lab')} />
        ) : (
          <LabStudio
            activeExp={activeExp}
            setActiveExp={setActiveExp}
            onLaunchScreening={() => setActiveTab('screening')}
          />
        )}
      </div>
    </div>
  );
}
