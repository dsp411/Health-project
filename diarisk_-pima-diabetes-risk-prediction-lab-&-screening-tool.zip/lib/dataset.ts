export interface PatientRecord {
  id: number;
  pregnancies: number;
  glucose: number;
  bloodPressure: number;
  skinThickness: number;
  insulin: number;
  bmi: number;
  diabetesPedigreeFunction: number;
  age: number;
  outcome: 0 | 1;
}

export const FEATURE_METADATA: Record<
  keyof Omit<PatientRecord, 'id' | 'outcome'>,
  {
    label: string;
    unit: string;
    description: string;
    normalRange: string;
    clinicalNote: string;
    min: number;
    max: number;
    step: number;
    defaultVal: number;
  }
> = {
  pregnancies: {
    label: 'Pregnancies',
    unit: 'count',
    description: 'Number of times pregnant',
    normalRange: '0 – 4 (clinical reference)',
    clinicalNote: 'Gestational diabetes history elevates long-term risk markedly.',
    min: 0,
    max: 17,
    step: 1,
    defaultVal: 2,
  },
  glucose: {
    label: 'Plasma Glucose',
    unit: 'mg/dL',
    description: 'Oral Glucose Tolerance Test (2 hours post-load)',
    normalRange: '70 – 99 mg/dL (Normal Fasting), < 140 mg/dL (2h OGTT)',
    clinicalNote: 'Primary diagnostic hallmark. Levels ≥ 140 mg/dL indicate impaired tolerance, ≥ 200 mg/dL diagnostic.',
    min: 44,
    max: 200,
    step: 1,
    defaultVal: 120,
  },
  bloodPressure: {
    label: 'Diastolic BP',
    unit: 'mm Hg',
    description: 'Diastolic blood pressure',
    normalRange: '60 – 80 mm Hg',
    clinicalNote: 'Hypertension strongly clusters with metabolic syndrome and insulin resistance.',
    min: 24,
    max: 122,
    step: 1,
    defaultVal: 72,
  },
  skinThickness: {
    label: 'Triceps Skinfold',
    unit: 'mm',
    description: 'Triceps skin fold thickness measuring subcutaneous fat',
    normalRange: '10 – 30 mm',
    clinicalNote: 'Anthropometric surrogate for peripheral adiposity.',
    min: 7,
    max: 99,
    step: 1,
    defaultVal: 27,
  },
  insulin: {
    label: 'Serum Insulin',
    unit: 'μU/mL',
    description: '2-Hour serum insulin test',
    normalRange: '16 – 166 μU/mL',
    clinicalNote: 'Elevated fasting/challenge insulin signifies hyperinsulinemia & peripheral insulin resistance.',
    min: 14,
    max: 846,
    step: 1,
    defaultVal: 102.5,
  },
  bmi: {
    label: 'Body Mass Index',
    unit: 'kg/m²',
    description: 'Weight in kg / (height in m)²',
    normalRange: '18.5 – 24.9 kg/m²',
    clinicalNote: 'Overweight (25–29.9) and Obese (≥30) drastically increase peripheral insulin resistance.',
    min: 18.2,
    max: 67.1,
    step: 0.1,
    defaultVal: 32.0,
  },
  diabetesPedigreeFunction: {
    label: 'Diabetes Pedigree',
    unit: 'score',
    description: 'Genetic score scoring diabetes likelihood based on family history',
    normalRange: '0.08 – 0.50 (low/average genetic loading)',
    clinicalNote: 'Quantifies genetic predisposition synthesis using familial pedigree relations.',
    min: 0.078,
    max: 2.42,
    step: 0.001,
    defaultVal: 0.375,
  },
  age: {
    label: 'Age',
    unit: 'years',
    description: 'Patient age in years',
    normalRange: '21 – 81 years',
    clinicalNote: 'Beta-cell function declines progressively with age; risk increases sharply past 35–45.',
    min: 21,
    max: 81,
    step: 1,
    defaultVal: 33,
  },
};
