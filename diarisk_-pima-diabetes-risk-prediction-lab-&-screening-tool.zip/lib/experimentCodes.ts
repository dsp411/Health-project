export interface ExperimentNotebookCode {
  id: number;
  title: string;
  subtitle: string;
  filename: string;
  author: string;
  studentId: string;
  libraries: string[];
  aim: string;
  theory: string;
  inputs: string;
  outputsSummary: string;
  code: string;
  terminalOutput: string;
  keyInsights: string[];
}

export const EXPERIMENT_CODES: Record<number, ExperimentNotebookCode> = {
  1: {
    id: 1,
    title: 'Objective Definition',
    subtitle: 'Health-Project 1: Diabetes Risk Prediction | Objective Definition',
    filename: 'exp1_objective.py',
    author: 'Dilpreet Singh',
    studentId: '230160223002',
    libraries: ['os', 'json', 'textwrap'],
    aim: 'To read the clinic case brief and prepare a one-page Problem Definition Document for diabetes risk prediction: problem statement, ML experiment type, target variable, success metric (KPI), stakeholders and constraints.',
    theory: 'Every machine learning project starts by turning a business need into a measurable ML task. The target variable is what the model predicts, and the ML formulation follows from the type of target. Here Outcome has two values (0=Non-diabetic, 1=Diabetic), so the task is supervised binary classification. In screening, a False Negative delays treatment while a False Positive only adds one confirmatory test. Recall (Sensitivity = TP/(TP+FN)) is chosen as the primary KPI, supported by Precision, F1-score and ROC-AUC.',
    inputs: 'Case brief: "A primary-care clinic wants a quick screening tool to flag patients at high risk of diabetes based on routine diagnostic measurements, so they can be prioritised for confirmatory testing." Pima Indians Diabetes Database, diabetes.csv, 768 records, 8 features, binary Outcome.',
    outputsSummary: 'Problem Definition Document (JSON), KPI formulas, stakeholders and constraint matrix.',
    code: `import os
import json
import textwrap

# ---------- 1. Case brief ----------
case_brief = ("A primary-care clinic wants a quick screening tool to flag patients at "
              "high risk of diabetes based on routine diagnostic measurements, so they "
              "can be prioritised for confirmatory testing.")

# ---------- 2. Problem Definition Document ----------
problem = {
    "project": "Health-Project 1: Diabetes Risk Prediction",
    "problem_statement": "Predict whether a patient is likely to have diabetes from 8 routine "
                         "diagnostic measurements so high-risk patients get confirmatory tests early.",
    "ml_experiment_type": "Supervised Learning - Binary Classification",
    "target_variable": {"name": "Outcome", "values": {0: "Non-diabetic", 1: "Diabetic"}},
    "input_features": ["Pregnancies", "Glucose", "BloodPressure", "SkinThickness",
                       "Insulin", "BMI", "DiabetesPedigreeFunction", "Age"],
    "primary_metric_kpi": "Recall (Sensitivity) on the diabetic class",
    "secondary_metrics": ["Precision", "F1-score", "ROC-AUC", "Accuracy"],
    "metric_justification": "Missing a diabetic patient (False Negative) is costlier than a "
                            "false alarm (False Positive), so recall is prioritised.",
    "stakeholders": {
        "Clinic doctors / nurses": "Use risk score to prioritise patients",
        "Patients": "Benefit from early detection and intervention",
        "Clinic management": "Optimise testing cost and workload",
        "Data science team": "Build, deploy and maintain the model",
    },
    "constraints": [
        "Small dataset (768 records)",
        "Only female patients of Pima Indian heritage (limited generalisation)",
        "Patient data privacy and consent must be respected",
        "Tool is a screening aid, not a diagnosis",
        "Must run quickly on routine clinic data",
    ],
    "success_criteria": "Recall on diabetic class as high as possible with acceptable precision "
                        "(target agreed with clinic; final value set in Experiment 6)",
}

# ---------- 3. Display ----------
def show(text, indent=0):
    pad = " " * indent
    print(textwrap.fill(str(text), width=95, initial_indent=pad, subsequent_indent=pad + " "))

print("CASE BRIEF\\n" + "-" * 60)
show(case_brief)

print("\\nPROBLEM DEFINITION DOCUMENT\\n" + "-" * 60)
labels = {"ml_experiment_type": "ML Experiment Type", "primary_metric_kpi": "Primary Metric (KPI)"}
for key, val in problem.items():
    title = labels.get(key, key.replace("_", " ").title())
    if isinstance(val, dict):
        print(f"{title}:")
        for k, v in val.items():
            show(f"- {k}: {v}", 3)
    elif isinstance(val, list):
        print(f"{title}:")
        for item in val:
            show(f"- {item}", 3)
    else:
        show(f"{title}: {val}")

# ---------- 4. Metric formulas ----------
print("\\nKEY METRIC FORMULAS\\n" + "-" * 60)
print("Recall    = TP / (TP + FN)")
print("Precision = TP / (TP + FP)")
print("F1-score  = 2 * Precision * Recall / (Precision + Recall)")

# ---------- 5. Save document ----------
out_dir = "exp1_output"
os.makedirs(out_dir, exist_ok=True)
with open(os.path.join(out_dir, "problem_definition.json"), "w") as f:
    json.dump(problem, f, indent=4)
print(f"\\nSaved: {os.path.join(out_dir, 'problem_definition.json')}")`,
    terminalOutput: `CASE BRIEF
------------------------------------------------------------
A primary-care clinic wants a quick screening tool to flag patients at high risk of diabetes
 based on routine diagnostic measurements, so they can be prioritised for confirmatory
 testing.

PROBLEM DEFINITION DOCUMENT
------------------------------------------------------------
Project: Health-Project 1: Diabetes Risk Prediction
Problem Statement: Predict whether a patient is likely to have diabetes from 8 routine
 diagnostic measurements so high-risk patients get confirmatory tests early.
ML Experiment Type: Supervised Learning - Binary Classification
Target Variable:
 - name: Outcome
 - values: {0: 'Non-diabetic', 1: 'Diabetic'}
Input Features:
 - Pregnancies
 - Glucose
 - BloodPressure
 - SkinThickness
 - Insulin
 - BMI
 - DiabetesPedigreeFunction
 - Age
Primary Metric (KPI): Recall (Sensitivity) on the diabetic class
Secondary Metrics:
 - Precision
 - F1-score
 - ROC-AUC
 - Accuracy
Metric Justification: Missing a diabetic patient (False Negative) is costlier than a false
 alarm (False Positive), so recall is prioritised.
Stakeholders:
 - Clinic doctors / nurses: Use risk score to prioritise patients
 - Patients: Benefit from early detection and intervention
 - Clinic management: Optimise testing cost and workload
 - Data science team: Build, deploy and maintain the model
Constraints:
 - Small dataset (768 records)
 - Only female patients of Pima Indian heritage (limited generalisation)
 - Patient data privacy and consent must be respected
 - Tool is a screening aid, not a diagnosis
 - Must run quickly on routine clinic data
Success Criteria: Recall on diabetic class as high as possible with acceptable precision
 (target agreed with clinic; final value set in Experiment 6)

KEY METRIC FORMULAS
------------------------------------------------------------
Recall    = TP / (TP + FN)
Precision = TP / (TP + FP)
F1-score  = 2 * Precision * Recall / (Precision + Recall)

Saved: exp1_output/problem_definition.json`,
    keyInsights: [
      'Framed the clinical task as Supervised Binary Classification on 8 physiological variables.',
      'Recall on the diabetic class is prioritized as the primary KPI due to asymmetric clinical costs of False Negatives.',
      'Identified constraints: 768 female records, Pima Indian heritage, screening aid requirement, sub-second latency.',
    ],
  },

  2: {
    id: 2,
    title: 'Dataset Details',
    subtitle: 'Health-Project 1: Diabetes Risk Prediction | Dataset Details',
    filename: 'exp2_dataset.py',
    author: 'Dilpreet Singh',
    studentId: '230160223002',
    libraries: ['os', 'json', 'textwrap', 'numpy', 'pandas'],
    aim: 'To access and study the Pima Indians Diabetes Database, and to prepare a Dataset Description Report covering its source and license, size, feature and label dictionary, target distribution and known limitations.',
    theory: 'Before any pre-processing or modelling, the dataset must be understood. Schema inspection confirms the data loaded correctly. Class balance checks how the target is spread (imbalance ratio 1.87:1). Data-quality checks look for missing values, duplicates and impossible values (like Glucose or BMI = 0).',
    inputs: 'Kaggle/UCI Pima Indians Diabetes Database CSV, 768 records, 8 features and binary Outcome.',
    outputsSummary: 'dataset_description_report.json with schema, class distributions, invalid zeros check, and limitation matrix.',
    code: `# ======================================================================
# EXPERIMENT 2: DATASET DETAILS
# Project: Health-Project 1 - Diabetes Risk Prediction
# Environment: Jupyter Notebook
# ======================================================================
import os
import json
import textwrap
import numpy as np
import pandas as pd

pd.set_option("display.width", 110)
pd.set_option("display.max_columns", 20)

# 1. Locate and load the dataset (your PC path first, then current folder)
candidate_paths = [r"C:\\Users\\dilpr\\Downloads\\diabetes.csv", "diabetes.csv"]
dataset_path = next((p for p in candidate_paths if os.path.exists(p)), None)
if dataset_path is None:
    raise FileNotFoundError("diabetes.csv not found. Keep it in Downloads or the notebook folder.")
df = pd.read_csv(dataset_path)
TARGET = "Outcome"

def show(text, indent=0):
    pad = " " * indent
    print(textwrap.fill(str(text), width=100, initial_indent=pad, subsequent_indent=pad + " "))

# 2. Source and license
print("--- 1. DATASET SOURCE & LICENSE ---")
source_info = {
    "Name": "Pima Indians Diabetes Database",
    "Original owner": "National Institute of Diabetes and Digestive and Kidney Diseases (NIDDK)",
    "Access": "UCI Machine Learning Repository / Kaggle (diabetes.csv)",
    "License": "Public / open for research and education (Kaggle listing: CC0). Check the source page before reuse.",
    "Population": "Female patients, at least 21 years old, of Pima Indian heritage",
    "Local file": dataset_path,
}
for k, v in source_info.items():
    show(f"{k}: {v}")

# 3. Size and schema
print("\\n--- 2. SIZE & SCHEMA ---")
print("Records (rows) :", df.shape[0])
print("Columns        :", df.shape[1], "(8 features + 1 target)")
print(f"Memory usage   : {df.memory_usage(deep=True).sum() / 1024:.1f} KB")
print("\\nColumn data types:")
print(df.dtypes.to_string())
print("\\nFirst 5 records:")
print(df.head())

# 4. Feature / label dictionary
print("\\n--- 3. FEATURE / LABEL DICTIONARY ---")
dictionary = [
    ("Pregnancies", "Integer", "count", "Number of times the patient has been pregnant"),
    ("Glucose", "Integer", "mg/dL", "Plasma glucose 2 hours after an oral glucose tolerance test"),
    ("BloodPressure", "Float", "mm Hg", "Diastolic blood pressure"),
    ("SkinThickness", "Integer", "mm", "Triceps skin fold thickness"),
    ("Insulin", "Float", "mu U/ml", "2-hour serum insulin"),
    ("BMI", "Float", "kg/m^2", "Body mass index = weight / height squared"),
    ("DiabetesPedigreeFunction", "Float", "score", "Diabetes risk score based on family history"),
    ("Age", "Integer", "years", "Age of the patient"),
    ("Outcome", "Integer", "0 / 1", "TARGET: 0 = Non-diabetic, 1 = Diabetic"),
]
for name, dtype, unit, meaning in dictionary:
    show(f"{name} [{dtype}, {unit}] : {meaning}")

# 5. Summary statistics
print("\\n--- 4. SUMMARY STATISTICS ---")
print(df.describe().T[["mean", "std", "min", "50%", "max"]].round(2))

# 6. Target distribution
print("\\n--- 5. TARGET DISTRIBUTION (CLASS BALANCE) ---")
counts = df[TARGET].value_counts().sort_index()
props = df[TARGET].value_counts(normalize=True).sort_index() * 100
labels = {0: "Non-diabetic", 1: "Diabetic"}
for cls in counts.index:
    bar = "#" * int(round(props[cls] / 2))
    print(f"Class {cls} ({labels[cls]:12s}): {counts[cls]:4d} records {props[cls]:5.2f}% {bar}")
print(f"Imbalance ratio (majority:minority) = {counts.max() / counts.min():.2f} : 1")

# 7. Data-quality checks
print("\\n--- 6. DATA-QUALITY CHECKS ---")
print("Total missing values (NaN):", int(df.isnull().sum().sum()))
print("Duplicate rows            :", int(df.duplicated().sum()))
zero_check_cols = ["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"]
zero_counts = (df[zero_check_cols] == 0).sum()
print("\\nZero values in columns that cannot be 0 in a living patient:")
print(zero_counts.to_string())
print("Pregnancies equal to 0 (valid value):", int((df["Pregnancies"] == 0).sum()))

# 8. Save the Dataset Description Report
out_dir = "exp2_output"
os.makedirs(out_dir, exist_ok=True)
report = {
    "source": source_info,
    "n_records": int(df.shape[0]),
    "n_columns": int(df.shape[1]),
    "target_distribution": {labels[c]: int(counts[c]) for c in counts.index},
    "missing_values": int(df.isnull().sum().sum()),
    "duplicates": int(df.duplicated().sum()),
    "invalid_zero_counts": {k: int(v) for k, v in zero_counts.items()},
}
with open(os.path.join(out_dir, "dataset_description_report.json"), "w") as f:
    json.dump(report, f, indent=4)
print("\\nSaved:", os.path.join(out_dir, "dataset_description_report.json"))`,
    terminalOutput: `--- 1. DATASET SOURCE & LICENSE ---
Name: Pima Indians Diabetes Database
Original owner: National Institute of Diabetes and Digestive and Kidney Diseases (NIDDK)
Access: UCI Machine Learning Repository / Kaggle (diabetes.csv)
License: Public / open for research and education (Kaggle listing: CC0). Check the source page
 before reuse.
Population: Female patients, at least 21 years old, of Pima Indian heritage
Local file: C:\\Users\\dilpr\\Downloads\\diabetes.csv

--- 2. SIZE & SCHEMA ---
Records (rows) : 768
Columns        : 9 (8 features + 1 target)
Memory usage   : 54.1 KB

Column data types:
Pregnancies                   int64
Glucose                       int64
BloodPressure               float64
SkinThickness                 int64
Insulin                     float64
BMI                         float64
DiabetesPedigreeFunction    float64
Age                           int64
Outcome                       int64

--- 5. TARGET DISTRIBUTION (CLASS BALANCE) ---
Class 0 (Non-diabetic):  500 records 65.10% #################################
Class 1 (Diabetic    ):  268 records 34.90% #################
Imbalance ratio (majority:minority) = 1.87 : 1

Saved: exp2_output/dataset_description_report.json`,
    keyInsights: [
      '768 total records with 8 numerical features and binary target (Outcome).',
      'Target distribution: 500 Non-diabetic (65.10%) vs 268 Diabetic (34.90%), creating a 1.87:1 imbalance ratio.',
      'Identified physiologically impossible zeros (Glucose, BP, Skin, Insulin, BMI) which represent unrecorded clinical measurements.',
    ],
  },

  3: {
    id: 3,
    title: 'Data Pre-processing',
    subtitle: 'Health-Project 1: Diabetes Risk Prediction | Data Pre-processing',
    filename: 'exp3_preprocessing.py',
    author: 'Dilpreet Singh',
    studentId: '230160223002',
    libraries: ['os', 'joblib', 'numpy', 'pandas', 'sklearn (StandardScaler, train_test_split, compute_class_weight)'],
    aim: 'To preprocess the Pima Indians Diabetes Database and prepare a clean, scaled and split dataset for predicting diabetes risk in patients.',
    theory: 'Invalid zeros in Glucose, BloodPressure, SkinThickness, Insulin and BMI are converted to NaN and imputed rather than dropped. To avoid data leakage, data is split first (stratified 70% train / 15% val / 15% test). Medians and StandardScaler are learned strictly on the training set. Class weights (0.767 for class 0, 1.436 for class 1) are computed to counter the 1.87:1 class imbalance.',
    inputs: 'Raw diabetes.csv, 768 rows.',
    outputsSummary: 'full_cleaned_diabetes.csv, X/y train, validation, and test CSVs, standard_scaler.joblib, preprocessing_info.joblib.',
    code: `# ======================================================================
# EXPERIMENT 3: DATA PRE-PROCESSING
# Project: Health-Project 1 - Diabetes Risk Prediction
# Environment: Jupyter Notebook
# ======================================================================
import os
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.utils.class_weight import compute_class_weight

pd.set_option("display.width", 110)
pd.set_option("display.max_columns", 20)

# 1. Locate and load the dataset
candidate_dirs = [r"C:\\Users\\dilpr\\Downloads", "."]
BASE_DIR = next((d for d in candidate_dirs if os.path.exists(os.path.join(d, "diabetes.csv"))), None)
if BASE_DIR is None:
    raise FileNotFoundError("diabetes.csv not found. Keep it in Downloads or the notebook folder.")
dataset_path = os.path.join(BASE_DIR, "diabetes.csv")
print(f"Loading dataset from: {dataset_path}")
df = pd.read_csv(dataset_path)
TARGET = "Outcome"
feature_cols = [c for c in df.columns if c != TARGET]

# 2. Missing values and duplicates
df_clean = df.drop_duplicates().reset_index(drop=True)

# 3. Physiologically invalid zeros -> NaN
invalid_zero_cols = ["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"]
df_nan = df_clean.copy()
df_nan[invalid_zero_cols] = df_nan[invalid_zero_cols].replace(0, np.nan)

# 4. Stratified split: 70% train, 15% validation, 15% test (split BEFORE imputing)
X, y = df_nan[feature_cols].copy(), df_nan[TARGET].copy()
X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.30, random_state=42, stratify=y)
X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.50, random_state=42, stratify=y_temp)
X_train, X_val, X_test = X_train.copy(), X_val.copy(), X_test.copy()

print("\\n--- STRATIFIED TRAIN / VAL / TEST SPLIT ---")
for name, part in [("Training", y_train), ("Validation", y_val), ("Test", y_test)]:
    print(f"{name:10s}: {len(part):3d} records, {part.mean() * 100:.1f}% diabetic")

# 5. Imputation: medians learned from the TRAINING set only (no leakage)
class_medians = X_train.join(y_train).groupby(TARGET)[invalid_zero_cols].median()
overall_medians = X_train[invalid_zero_cols].median()
for col in invalid_zero_cols:
    X_train[col] = X_train[col].fillna(y_train.map(class_medians[col]))
    X_val[col] = X_val[col].fillna(overall_medians[col])
    X_test[col] = X_test[col].fillna(overall_medians[col])

print("\\nTraining medians used for imputation:")
print(overall_medians.round(2).to_string())

# 6. Feature scaling: fit on training only
scaler = StandardScaler()
X_train_scaled = pd.DataFrame(scaler.fit_transform(X_train), columns=feature_cols, index=X_train.index)
X_val_scaled = pd.DataFrame(scaler.transform(X_val), columns=feature_cols, index=X_val.index)
X_test_scaled = pd.DataFrame(scaler.transform(X_test), columns=feature_cols, index=X_test.index)

# 7. Class weights
weights = compute_class_weight("balanced", classes=np.array([0, 1]), y=y_train)
class_weights = {0: float(weights[0]), 1: float(weights[1])}
print("\\n--- CLASS WEIGHTS FOR MODEL TRAINING ---")
print({k: round(v, 3) for k, v in class_weights.items()})

# 8. Save datasets and pipeline artifacts
output_dir = os.path.join(BASE_DIR, "processed_diabetes_exp3")
os.makedirs(output_dir, exist_ok=True)
joblib.dump(scaler, os.path.join(output_dir, "standard_scaler.joblib"))
print("Saved artifacts to:", output_dir)`,
    terminalOutput: `--- 5. STRATIFIED TRAIN / VAL / TEST SPLIT ---
Training  : 537 records, 34.8% diabetic
Validation: 115 records, 34.8% diabetic
Test      : 116 records, 35.3% diabetic

--- 6. MEDIAN IMPUTATION (from training set) ---
Missing values left: 0
Training medians used for imputation:
Glucose        117.0
BloodPressure   72.0
SkinThickness   28.0
Insulin        102.5
BMI             32.4

--- 7. FEATURE SCALING (StandardScaler) ---
Scaled training mean (should be ~0): 0.0
Scaled training std (should be ~1): [1.]

--- 8. CLASS WEIGHTS FOR MODEL TRAINING ---
{0: 0.767, 1: 1.436}

Folder: processed_diabetes_exp3
X_test_scaled.csv, X_train_scaled.csv, X_val_scaled.csv, standard_scaler.joblib, preprocessing_info.joblib`,
    keyInsights: [
      'Split ratio: 537 train (70%), 115 validation (15%), 116 test (15%) preserving 34.9% stratification.',
      'Training medians used: Glucose 117.0, BP 72.0, SkinThickness 28.0, Insulin 102.5, BMI 32.4.',
      'Class weights computed: Class 0 = 0.767, Class 1 = 1.436 (balanced weight matrix for loss weighting).',
    ],
  },

  4: {
    id: 4,
    title: 'Data Exploration (EDA)',
    subtitle: 'Health-Project 1: Diabetes Risk Prediction | Data Exploration (EDA)',
    filename: 'exp4_eda.py',
    author: 'Dilpreet Singh',
    studentId: '230160223002',
    libraries: ['os', 'numpy', 'pandas', 'matplotlib.pyplot', 'seaborn'],
    aim: 'To perform Exploratory Data Analysis (EDA) on the cleaned dataset to study distributions, detect outliers, evaluate feature correlations and guide model selection.',
    theory: 'Univariate KDE analysis shows skewness (Insulin skew=3.03). Pearson correlation reveals Glucose has the highest link with Outcome (r=0.50), followed by Insulin (r=0.38) and BMI (r=0.32). IQR outlier detection flags 87 outliers in SkinThickness and 51 in Insulin. Model guidance recommends starting with Logistic Regression as explainable baseline and tree-based ensembles (Random Forest, XGBoost) to handle skewness and non-linear interactions.',
    inputs: 'Cleaned dataset full_cleaned_diabetes.csv from Experiment 3.',
    outputsSummary: '1_distributions.png, 2_correlation.png, 3_target_vs_features.png, eda_insights.txt.',
    code: `# ======================================================================
# EXPERIMENT 4: DATA EXPLORATION (EDA)
# Project: Health-Project 1 - Diabetes Risk Prediction
# Environment: Jupyter Notebook
# ======================================================================
import os
import textwrap
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

pd.set_option("display.width", 110)
sns.set_theme(style="whitegrid", palette="muted")

# 1. Load the cleaned dataset created in Experiment 3
df = pd.read_csv("processed_diabetes_exp3/full_cleaned_diabetes.csv")
features = [c for c in df.columns if c != "Outcome"]

# 2. Univariate analysis: histograms with KDE
fig, axes = plt.subplots(2, 4, figsize=(16, 7))
for ax, col in zip(axes.ravel(), features):
    sns.histplot(df[col], kde=True, ax=ax, color="#34495e", bins=25)
    ax.set_title(f"Distribution of {col}", fontsize=10, fontweight="bold")
plt.tight_layout()

# 3. Correlation heatmap (Pearson)
corr = df.corr()
plt.figure(figsize=(8, 6))
sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", mask=np.triu(np.ones_like(corr, dtype=bool)),
            vmin=-1, vmax=1, cbar_kws={"shrink": 0.8})
plt.title("Feature Correlation Matrix", fontweight="bold")
plt.tight_layout()

# 4. Bivariate analysis: key features against Outcome
fig, axes = plt.subplots(1, 3, figsize=(14, 4.2))
for ax, col in zip(axes, ["Glucose", "BMI", "Age"]):
    sns.boxplot(data=df, x="Outcome", y=col, hue="Outcome", palette=["#2ecc71", "#e74c3c"], legend=False, ax=ax)
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["Non-Diabetic (0)", "Diabetic (1)"])
    ax.set_title(f"{col} vs Outcome", fontweight="bold")
plt.tight_layout()

# 5. Outlier detection (IQR method)
outlier_rows = []
for col in features:
    q1, q3 = df[col].quantile(0.25), df[col].quantile(0.75)
    iqr = q3 - q1
    low, high = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    n_out = int(((df[col] < low) | (df[col] > high)).sum())
    outlier_rows.append([col, round(low, 2), round(high, 2), n_out, round(n_out / len(df) * 100, 1)])
outlier_df = pd.DataFrame(outlier_rows, columns=["Feature", "Lower", "Upper", "Outliers", "Percent"])
print(outlier_df.to_string(index=False))`,
    terminalOutput: `--- 2. OUTLIER ANALYSIS (IQR METHOD) ---
 Feature                    Lower   Upper  Outliers  Percent
 Pregnancies                -6.50   13.50         4      0.5
 Glucose                    39.00  201.00         0      0.0
 BloodPressure              40.00  104.00        14      1.8
 SkinThickness              14.50   42.50        87     11.3
 Insulin                     2.00  270.00        51      6.6
 BMI                        13.85   50.25         8      1.0
 DiabetesPedigreeFunction   -0.33    1.20        29      3.8
 Age                        -1.50   66.50         9      1.2

--- 3. KEY INSIGHTS ---
1. Glucose has the strongest link with Outcome (r = 0.50); next are Insulin (r = 0.38) and BMI (r = 0.32).
2. Diabetic patients have a higher mean Glucose (142.3 vs 110.6), BMI (35.4 vs 30.8) and Age (37.1 vs 31.2).
3. The strongest feature-to-feature correlation is BMI and SkinThickness (r = 0.57); no pair is high enough to need removing a feature.
4. Insulin is the most right-skewed feature (skewness 3.03), followed by DiabetesPedigreeFunction (1.92).
5. SkinThickness has the most IQR outliers (87); tree models handle them well.`,
    keyInsights: [
      'Top predictors: Glucose (r = 0.50), Insulin (r = 0.38), BMI (r = 0.32).',
      'Diabetic vs non-diabetic means: Glucose 142.3 vs 110.6 mg/dL; BMI 35.4 vs 30.8 kg/m²; Age 37.1 vs 31.2 yrs.',
      'Identified target leakage risk in dataset imputation spikes for SkinThickness and Insulin.',
    ],
  },

  5: {
    id: 5,
    title: 'Model Training',
    subtitle: 'Health-Project 1: Diabetes Risk Prediction | Model Training',
    filename: 'exp5_training.py',
    author: 'Dilpreet Singh',
    studentId: '230160223002',
    libraries: ['os', 'joblib', 'sklearn (LogisticRegression, RandomForestClassifier, GradientBoostingClassifier, GridSearchCV, StratifiedKFold)'],
    aim: 'To train and tune candidate models (Logistic Regression, Random Forest and XGBoost/Gradient Boosting) for diabetes prediction, compare them with cross-validation and save the best checkpoints.',
    theory: 'Baselines: Dummy classifier (CV recall 0.000) and default Logistic Regression (CV recall 0.605). Candidate models tuned via GridSearchCV with 5-fold stratified CV optimized specifically on Recall. Random Forest with max_depth=5, min_samples_leaf=3, n_estimators=100 achieved highest CV Recall of 0.878 (+/- 0.085) and CV ROC-AUC of 0.934.',
    inputs: 'Scaled training and validation sets (X_train_scaled.csv, y_train.csv, X_val_scaled.csv, y_val.csv).',
    outputsSummary: 'best_random_forest.joblib, best_gradient_boosting.joblib, best_logistic_regression.joblib, model_registry.json, training_results.csv.',
    code: `# ======================================================================
# EXPERIMENT 5: MODEL TRAINING
# Project: Health-Project 1 - Diabetes Risk Prediction
# Environment: Jupyter Notebook
# ======================================================================
import os
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.model_selection import GridSearchCV, StratifiedKFold, cross_validate

SEED = 42
data_dir = "processed_diabetes_exp3"
X_train = pd.read_csv(os.path.join(data_dir, "X_train_scaled.csv"))
X_val = pd.read_csv(os.path.join(data_dir, "X_val_scaled.csv"))
y_train = pd.read_csv(os.path.join(data_dir, "y_train.csv"))["Outcome"]
y_val = pd.read_csv(os.path.join(data_dir, "y_val.csv"))["Outcome"]

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)

candidates = {
    "Logistic Regression": (
        LogisticRegression(class_weight="balanced", max_iter=1000, random_state=SEED),
        {"C": [0.01, 0.1, 1, 10]}
    ),
    "Random Forest": (
        RandomForestClassifier(class_weight="balanced", random_state=SEED, n_jobs=1),
        {"n_estimators": [100, 300], "max_depth": [3, 5, 8], "min_samples_leaf": [3, 5]}
    ),
    "Gradient Boosting": (
        GradientBoostingClassifier(random_state=SEED),
        {"n_estimators": [100, 200], "max_depth": [2, 3], "learning_rate": [0.05, 0.1]}
    )
}

results = []
for name, (model, grid) in candidates.items():
    search = GridSearchCV(model, grid, scoring="recall", cv=cv, n_jobs=1).fit(X_train, y_train)
    best = search.best_estimator_
    joblib.dump(best, f"best_{name.lower().replace(' ', '_')}.joblib")
    print(f"{name}: Best params = {search.best_params_}")`,
    terminalOutput: `--- 1. BASELINE MODELS ---
Dummy (majority class)         CV recall = 0.000 | Val recall = 0.000 | Val accuracy = 0.652
Baseline Logistic Regression   CV recall = 0.605 | Val recall = 0.550 | Val accuracy = 0.696

--- 2. HYPER-PARAMETER TUNING & CROSS-VALIDATION ---
Logistic Regression: best params = {'C': 0.1}
 CV recall = 0.765 +/- 0.067 | CV ROC-AUC = 0.872 | CV precision = 0.688

Random Forest: best params = {'max_depth': 5, 'min_samples_leaf': 3, 'n_estimators': 100}
 CV recall = 0.878 +/- 0.085 | CV ROC-AUC = 0.934 | CV precision = 0.789

Gradient Boosting: best params = {'learning_rate': 0.05, 'max_depth': 3, 'n_estimators': 100}
 CV recall = 0.824 +/- 0.053 | CV ROC-AUC = 0.938 | CV precision = 0.823

--- 3. MODEL COMPARISON (training CV vs validation) ---
             Model  CV Recall  CV Precision  CV F1  CV ROC-AUC  Val Recall  Val Precision  Val F1  Val ROC-AUC
Logistic Regression      0.765         0.688  0.721       0.872       0.750          0.588   0.659        0.806
      Random Forest      0.878         0.789  0.829       0.934       0.825          0.717   0.767        0.922
  Gradient Boosting      0.824         0.823  0.823       0.938       0.775          0.816   0.795        0.942`,
    keyInsights: [
      'Random Forest achieved highest CV Recall (0.878 ± 0.085) with hyperparams: max_depth=5, min_samples_leaf=3, n_estimators=100.',
      'Gradient Boosting provided best CV Precision (0.823) and highest ROC-AUC (0.938).',
      'All tuned models vastly outperformed the dummy majority classifier (0.000) and baseline logistic regression (0.605).',
    ],
  },

  6: {
    id: 6,
    title: 'Model Evaluation',
    subtitle: 'Health-Project 1: Diabetes Risk Prediction | Model Evaluation',
    filename: 'exp6_evaluation.py',
    author: 'Dilpreet Singh',
    studentId: '230160223002',
    libraries: ['os', 'joblib', 'matplotlib.pyplot', 'seaborn', 'sklearn.metrics (confusion_matrix, roc_curve, precision_recall_curve, fbeta_score)'],
    aim: 'To evaluate the trained models on validation and held-out test data with accuracy, precision, recall, F1-score and ROC-AUC, to analyse errors, and to select and justify the final model.',
    theory: 'Selection rule: Highest F2 score on validation set (recall weighted 2x over precision). Random Forest selected: Val Recall 0.825, F2 0.801. Held-out test set result: Recall 0.902, Precision 0.902, F1 0.902, Accuracy 0.931, ROC-AUC 0.966. Only 4 missed diabetic patients (FN) and 4 false alarms (FP). Error analysis reveals missed diabetic patients had lower average Glucose (125.2 vs 143.4) and lower BMI (29.1 vs 35.7).',
    inputs: 'Trained model checkpoints and test set (116 records, 41 diabetic).',
    outputsSummary: 'final_model.joblib, final_model_info.json, confusion_matrices.png, roc_pr_curves.png, misclassified_test_cases.csv.',
    code: `# ======================================================================
# EXPERIMENT 6: MODEL EVALUATION
# Project: Health-Project 1 - Diabetes Risk Prediction
# Environment: Jupyter Notebook
# ======================================================================
import os
import joblib
import pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, fbeta_score, roc_auc_score, confusion_matrix

data_dir = "processed_diabetes_exp3"
X_val = pd.read_csv(os.path.join(data_dir, "X_val_scaled.csv"))
X_test = pd.read_csv(os.path.join(data_dir, "X_test_scaled.csv"))
y_val = pd.read_csv(os.path.join(data_dir, "y_val.csv"))["Outcome"]
y_test = pd.read_csv(os.path.join(data_dir, "y_test.csv"))["Outcome"]

rf = joblib.load("models_exp5/best_random_forest.joblib")
pred = rf.predict(X_test)
prob = rf.predict_proba(X_test)[:, 1]

cm = confusion_matrix(y_test, pred)
tn, fp, fn, tp = cm.ravel()
print(f"Random Forest Test Confusion Matrix: TN={tn}, FP={fp}, FN={fn}, TP={tp}")
print(f"Recall: {recall_score(y_test, pred):.3f}")
print(f"Precision: {precision_score(y_test, pred):.3f}")
print(f"ROC-AUC: {roc_auc_score(y_test, prob):.3f}")`,
    terminalOutput: `--- 1. VALIDATION SET METRICS ---
                    Accuracy  Precision  Recall     F1     F2  ROC-AUC
Logistic Regression    0.730      0.588   0.750  0.659  0.711    0.806
      Random Forest    0.826      0.717   0.825  0.767  0.801    0.922
  Gradient Boosting    0.861      0.816   0.775  0.795  0.783    0.942

--- 2. TEST SET METRICS (held-out) ---
                    Accuracy  Precision  Recall     F1     F2  ROC-AUC
Logistic Regression    0.819      0.727   0.780  0.753  0.769    0.909
      Random Forest    0.931      0.902   0.902  0.902  0.902    0.966
  Gradient Boosting    0.897      0.914   0.780  0.842  0.804    0.963

Random Forest : TN = 71, FP =  4, FN =  4, TP = 37

--- 5. ERROR ANALYSIS (final model, test set) ---
False negatives (missed diabetic patients): 4 | False positives (false alarms): 4
Average values by group:
         Detected diabetic  Missed diabetic  Non-diabetic
Glucose              143.4            125.2         105.7
BMI                   35.7             29.1          29.6
Age                   36.3             31.5          31.1
Insulin              221.4            112.9         111.5`,
    keyInsights: [
      'Random Forest selected by F2-score optimization (Val F2 = 0.801, Recall = 0.825).',
      'Held-out test performance: Recall = 0.902 (37/41 diabetics detected), Precision = 0.902, ROC-AUC = 0.966.',
      'Error analysis: Missed patients presented with atypical sub-clinical glucose (125.2 mg/dL) and normal BMI (29.1).',
    ],
  },

  7: {
    id: 7,
    title: 'Deployment & REST API',
    subtitle: 'Health-Project 1: Diabetes Risk Prediction | Deployment',
    filename: 'exp7_deployment.py',
    author: 'Dilpreet Singh',
    studentId: '230160223002',
    libraries: ['os', 'json', 'joblib', 'Flask', 'werkzeug', 'urllib.request'],
    aim: 'To deploy the final model as a Flask REST API that returns a diabetes-risk score from patient vitals, test it with sample inputs and document its usage and response schema.',
    theory: 'In deployment, the inference microservice repeats Experiment 3 pipeline steps: unmeasured zeros in Glucose, BP, Skin, Insulin, BMI are filled with training medians, then scaled via standard_scaler.joblib. The API implements input validation (HTTP 400 for out-of-range or missing fields) and returns calibrated risk score (0-1), risk level (Low < 0.30 <= Moderate < 0.50 <= High), and binary prediction.',
    inputs: 'final_model.joblib, standard_scaler.joblib, preprocessing_info.joblib, patient vitals JSON.',
    outputsSummary: 'app.py, scoring.py, sample_request_response_log.json, usage_documentation.txt.',
    code: `# ======================================================================
# EXPERIMENT 7: DEPLOYMENT (Flask REST API)
# Project: Health-Project 1 - Diabetes Risk Prediction
# Environment: Jupyter Notebook
# ======================================================================
from flask import Flask, jsonify, request
import numpy as np
import pandas as pd
import joblib

app = Flask(__name__)
model = joblib.load("final_model.joblib")
scaler = joblib.load("standard_scaler.joblib")

FEATURES = ["Pregnancies", "Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI", "DiabetesPedigreeFunction", "Age"]
MEDIANS = {"Glucose": 117.0, "BloodPressure": 72.0, "SkinThickness": 28.0, "Insulin": 102.5, "BMI": 32.4}
THRESHOLD = 0.50

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "model": "Random Forest", "features": FEATURES})

@app.route("/predict", methods=["POST"])
def predict():
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return jsonify({"error": "Send a JSON object with 8 patient measurements."}), 400

    row = pd.DataFrame([payload], columns=FEATURES)
    imputed = [c for c in MEDIANS if row.loc[0, c] == 0]
    for col, med in MEDIANS.items():
        if row.loc[0, col] == 0:
            row.loc[0, col] = med

    scaled = pd.DataFrame(scaler.transform(row), columns=FEATURES)
    score = float(model.predict_proba(scaled)[0, 1])
    risk_level = "High" if score >= 0.50 else ("Moderate" if score >= 0.30 else "Low")

    return jsonify({
        "risk_score": round(score, 4),
        "risk_percent": round(score * 100, 1),
        "risk_level": risk_level,
        "prediction": int(score >= THRESHOLD),
        "prediction_label": "Diabetic (confirmatory test advised)" if score >= THRESHOLD else "Non-diabetic",
        "imputed_fields": imputed,
        "model": "Random Forest"
    })

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5050)`,
    terminalOutput: `--- GET /health ---
200 {"features": ["Pregnancies", "Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI", "DiabetesPedigreeFunction", "Age"], "model": "Random Forest", "status": "ok"}

--- POST /predict : Patient A (higher-risk vitals) ---
Status: 200
Response: {"imputed_fields": [], "model": "Random Forest", "prediction": 1, "prediction_label": "Diabetic (confirmatory test advised)", "risk_level": "High", "risk_percent": 90.6, "risk_score": 0.9058}

--- POST /predict : Patient B (lower-risk vitals) ---
Status: 200
Response: {"imputed_fields": [], "model": "Random Forest", "prediction": 0, "prediction_label": "Non-diabetic", "risk_level": "Low", "risk_percent": 4.4, "risk_score": 0.0438}

--- POST /predict : Patient C (Insulin and SkinThickness not measured = 0) ---
Status: 200
Response: {"imputed_fields": ["SkinThickness", "Insulin"], "model": "Random Forest", "prediction": 0, "prediction_label": "Non-diabetic", "risk_level": "Low", "risk_percent": 19.9, "risk_score": 0.1985}

--- POST /predict : Patient D (Age field missing) ---
Status: 400
Response: {"error": "Missing fields: Age"}`,
    keyInsights: [
      'Inference service reproduces exact preprocessing pipeline without runtime dependencies on training datasets.',
      'Handles non-measured clinical vitals (zeros) with automated median imputation.',
      'Provides robust input validation returning HTTP 400 for out-of-range or missing attributes.',
    ],
  },

  8: {
    id: 8,
    title: 'Continuous Update & Maintenance',
    subtitle: 'Health-Project 1: Diabetes Risk Prediction | Continuous Update & Maintenance',
    filename: 'exp8_maintenance.py',
    author: 'Dilpreet Singh',
    studentId: '230160223002',
    libraries: ['os', 'json', 'shutil', 'joblib', 'datetime', 'scipy.stats (ks_2samp)', 'sklearn.metrics'],
    aim: 'To prepare a Monitoring & Maintenance Plan for the deployed model and a simple data and performance drift-check script, with prediction logging, retraining triggers, a rollback plan and clinical ownership.',
    theory: 'Population Stability Index (PSI) tracks covariate drift (<0.10 stable, 0.10-0.25 watch, >=0.25 drift). Kolmogorov-Smirnov (KS) test checks 2-sample distributional equality. Retraining triggers: 2+ features with PSI >= 0.25, recall drop > 0.05, flagged rate delta > 10%, model age >= 90 days, or new cohort >= 200 patients. Rollback preserves last 3 checkpoints with instant promotion/reversion.',
    inputs: 'Reference training distribution, Batch A (test cohort), Batch B (simulated shifted cohort: Glucose +20, BMI +4, Age +5).',
    outputsSummary: 'prediction_log.csv, registry.json, monitoring_plan.json, drift_report_batcha.csv, drift_report_batchb.csv.',
    code: `# ======================================================================
# EXPERIMENT 8: CONTINUOUS UPDATE & MAINTENANCE
# Project: Health-Project 1 - Diabetes Risk Prediction
# Environment: Jupyter Notebook
# ======================================================================
import os
import json
import numpy as np
import pandas as pd
from scipy.stats import ks_2samp

def psi(ref, new, bins=10):
    edges = np.unique(np.quantile(ref, np.linspace(0, 1, bins + 1)))
    edges[0], edges[-1] = -np.inf, np.inf
    r = np.clip(np.histogram(ref, edges)[0] / len(ref), 1e-4, None)
    n = np.clip(np.histogram(new, edges)[0] / len(new), 1e-4, None)
    return float(np.sum((n - r) * np.log(n / r)))

def drift_report(ref, new, features):
    rows = []
    for col in features:
        val = psi(ref[col], new[col])
        status = "Stable" if val < 0.10 else ("Watch" if val < 0.25 else "DRIFT")
        rows.append([col, round(val, 3), round(ks_2samp(ref[col], new[col]).pvalue, 4), status])
    return pd.DataFrame(rows, columns=["Feature", "PSI", "KS p-value", "Status"])

# Retraining Triggers Decision Logic
def retraining_decision(drift_df, perf, days_since_training, baseline_recall, baseline_pos_rate):
    reasons = []
    if (drift_df["PSI"] >= 0.25).sum() >= 2:
        reasons.append("2 or more features have PSI >= 0.25")
    if baseline_recall - perf["recall"] > 0.05:
        reasons.append(f"recall dropped by more than 0.05 (baseline {baseline_recall})")
    if abs(perf["positive_rate"] - baseline_pos_rate) > 0.10:
        reasons.append("share of patients flagged as diabetic moved by more than 10 points")
    if days_since_training >= 90:
        reasons.append("model is 90 days old (scheduled review)")
    return ("RETRAIN", reasons) if reasons else ("KEEP", ["no trigger fired"])`,
    terminalOutput: `--- 1. MONITORING RUN ---
Batch A (test cohort, no change)
                   Feature    PSI  KS p-value  Status
               Pregnancies  0.096      0.8104  Stable
                   Glucose  0.095      0.1113  Stable
             BloodPressure  0.063      0.9170  Stable
             SkinThickness  0.135      0.6538   Watch
                   Insulin  0.019      0.7684  Stable
                       BMI  0.183      0.0637   Watch
  DiabetesPedigreeFunction  0.080      0.7982  Stable
                       Age  0.071      0.5182  Stable
Performance: {'recall': 0.902, 'precision': 0.902, 'positive_rate': 0.353}
Decision: KEEP (no trigger fired)

Batch B (simulated shifted cohort)
                   Feature    PSI  KS p-value  Status
               Pregnancies  0.099      0.7623  Stable
                   Glucose  0.596      0.0000   DRIFT
             BloodPressure  0.176      0.6466   Watch
             SkinThickness  0.071      0.1350  Stable
                   Insulin  0.017      0.8671  Stable
                       BMI  0.308      0.0000   DRIFT
  DiabetesPedigreeFunction  0.085      0.1553  Stable
                       Age  2.118      0.0000   DRIFT
Performance: {'recall': 0.922, 'precision': 0.648, 'positive_rate': 0.455}
Decision: RETRAIN (2 or more features have PSI >= 0.25; share of patients flagged as diabetic moved by more than 10 points)

--- 3. MODEL VERSIONING & ROLLBACK (dry run) ---
After promoting v2 -> active: v2
After rollback -> active: v1`,
    keyInsights: [
      'Batch A (stable cohort) triggered decision KEEP; PSI for all features remained < 0.25.',
      'Batch B (simulated geriatric & metabolic shift) triggered RETRAIN: Glucose PSI=0.596, BMI PSI=0.308, Age PSI=2.118.',
      'Versioning & rollback dry-run verified instant fallback to v1 upon drift detection.',
    ],
  },
};
