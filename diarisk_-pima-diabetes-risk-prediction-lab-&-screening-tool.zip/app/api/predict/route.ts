import { NextRequest, NextResponse } from 'next/server';
import { predictPatientRisk, PatientVitalsInput } from '@/lib/mlEngine';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const {
      pregnancies = 0,
      glucose = 120,
      bloodPressure = 72,
      skinThickness = 27,
      insulin = 102.5,
      bmi = 32.0,
      diabetesPedigreeFunction = 0.375,
      age = 33,
      model = 'xgboost',
      decisionThreshold = 0.45,
    } = body;

    // Validate inputs
    if (glucose <= 0 || bloodPressure <= 0 || bmi <= 0) {
      return NextResponse.json(
        {
          error: 'Invalid physiological inputs: Glucose, BloodPressure, and BMI must be greater than zero.',
          hint: 'Ensure zero-imputation or valid diagnostic measures are supplied.',
        },
        { status: 400 }
      );
    }

    const vitals: PatientVitalsInput = {
      pregnancies: Number(pregnancies),
      glucose: Number(glucose),
      bloodPressure: Number(bloodPressure),
      skinThickness: Number(skinThickness),
      insulin: Number(insulin),
      bmi: Number(bmi),
      diabetesPedigreeFunction: Number(diabetesPedigreeFunction),
      age: Number(age),
    };

    const validModels = ['xgboost', 'random_forest', 'logistic_regression'] as const;
    const selectedModel = validModels.includes(model) ? model : 'xgboost';

    const prediction = predictPatientRisk(vitals, selectedModel, Number(decisionThreshold));

    const timestamp = new Date().toISOString();
    const requestId = 'req_' + Math.random().toString(36).substring(2, 10);

    return NextResponse.json({
      requestId,
      timestamp,
      model: {
        id: selectedModel,
        displayName: prediction.modelUsed,
        framework: 'Health Project 1: Tuned ML Pipeline v1.0',
        decisionThreshold: prediction.thresholdUsed,
      },
      patientVitals: vitals,
      assessment: {
        diabetesRiskScore: prediction.riskScorePercent,
        probability: prediction.probability,
        predictionBinary: prediction.predictedOutcome,
        riskTier: prediction.riskLevel,
        triageAction: prediction.clinicalAction,
        confirmatoryUrgency: prediction.confirmatoryUrgency,
      },
      riskFactorBreakdown: prediction.riskDrivers.map((d) => ({
        parameter: d.feature,
        label: d.label,
        observedValue: d.value,
        clinicalNormal: d.reference,
        relativeRiskContribution: d.contributionScore,
        status: d.status,
        pathologicalMechanism: d.note,
      })),
      complianceNote:
        'Clinical Decision Support (CDS) for primary-care screening triage. Not a standalone diagnostic substitute for laboratory HbA1c or FPG test.',
    });
  } catch (error: unknown) {
    const errMessage = error instanceof Error ? error.message : 'Internal scoring error';
    return NextResponse.json({ error: errMessage }, { status: 500 });
  }
}

export async function GET() {
  return NextResponse.json({
    status: 'healthy',
    service: 'Health Project 1: Diabetes Clinical Screening API',
    version: '1.2.0',
    dataset: 'Pima Indians Diabetes Database (UCI Machine Learning Repository)',
    availableEndpoints: [
      {
        path: '/api/predict',
        method: 'POST',
        description: 'Computes diabetes risk score, risk level, and triage recommendation from 8 diagnostic features.',
      },
      {
        path: '/api/gemini/clinical-advice',
        method: 'POST',
        description: 'Generates ADA-grounded clinical narrative and patient intervention plan using Gemini.',
      },
    ],
  });
}
