import type { Metadata } from 'next';
import './globals.css';
import { ThemeProvider } from '@/components/ThemeProvider';

export const metadata: Metadata = {
  title: 'Health Project 1: Diabetes Risk Prediction',
  description: 'Health Project 1 — Pima Indians Diabetes machine learning research pipeline, 8-experiment lab studio, and recall-optimized clinical screening system.',
  openGraph: {
    title: 'Health Project 1: Diabetes Risk Prediction',
    description: 'Health Project 1 — Pima Indians Diabetes machine learning research pipeline, 8-experiment lab studio, and recall-optimized clinical screening system.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Health Project 1: Diabetes Risk Prediction',
    description: 'Health Project 1 — Pima Indians Diabetes machine learning research pipeline, 8-experiment lab studio, and recall-optimized clinical screening system.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning className="scroll-smooth">
      <body suppressHydrationWarning className="bg-[#f2f2f2] text-[#111111] antialiased selection:bg-[#111111] selection:text-[#f2f2f2]">
        {children}
      </body>
    </html>
  );
}
