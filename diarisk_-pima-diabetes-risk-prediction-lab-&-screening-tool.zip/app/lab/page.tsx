'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import Navbar from '@/components/Navbar';
import LabStudio from '@/components/LabStudio';

export default function LabPage() {
  const router = useRouter();
  const [activeExp, setActiveExp] = useState<number>(1);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navbar
        activeTab="lab"
        setActiveTab={(tab) => {
          if (tab === 'screening') {
            router.push('/');
          }
        }}
        onSelectExperiment={(exp) => setActiveExp(exp)}
      />

      <main className="flex-1">
        <LabStudio
          activeExp={activeExp}
          setActiveExp={setActiveExp}
          onLaunchScreening={() => router.push('/')}
        />
      </main>

      <footer className="border-t border-slate-200 bg-white py-6 mt-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-800">Health-Project 1: Diabetes Risk Prediction</span>
            <span>•</span>
            <span>Pima Indians Diabetes Database (NIDDK/UCI)</span>
          </div>
          <div className="flex items-center gap-4">
            <span>8 Laboratory Experiments</span>
            <span>•</span>
            <span>Decision Support System</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
