'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Navbar from '@/components/Navbar';
import EditorialSections from '@/components/EditorialSections';
import ClinicalScreening from '@/components/ClinicalScreening';
import LabStudio from '@/components/LabStudio';
import EditorialFooter from '@/components/EditorialFooter';

export default function Home() {
  const [activeTab, setActiveTab] = useState<'screening' | 'lab'>('screening');
  const [activeExp, setActiveExp] = useState<number>(1);
  const [selectedPersonaId, setSelectedPersonaId] = useState<'low' | 'moderate' | 'high' | 'gestational'>('moderate');

  const handleSelectExp = (expNumber: number) => {
    setActiveExp(expNumber);
    setActiveTab('lab');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleScrollToScreener = () => {
    if (activeTab !== 'screening') {
      setActiveTab('screening');
      setTimeout(() => {
        const el = document.getElementById('clinical-workspace');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 150);
    } else {
      const el = document.getElementById('clinical-workspace');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative min-h-screen flex flex-col bg-[#f2f2f2] text-[#111111] selection:bg-[#111111] selection:text-[#f2f2f2]">
      {/* Sticky 80px Navigation in #f2f2f2 with 90% opacity & backdrop-blur(12px) */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeLabExp={activeExp}
        setActiveLabExp={setActiveExp}
        onSelectExperiment={handleSelectExp}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full">
        <AnimatePresence mode="wait">
          {activeTab === 'screening' ? (
            <motion.div
              key="screening"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3, ease: [0.77, 0, 0.175, 1] }}
              className="w-full"
            >
              {/* Editorial Hero, Philosophy, Asymmetrical Showcase Grid, and Bespoke Service Cards */}
              <EditorialSections
                onSelectPersona={(id) => {
                  setSelectedPersonaId(id);
                  handleScrollToScreener();
                }}
                onNavigateToLab={handleSelectExp}
                onScrollToScreener={handleScrollToScreener}
              />

              {/* Functional Clinical Workspace (Patient Intake Form, Real-time Risk Gauge, Report Generator) */}
              <ClinicalScreening
                onOpenLab={() => handleSelectExp(1)}
                presetPersona={selectedPersonaId}
              />
            </motion.div>
          ) : (
            <motion.div
              key="lab"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3, ease: [0.77, 0, 0.175, 1] }}
              className="w-full"
            >
              <LabStudio
                activeExp={activeExp}
                setActiveExp={setActiveExp}
                onLaunchScreening={() => {
                  setActiveTab('screening');
                  handleScrollToScreener();
                }}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Deep dark theme (#1e1e1e) Footer with 60% opacity text and 4-column layout */}
      <EditorialFooter
        onSwitchTab={setActiveTab}
        onNavigateToLab={handleSelectExp}
      />
    </div>
  );
}
